package com.palm.jprotobuf;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 协议注解 所有协议均需附带 包括：枚举、内部类
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Documented
public @interface Message {
    public long         code() default 0;                   //协议编号
    public MessageType  type() default MessageType.OTHER;   //协议类型
    public String       note() default "";                  //协议备注
}
