package com.palm.jprotobuf;

import com.baidu.bjf.remoting.protobuf.Codec;
import com.baidu.bjf.remoting.protobuf.ProtobufProxy;
import com.baidu.bjf.remoting.protobuf.annotation.Protobuf;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.Descriptors;

import java.lang.reflect.Field;

public class ProtobufProxyKit {
    public static <TClass> Codec<TClass> createCodec(final Class<TClass> vClass) {
        boolean tIsCanCreate = false;

        Class tClass = vClass;
        out: while (null != tClass){
            for (Field tField : tClass.getDeclaredFields()) {
                if (null != tField.getAnnotation(Protobuf.class)) {
                    tIsCanCreate = true;
                    break out;
                }
            }
            tClass = tClass.getSuperclass();
        }


        if(true == tIsCanCreate){
            return ProtobufProxy.create(vClass);
        }else {
            return new Codec<TClass>() {
                @Override
                public byte[] encode(Object vObject){
                    return new byte[0];
                }

                @Override
                public TClass decode(byte[] bytes){
                    try {
                        return vClass.newInstance();
                    } catch (Throwable vE) {
                        throw new RuntimeException(vE);
                    }
                }

                @Override
                public int size(Object vObject){
                    return 0;
                }

                @Override
                public void writeTo(Object vObject, CodedOutputStream out){

                }

                @Override
                public TClass readFrom(CodedInputStream intput){
                    try {
                        return vClass.newInstance();
                    } catch (Throwable vE) {
                        throw new RuntimeException(vE);
                    }
                }

                @Override
                public Descriptors.Descriptor getDescriptor(){
                    return null;
                }
            };
        }
    }
}
