package com.palm.jprotobuf;

public enum MessageType{
    REQUEST,
    RESPONSE,
    NOTICE_PRIVATE,
    NOTICE_PUBLIC,
    INLINE,
    ENUM,
    OTHER,
}
