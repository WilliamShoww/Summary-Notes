package com.palm.jprotobuf;

import com.baidu.bjf.remoting.protobuf.EnumReadable;
import com.baidu.bjf.remoting.protobuf.FieldType;
import com.baidu.bjf.remoting.protobuf.annotation.Protobuf;
import com.baidu.bjf.remoting.protobuf.utils.FieldInfo;
import com.baidu.bjf.remoting.protobuf.utils.FieldUtils;
import com.baidu.bjf.remoting.protobuf.utils.ProtobufProxyUtils;
import com.palm.common.kit.ClassKit;
import com.palm.common.kit.PathKit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.*;

/**
 * 协议生成工具
 */
@SuppressWarnings("all")
public class MakeProtocolFileKit {
    private final static Logger LOGGER = LoggerFactory.getLogger(MakeProtocolFileKit.class);

    /**
     * 生成协议
     * @param vPackageName  协议目录（会自动递归处理）
     * @param vDirPath      协议存放目录
     * @return
     * @throws IOException
     */
    public static boolean makeAndCreate(String vPackageName, String vDirPath) throws IOException {
        File tDirFile = new File(vDirPath);
        if(false == tDirFile.exists())
            tDirFile.mkdirs();

        Set<Class> tClassList = ClassKit.getClassList(vPackageName, Message.class);
        Map<String, Set<Class>> tPackageProtocolSetMap = carveClassByPackage(tClassList);
        for (Map.Entry<String, Set<Class>> tPackageProtocolSetEntry : tPackageProtocolSetMap.entrySet()) {
            String tProtocol = makeProtocol(tPackageProtocolSetEntry.getKey(), tPackageProtocolSetEntry.getValue());
            if(null == tProtocol)
                return false;

            String tFile = String.format("%s.proto", tPackageProtocolSetEntry.getKey().replace('.', '_'));
            try (FileOutputStream tFileOutputStream = new FileOutputStream(PathKit.joint(vDirPath, tFile))){
                tFileOutputStream.write(tProtocol.getBytes());
            }
        }

        return true;
    }

    /**
     * 协议分包
     * @param vCollectionSet 需要分包的协议集合
     * @return
     */
    public static Map<String, Set<Class>> carveClassByPackage(Collection<Class> vCollectionSet){
        Map<String, Set<Class>> tResult = new HashMap<>();
        for (Class tClass : vCollectionSet) {
            String tPackageName = tClass.getPackage().getName();
            Set<Class> tClassList = tResult.get(tPackageName);
            if(null == tClassList){
                tClassList = new LinkedHashSet();
                tResult.put(tPackageName, tClassList);
            }
            tClassList.add(tClass);
        }
        return tResult;
    }

    /**
     * 按格式生成协议
     * @param vPackageName  包名
     * @param vClassList    协议集合
     * @return
     */
    public static String makeProtocol(String vPackageName, Collection<Class> vClassList){
        StringBuilder   tMsgItems       = new StringBuilder();
        StringBuilder   tProtocols      = new StringBuilder();
        StringBuilder   tPackageImports = new StringBuilder();
        Set<Class>      tInlineClassSet = new LinkedHashSet();
        Set<String>     tPackageNameSet = new LinkedHashSet();
        for (Class tClass : vClassList) {
            Message tMessage = (Message) tClass.getAnnotation(Message.class);
            if(0 != tMessage.code()){
                tMsgItems.append(String.format("\tMsg%s\t=\t%d;\t//%s\n", tClass.getSimpleName(), tMessage.code(), tMessage.note()));
            }

            tInlineClassSet.clear();
            String tProtocol = Enum.class.isAssignableFrom(tClass) ? generateEnumIDL(tClass) : generateClassIDL(tClass, tInlineClassSet);
            for (Class tInlineClass : tInlineClassSet) {
                Message tInlineMessage = (Message) tInlineClass.getAnnotation(Message.class);
                if(null == tInlineMessage){
                    LOGGER.error("{}->{} not Message Annotation", tClass, tInlineClass);
                    return null;
                }

                if(false == tInlineClass.getPackage().getName().equals(vPackageName))
                    tPackageNameSet.add(tInlineClass.getPackage().getName());
            }

            tProtocols.append(tProtocol).append("\n");
        }

        for (String tPackageName : tPackageNameSet)
            tPackageImports.append(String.format("import\t\"%s\";\n\n", tPackageName));

        //带协议头
        String tResult = String.format("%s\noption java_package = \"%s\";\n\nenum MsgType {\n%s}\n\n%s",
                tPackageImports, vPackageName, tMsgItems, tProtocols);

        return tResult;
    }

    /**
     * 按格式拼装协议模型
     * @param vClass            协议java类
     * @param vInlineClassSet   协议所需的内联类（外部类集合 用于存放）
     * @return
     */
    public static String generateClassIDL(Class<?> vClass, Set<Class> vInlineClassSet){
        StringBuilder tStringBuilder = new StringBuilder();
        tStringBuilder.append("message ").append(vClass.getSimpleName()).append(" {  \n");
        for (FieldInfo tFieldInfo : ProtobufProxyUtils.processDefaultValue(FieldUtils.findMatchedFields(vClass, Protobuf.class), false)) {
            if (FieldType.OBJECT == tFieldInfo.getFieldType() || FieldType.ENUM == tFieldInfo.getFieldType()) {
                if (tFieldInfo.isList()) {
                    Type tGenericType = tFieldInfo.getField().getGenericType();
                    if (tGenericType instanceof ParameterizedType) {
                        Type[] tActualTypeArguments = ((ParameterizedType) tGenericType).getActualTypeArguments();
                        if (null != tActualTypeArguments && 0 < tActualTypeArguments.length) {
                            Type tTargetType = tActualTypeArguments[0];
                            if (tTargetType instanceof Class) {
                                Class tClass = (Class) tTargetType;

                                String tFieldTypeName;
                                if (ProtobufProxyUtils.isScalarType(tClass)) {
                                    tFieldTypeName = ProtobufProxyUtils.TYPE_MAPPING.get(tClass).getType();
                                } else {
                                    tFieldTypeName = tClass.getSimpleName();
                                    vInlineClassSet.add(tClass);
                                }

                                tStringBuilder.append("\t").append("repeated ").append(tFieldTypeName).append(" ")
                                        .append(tFieldInfo.getField().getName()).append("=").append(tFieldInfo.getOrder())
                                        .append(";");
                            }
                        }
                    }
                } else {
                    Class tClass = tFieldInfo.getField().getType();
                    tStringBuilder.append("\t").append(getFieldRequired(tFieldInfo.isRequired())).append(" ").append(tClass.getSimpleName()).append(" ")
                            .append(tFieldInfo.getField().getName()).append("=").append(tFieldInfo.getOrder()).append(";");

                    vInlineClassSet.add(tClass);
                }
            } else {
                String tType = tFieldInfo.getFieldType().getType().toLowerCase();
                if (FieldType.ENUM == tFieldInfo.getFieldType()) {
                    tType = tFieldInfo.getField().getType().getSimpleName();
                    vInlineClassSet.add(tFieldInfo.getField().getType());
                } /*else if (FieldType.MAP == tFieldInfo.getFieldType()) {
                    Class tGenericKeyType = tFieldInfo.getGenericKeyType();
                    Class tGenericValueType = tFieldInfo.getGenericeValueType();
                    tType = tType + "<" + ProtobufProxyUtils.processProtobufType(tGenericKeyType) + ", " + ProtobufProxyUtils.processProtobufType(tGenericValueType)  + ">";

                    if (ProtobufProxyUtils.isObjectType(tGenericKeyType)) {
                        vInlineClassSet.add(tGenericKeyType);
                    }

                    if (ProtobufProxyUtils.isObjectType(tGenericValueType)) {
                        vInlineClassSet.add(tGenericValueType);
                    }
                }*/

                tStringBuilder.append("\t").append(getSign(tFieldInfo)).append(" ").append(tType).append(" ").append(tFieldInfo.getField().getName())
                        .append("=").append(tFieldInfo.getOrder()).append(";");
            }

            if (tFieldInfo.hasDescription()) {
                tStringBuilder.append("\t//").append(tFieldInfo.getDescription());
            }

            tStringBuilder.append("\n");
        }

        tStringBuilder.append("}\n");

        return tStringBuilder.toString();
    }

    /**
     * 生成枚举协议
     * @param vEnumClass java 枚举
     * @return
     */
    public static String generateEnumIDL(Class<? extends Enum> vEnumClass) {
        StringBuilder tBuilder = new StringBuilder();
        tBuilder.append("enum ").append(vEnumClass.getSimpleName()).append(" {  \n");

        List<Integer> tEnumIndexList = new ArrayList();
        Field[] tFields = vEnumClass.getFields();
        for (Field tField : tFields) {
            String tFieldName = tField.getName();
            tBuilder.append("\t").append(tFieldName).append("=");
            try {
                Enum tValue = Enum.valueOf(vEnumClass, tFieldName);
                int tEnumIndex = tValue.ordinal();
                if (tValue instanceof EnumReadable)
                    tEnumIndex = ((EnumReadable) tValue).value();

                if(true == tEnumIndexList.contains(tEnumIndex)){
                    LOGGER.error("generateEnum {}.{} index clash", tField.getGenericType(), tField.getName());
                }
                tEnumIndexList.add(tEnumIndex);
                tBuilder.append(tEnumIndex).append(";");

                EnumNote tEnumNote = tField.getAnnotation(EnumNote.class);
                if(null != tEnumNote && false == tEnumNote.value().isEmpty()){
                    tBuilder.append(" //");
                    tBuilder.append(tEnumNote.value());
                }

                tBuilder.append("\n");
            } catch (RuntimeException vE) {
                LOGGER.warn("generateEnum {}.{} fail", tField.getGenericType(), tField.getName(), vE);
            }
        }

        tBuilder.append("}\n ");
        return tBuilder.toString();
    }

    private static String getFieldRequired(boolean vRequired) {
        return vRequired ? "required" : "optional";
    }

    private static String getSign(FieldInfo vFieldInfo) {
        if(true == vFieldInfo.isRequired()) return "required";
        if(true == vFieldInfo.isList()) return "repeated";
        if(true == vFieldInfo.isMap()) return "";
        return "optional";
    }
}
