package com.palm.core.net.websocket.perfect;

import com.palm.core.net.websocket.config.WebSocketConfig;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.handler.codec.http.websocketx.WebSocketServerProtocolHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationListener;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import javax.annotation.PreDestroy;

@Component
public class NettyChannel implements ApplicationListener<ApplicationReadyEvent>, ApplicationContextAware {
    private final static Logger LOGGER = LoggerFactory.getLogger(NettyChannel.class);

    private ApplicationContext s_ApplicationContext;
    @Autowired
    private WebSocketConfig webSocketConfig;
    @Autowired
    private Environment m_Environment;

    private EventLoopGroup m_ParentGroup;
    private EventLoopGroup m_ChildGroup;

    @PreDestroy
    public void uninit() {
        m_ParentGroup.shutdownGracefully();
        m_ChildGroup.shutdownGracefully();
    }

    @Override
    public void setApplicationContext(ApplicationContext vApplicationContext) throws BeansException {
        s_ApplicationContext = vApplicationContext;
    }

    @Override
    public void onApplicationEvent(ApplicationReadyEvent vApplicationReadyEvent) {
        try {
            m_ParentGroup = new NioEventLoopGroup(webSocketConfig.getBossGroupThreadSize());
            m_ChildGroup = new NioEventLoopGroup(webSocketConfig.getWorkerGroupThreadSize());
            ServerBootstrap tServerBootstrap = new ServerBootstrap();
            tServerBootstrap.group(m_ParentGroup, m_ChildGroup)
                    .channel(NioServerSocketChannel.class)
                    .option(ChannelOption.SO_BACKLOG, 128)
                    .childHandler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        public void initChannel(SocketChannel vSocketChannel) throws Exception {
                            vSocketChannel.pipeline().addLast(
                                    new HttpServerCodec(),
                                    new HttpObjectAggregator(1024),
                                    new WebSocketServerProtocolHandler(webSocketConfig.getRootPath()),
                                    s_ApplicationContext.getBean(WebSocketMessageTransferStation.class)
                            );
                        }
                    });

            tServerBootstrap.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 30);
            tServerBootstrap.bind(Integer.parseInt(m_Environment.getProperty("server.net.netty.port"))).sync();

            LOGGER.info("netty config succeed!!!123");
        } catch (Exception e) {
            LOGGER.error("netty start error", e);
            System.exit(-1);
        }
    }
}
