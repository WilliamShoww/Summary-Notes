package com.palm.core.net.websocket.config;

/**
 * Created by admin on 2018/12/27.
 * web socket 配置实体类
 */
public class WebSocketConfig {

    /**
     * web socket 的根路由uri
     */
    private String rootPath;
    /**
     * netty 的accepter 线程组线程数量
     */
    private Integer bossGroupThreadSize;
    /**
     * netty 的worker 线程组线程数量
     */
    private Integer workerGroupThreadSize;
    /**
     * XXT 加解密的KEY值
     */
    private String xxtKey;
    /**
     * 用户超时时长 单位：毫秒（ms）
     */
    private long sessionTimeOut;

    public String getRootPath() {
        return rootPath;
    }

    public void setRootPath(String rootPath) {
        this.rootPath = rootPath;
    }

    public Integer getBossGroupThreadSize() {
        return bossGroupThreadSize;
    }

    public void setBossGroupThreadSize(Integer bossGroupThreadSize) {
        this.bossGroupThreadSize = bossGroupThreadSize;
    }

    public Integer getWorkerGroupThreadSize() {
        return workerGroupThreadSize;
    }

    public void setWorkerGroupThreadSize(Integer workerGroupThreadSize) {
        this.workerGroupThreadSize = workerGroupThreadSize;
    }

    public String getXxtKey() {
        return xxtKey;
    }

    public void setXxtKey(String xxtKey) {
        this.xxtKey = xxtKey;
    }

    public long getSessionTimeOut() {
        return sessionTimeOut;
    }

    public void setSessionTimeOut(long sessionTimeOut) {
        this.sessionTimeOut = sessionTimeOut;
    }
}
