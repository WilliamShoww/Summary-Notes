package com.palm.core.net.websocket.perfect;

import com.palm.core.net.base.api.base.ICallBase;
import com.palm.core.net.base.api.net.IAcceptMessageBySession;
import com.palm.core.net.base.api.net.ISendMessageBySession;
import com.palm.core.net.base.model.MessageFromEnum;
import com.palm.core.net.base.model.MessagePackage;
import com.palm.core.net.websocket.model.SessionInfo;
import io.netty.buffer.ByteBuf;
import io.netty.channel.*;
import io.netty.handler.codec.http.websocketx.*;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.net.InetAddress;
import java.net.InetSocketAddress;

@Component
@ChannelHandler.Sharable
public class WebSocketMessageTransferStation extends SimpleChannelInboundHandler<WebSocketFrame> implements ISendMessageBySession {
    private static final Logger LOGGER = LoggerFactory.getLogger(WebSocketMessageTransferStation.class);

    @Autowired
    private IAcceptMessageBySession m_AcceptMessageBySession;

    @Autowired
    private SessionManager m_SessionManager;

    @Autowired
    private MessageCodec messageCodec;

    @Override
    public void channelActive(ChannelHandlerContext vChannelHandlerContext) throws Exception {
        Channel tChannel = vChannelHandlerContext.channel();
        long tCode = m_SessionManager.addSession(tChannel);
        LOGGER.info(String.format("channelActive Address=%s id=%s", ((InetSocketAddress) tChannel.remoteAddress()).getAddress(), tCode));
    }

    @Override
    public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
        LOGGER.info("handlerAdd!");
    }

    @Override
    public void handlerRemoved(ChannelHandlerContext vChannelHandlerContext) throws Exception {
        Channel tChannel = vChannelHandlerContext.channel();
        long tSessionId = m_SessionManager.invalidate(tChannel);
        m_AcceptMessageBySession.disconnect(tSessionId);
        tChannel.close();
        vChannelHandlerContext.close();
        LOGGER.info("remove!");
    }

    @Override
    public void channelInactive(ChannelHandlerContext vChannelHandlerContext) throws Exception {
        Channel tChannel = vChannelHandlerContext.channel();
        long tSessionId = m_SessionManager.invalidate(tChannel);
        LOGGER.info(String.format("channelInactive Address=%s id=%s", ((InetSocketAddress) tChannel.remoteAddress()).getAddress(), tSessionId));
    }

    @Override
    public void channelRead0(ChannelHandlerContext channelHandlerContext, WebSocketFrame webSocketFrame) {
        //判断是否是关闭链路的指令
        if (webSocketFrame instanceof CloseWebSocketFrame) {
            LOGGER.info("关闭链路");
            channelHandlerContext.pipeline().close();
            return;
        }
        //判断是否是ping消息
        if (webSocketFrame instanceof PingWebSocketFrame) {
	        LOGGER.info("pong");
            channelHandlerContext.channel().writeAndFlush(new PongWebSocketFrame(webSocketFrame.content().retain()));
            return;
        }
        MessagePackage msgPackage = messageCodec.decode(webSocketFrame.content().retain());
        if (msgPackage == null) {
	        LOGGER.info("=======msg decode error=======");
            return;
        }
        if (msgPackage.getCode() != 100001) {
	        LOGGER.info("Message Read Success!-->session:" + msgPackage.getSessionId() + "-->user:" + msgPackage.getUserId() + "-->code:" + msgPackage.getCode() + "-->request:" + msgPackage.getMessage());
        }
        SessionInfo tSessionInfo = m_SessionManager.getSessionInfo(channelHandlerContext.channel());

        dealMessage(tSessionInfo, msgPackage);

        m_SessionManager.action(channelHandlerContext.channel());
    }

    @Override
    public ChannelFuture send(MessagePackage vMessagePackage) {
        Channel tChannel = m_SessionManager.getChannel(vMessagePackage.getSessionId());
        if (null == tChannel)
            return null;
        ByteBuf byteBuf = null;
        try {
            byteBuf = messageCodec.encode(vMessagePackage);
        } catch (Exception e) {
            LOGGER.info("==========response msg error, code:" + vMessagePackage.getCode());
            e.printStackTrace();
        }
        if (null == byteBuf) {
            LOGGER.info("==========response msg encode buf error, code:" + vMessagePackage.getCode());
            return null;
        }
        BinaryWebSocketFrame out = new BinaryWebSocketFrame(byteBuf);
        return tChannel.writeAndFlush(out);
    }

    @Override
    public void send(final MessagePackage vMessagePackage, final ICallBase vCall) {
        Channel tChannel = m_SessionManager.getChannel(vMessagePackage.getSessionId());
        if (null == tChannel) {
            if (null != vCall)
                vCall.onCall(false);

            LOGGER.debug("msg send fail!!! not channel, vMessagePackage", vMessagePackage);
            return;
        }
        ByteBuf byteBuf = null;
        try {
            byteBuf = messageCodec.encode(vMessagePackage);
        } catch (Exception e) {
            LOGGER.info("==========response msg error, code:" + vMessagePackage.getCode());
            e.printStackTrace();
        }
        if (null == byteBuf) {
            LOGGER.info("==========response msg encode buf error, code:" + vMessagePackage.getCode());
            return;
        }
        BinaryWebSocketFrame out = new BinaryWebSocketFrame(byteBuf);
        ChannelFuture tChannelFuture = tChannel.writeAndFlush(out);
        tChannelFuture.addListener(new GenericFutureListener<Future<Void>>() {
            @Override
            public void operationComplete(Future<Void> vFuture) {
                if (null != vCall)
                    vCall.onCall(vFuture.isSuccess());

                if (false == vFuture.isSuccess())
                    LOGGER.warn("msg send fail!!! vMessagePackage", vMessagePackage, vFuture.cause());
            }
        });
    }

    @Override
    public void resetOrder(long vSessionId) {
        m_SessionManager.resetOrder(vSessionId);
    }

    @Override
    public InetAddress getAddress(long vSessionId) {
        Channel tChannel = m_SessionManager.getChannel(vSessionId);
        if (null == tChannel)
            return null;

        return ((InetSocketAddress) tChannel.remoteAddress()).getAddress();
    }

    @Override
    public void kickSession(long vSessionId) {
        Channel tChannel = m_SessionManager.getChannel(vSessionId);
        if (null != tChannel)
            tChannel.close();
    }

    private void dealMessage(SessionInfo vSessionInfo, MessagePackage vMessagePackage) {
        vMessagePackage.setSessionId(vSessionInfo.getSessionId());
        m_AcceptMessageBySession.accept(vMessagePackage, MessageFromEnum.NORMAL);
    }
}
