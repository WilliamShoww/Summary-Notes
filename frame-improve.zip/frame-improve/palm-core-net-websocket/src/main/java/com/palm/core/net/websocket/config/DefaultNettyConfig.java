package com.palm.core.net.websocket.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by admin on 2018/12/27.
 * 默认配置
 */
@Configuration
public class DefaultNettyConfig {

    /**
     * 默认配置
     *
     * @return
     */
    @Bean
    @ConditionalOnMissingBean(WebSocketConfig.class)
    public WebSocketConfig webSocketConfig() {
        WebSocketConfig config = new WebSocketConfig();
        config.setRootPath("/sglhz");
        config.setBossGroupThreadSize(16);
        config.setWorkerGroupThreadSize(16);
        config.setXxtKey("akiAABI668lh");
        config.setSessionTimeOut(600000L);
        return config;
    }
}
