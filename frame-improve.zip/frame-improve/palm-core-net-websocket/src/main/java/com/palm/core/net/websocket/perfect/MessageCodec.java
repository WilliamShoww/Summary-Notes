package com.palm.core.net.websocket.perfect;

import com.google.protobuf.Message;
import com.palm.core.net.base.api.utils.IMessageTransverter;
import com.palm.core.net.base.model.MessagePackage;
import com.palm.core.net.websocket.config.WebSocketConfig;
import com.palm.core.net.websocket.util.ByteUtil;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.xxtea.XXTEA;

/**
 * @author Hailuo
 * @Date: 2018/8/9 17:31
 * @Description： 处理消息
 * <p>
 * /**
 * request Frame Structure
 * ------------------- |<-----frame header part--->|<------------Response frame body part(repeatable)------------->|
 * ---------------------------------------------------------------------------------------------------------------------------
 * |SessionId | No.1 Msg Type | No.1 Msg Body
 * ---------------------------------------------------------------------------------------------------------------------------
 * |<--1int-->|<--1 int ----->|<---byte []--->|
 * <p>
 * <p>
 * response Frame Structure
 * ------------------- |<-----frame header part--->|<------------Response frame body part(repeatable)------------->|
 * ---------------------------------------------------------------------------------------------------------------------------
 * |SessionId | No.1 Msg Type | No.1 Msg Body
 * ---------------------------------------------------------------------------------------------------------------------------
 * |<--1int-->|<--1 int ----->|<---byte []--->|
 */
@Component
public class MessageCodec {

    private final Logger m_Logger = LoggerFactory.getLogger(MessageCodec.class);

    @Autowired
    private WebSocketConfig webSocketConfig;
    @Autowired
    private IMessageTransverter m_MessageTransverter;

    /**
     * 解码
     *
     * @param vByteBuf 消息体内容
     * @return
     */
    public MessagePackage decode(ByteBuf vByteBuf) {
        byte[] bytes = new byte[vByteBuf.readableBytes()];
        vByteBuf.getBytes(0, bytes);
        //m_Logger.info("message:"+ Arrays.toString(bytes));
        if (vByteBuf.readableBytes() < 8) {
            m_Logger.error("消息长度不对！" + vByteBuf.readableBytes());
            return null;
        }

        vByteBuf.markReaderIndex();
        int sessionId = ByteUtil.readInt(vByteBuf);
        int msgType = ByteUtil.readInt(vByteBuf);
        int msgLen = vByteBuf.readableBytes();

        byte[] messageBody = new byte[msgLen];
        ByteBuf tempByte = vByteBuf.readBytes(msgLen);
        tempByte.getBytes(0, messageBody);
        vByteBuf.release();
        byte[] msg = XXTEA.decrypt(messageBody, webSocketConfig.getXxtKey());
        Message tMessage = null;
        try {
            tMessage = m_MessageTransverter.decode(msgType, msg);
            if (null == tMessage) {
                m_Logger.error("msg decode error!--->msgType:" + msgType);
                vByteBuf.clear();
                return null;
            }
        } catch (Exception e) {
            m_Logger.error("msg decode error!--->msgType:" + msgType);
            e.printStackTrace();
        } finally {
            tempByte.release();
        }
        if (null == tMessage) {
            m_Logger.error("msg decode error!");
            vByteBuf.clear();
            return null;
        }
        return new MessagePackage(tMessage, msgType, sessionId, 0L);
    }


    /**
     * 编码
     *
     * @param responseMsg 响应的消息体
     * @return
     * @throws Exception
     */
    public ByteBuf encode(MessagePackage responseMsg) throws Exception {
        int sessionId = (int) responseMsg.getSessionId();
        int msgType = (int) m_MessageTransverter.getCode(responseMsg.getMessage());
        if (null == responseMsg.getMessage()) {
            m_Logger.info("=======msg class not exist=======,msg code: " + msgType);
            return null;
        }
        if (msgType != 100002) {
            m_Logger.info("msgType:" + msgType + "-->response:\n" + responseMsg.getMessage());
        }
        byte[] responseBody = XXTEA.encrypt(responseMsg.getMessage().toByteArray(), webSocketConfig.getXxtKey());
        ByteBuf buf = Unpooled.buffer();
        ByteUtil.writeInt(buf, sessionId);
        ByteUtil.writeInt(buf, msgType);
        buf.writeBytes(responseBody);
        return buf;
    }
}
