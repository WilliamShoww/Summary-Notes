package com.palm.core.net.websocket.perfect;

import com.palm.core.net.websocket.config.WebSocketConfig;
import com.palm.core.net.websocket.model.SessionInfo;
import io.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 会话管理器
 */
@Component
public class SessionManager {

    @Autowired
    private WebSocketConfig webSocketConfig;

    private Map<Long, SessionInfo> m_SessionInfoMap = new ConcurrentHashMap();

    private Timer m_SessionOutTimer = new Timer();      //会话超时清理定时器
    private static final Logger LOG = LoggerFactory.getLogger(SessionManager.class);

    @PostConstruct
    public void init() {
        m_SessionOutTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                //TODO 变量提出
                for (SessionInfo tSessionInfo : m_SessionInfoMap.values()) {
                    if (webSocketConfig.getSessionTimeOut() <= System.currentTimeMillis() - tSessionInfo.getLastDate()) {
                        tSessionInfo.getChannel().close();
                        LOG.info("会话超时！---》" + tSessionInfo.getSessionId() + "--->time:" + tSessionInfo.getLastDate() + "---->now:" + System.currentTimeMillis());
                        //让会话回掉去销毁
//                        m_SessionInfoMap.remove(tSessionInfo.getSessionId());
                    }
                }
            }
        }, 1000, 1000);
    }


    @PreDestroy
    public void uninit() {
        m_SessionOutTimer.cancel();
    }

    public long addSession(Channel vChannel) {
        Long tSessionId = getOrCreateSessionIdByChannel(vChannel);
        m_SessionInfoMap.put(tSessionId, new SessionInfo(tSessionId, vChannel));
        return tSessionId;
    }

    public Channel getChannel(long vSessionId) {
        SessionInfo tSessionInfo = m_SessionInfoMap.get(vSessionId);
        if (null == tSessionInfo)
            return null;

        return tSessionInfo.getChannel();
    }

    public Long getSessionId(Channel vChannel) {
        long tSessionId = getOrCreateSessionIdByChannel(vChannel);
        return false == m_SessionInfoMap.containsKey(tSessionId) ? null : tSessionId;
    }

    public SessionInfo getSessionInfo(Channel vChannel) {
        return getSessionInfo(getOrCreateSessionIdByChannel(vChannel));
    }

    public SessionInfo getSessionInfo(long vSessionId) {
        return m_SessionInfoMap.get(vSessionId);
    }

    public boolean isAction(long vSessionId) {
        return m_SessionInfoMap.containsKey(vSessionId);
    }

    public void action(long vSessionId) {
        SessionInfo tSessionInfo = m_SessionInfoMap.get(vSessionId);
        if (null == tSessionInfo)
            return;

        tSessionInfo.setLastDate(System.currentTimeMillis());
    }

    public void action(Channel vChannel) {
        SessionInfo tSessionInfo = m_SessionInfoMap.get(getOrCreateSessionIdByChannel(vChannel));
        if (null == tSessionInfo)
            return;

        tSessionInfo.setLastDate(System.currentTimeMillis());
    }

    public void invalidate(long vSessionId) {
        SessionInfo tSessionInfo = m_SessionInfoMap.remove(vSessionId);
        if (null != tSessionInfo)
            tSessionInfo.getChannel().close();
    }

    public long invalidate(Channel vChannel) {
        SessionInfo tSessionInfo = m_SessionInfoMap.remove(getOrCreateSessionIdByChannel(vChannel));
        if (null != tSessionInfo) {
            tSessionInfo.getChannel().close();
            return tSessionInfo.getSessionId();
        }
        return 0;
    }

    public void resetOrder(long vSessionId) {
        SessionInfo tSessionInfo = m_SessionInfoMap.get(vSessionId);
        if (null != tSessionInfo)
            tSessionInfo.resetOrder();
    }

    public long getOrder(long vSessionId) {
        SessionInfo tSessionInfo = m_SessionInfoMap.get(vSessionId);
        return null == tSessionInfo ? -1 : tSessionInfo.getOrder();
    }

    private long getOrCreateSessionIdByChannel(Channel vChannel) {
        return (long) vChannel.hashCode();
    }
}
