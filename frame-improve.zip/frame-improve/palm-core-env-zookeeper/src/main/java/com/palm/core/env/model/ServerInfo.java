package com.palm.core.env.model;

public class ServerInfo {
    private String  m_ServerId;
    private String  m_ServerIp;
    private int     m_ServerPort;
    private String  m_ServerMode;
    private String  m_ServerCode;
    private String  m_ServerNote;
    private boolean m_Action;

    public ServerInfo(String vServerIp, int vServerPort, String vServerMode, String vServerCode, String vServerNote) {
        m_ServerIp = vServerIp;
        m_ServerPort = vServerPort;
        m_ServerMode = vServerMode;
        m_ServerCode = vServerCode;
        m_ServerNote = vServerNote;
        m_ServerId = vServerMode+vServerCode;
    }

    public ServerInfo() {
    }

    public void setServerIp(String vServerIp) {
        m_ServerIp = vServerIp;
    }

    public void setServerPort(int vServerPort) {
        m_ServerPort = vServerPort;
    }

    public void setServerMode(String vServerMode) {
        m_ServerMode = vServerMode;
    }

    public void setServerCode(String vServerCode) {
        m_ServerCode = vServerCode;
    }

    public void setServerNote(String vServerNote) {
        m_ServerNote = vServerNote;
    }

    public void setServerId(String vServerId) {
        m_ServerId = vServerId;
    }

    public void setAction(boolean vAction) {
        m_Action = vAction;
    }

    public String getServerIp() {
        return m_ServerIp;
    }

    public int getServerPort() {
        return m_ServerPort;
    }

    public String getServerMode() {
        return m_ServerMode;
    }

    public String getServerCode() {
        return m_ServerCode;
    }

    public String getServerNote() {
        return m_ServerNote;
    }

    public String getServerId() {
        return m_ServerId;
    }

    public boolean isAction() {
        return m_Action;
    }
}
