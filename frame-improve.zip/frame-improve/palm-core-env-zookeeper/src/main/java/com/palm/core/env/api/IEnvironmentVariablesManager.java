package com.palm.core.env.api;

public interface IEnvironmentVariablesManager {
    public boolean setDefaultValueToInt    (int vValue,        String ...vS);
    public boolean setDefaultValueToBool   (boolean vValue,    String ...vS);
    public boolean setDefaultValue         (String vValue,     String ...vS);

    public boolean setVersionValueByInt     (String vVersion, int vValue,        String ...vS);
    public boolean setVersionValueByBool    (String vVersion, boolean vValue,    String ...vS);
    public boolean setVersionValue          (String vVersion, String vValue,     String ...vS);

    public Integer  getVersionValueToInt    (String vVersion, String ...vS);
    public Boolean  getVersionValueToBool   (String vVersion, String ...vS);
    public String   getVersionValue         (String vVersion, String ...vS);

    public Integer  getDefaultValueToInt    (String ...vS);
    public Boolean  getDefaultValueToBool   (String ...vS);
    public String   getDefaultValue         (String ...vS);

    public boolean  removeVersionValue  (String vVersion, String ...vS);
    public boolean  removeDefaultValue  (String ...vS);

    public boolean  createVersionValue  (String vVersion, String ...vS);
    public boolean  createDefaultValue  (String ...vS);
}
