package com.palm.core.env.api;

public interface IEnvironmentVariablesTable {
    public Integer  getCurValueToInt    (String vName);
    public Boolean  getCurValueToBool   (String vName);
    public String   getCurValueToString (String vName);
    public byte[]   getCurValue         (String vName);

    public IEnvironmentVariablesTable getChild(String vPath);
}