package com.palm.core.env.perfect;

import com.palm.common.kit.DataKit;
import com.palm.common.kit.PathKit;
import com.palm.core.env.api.IEnvironmentVariablesManager;
import org.apache.curator.framework.CuratorFramework;
import org.apache.zookeeper.CreateMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

//TODO
//@Component
public class EnvironmentVariablesManager implements IEnvironmentVariablesManager{
    private final static byte[] DEFAULT_DATA = new byte[0];

    @Autowired
    private CuratorFramework m_RootCuratorFramework;

    private CuratorFramework m_DefaultCuratorFramework;
    private CuratorFramework m_VersionCuratorFramework;

    @PostConstruct
    public void init(){
        m_DefaultCuratorFramework = m_RootCuratorFramework.usingNamespace("default");
        m_VersionCuratorFramework = m_RootCuratorFramework.usingNamespace("version");
    }

    @Override
    public boolean setDefaultValueToInt(int vValue, String... vS) {
        return setDefaultValue(PathKit.joint(vS), DataKit.getBytes(vValue));
    }

    @Override
    public boolean setDefaultValueToBool(boolean vValue, String... vS) {
        return setDefaultValue(PathKit.joint(vS), DataKit.getBytes(vValue));
    }

    @Override
    public boolean setDefaultValue(String vValue, String... vS) {
        return setDefaultValue(PathKit.joint(vS), DataKit.getBytes(vValue));
    }

    @Override
    public boolean setVersionValueByInt(String vVersion, int vValue, String... vS) {
        return setDefaultValue(PathKit.joint(vS), DataKit.getBytes(vValue));
    }

    @Override
    public boolean setVersionValueByBool(String vVersion, boolean vValue, String... vS) {
        return setDefaultValue(PathKit.joint(vS), DataKit.getBytes(vValue));
    }

    @Override
    public boolean setVersionValue(String vVersion, String vValue, String... vS) {
        return setDefaultValue(PathKit.joint(vS), DataKit.getBytes(vValue));
    }

    @Override
    public Integer getVersionValueToInt(String vVersion, String... vS) {
        return null;
    }

    @Override
    public Boolean getVersionValueToBool(String vVersion, String... vS) {
        return null;
    }

    @Override
    public String getVersionValue(String vVersion, String... vS) {
        return null;
    }

    @Override
    public Integer getDefaultValueToInt(String... vS) {
        return null;
    }

    @Override
    public Boolean getDefaultValueToBool(String... vS) {
        return null;
    }

    @Override
    public String getDefaultValue(String... vS) {
        return null;
    }

    @Override
    public boolean removeVersionValue(String vVersion, String... vS) {
        return false;
    }

    @Override
    public boolean removeDefaultValue(String... vS) {
        return false;
    }

    @Override
    public boolean createVersionValue(String vVersion, String... vS) {
        return false;
    }

    @Override
    public boolean createDefaultValue(String... vS) {
        return createVersionValue(PathKit.joint(vS));
    }

    private boolean createVersionValue(String vPath, boolean vIsTemporary){
        try {
            m_VersionCuratorFramework.create().creatingParentsIfNeeded().withMode(vIsTemporary ? CreateMode.EPHEMERAL : CreateMode.PERSISTENT).forPath(vPath);
            return true;
        } catch (Exception vE) {
            vE.printStackTrace();
            return false;
        }
    }

    private boolean setDefaultValue(String vPath, byte[] vData){
        try {
            m_DefaultCuratorFramework.setData().forPath(vPath, vData);
            return true;
        } catch (Exception vE) {
            vE.printStackTrace();
            return false;
        }
    }

    private byte[] getDefaultValue(String vPath){
        try {
            return m_DefaultCuratorFramework.getData().forPath(vPath);
        } catch (Exception vE) {
            vE.printStackTrace();
            return null;
        }
    }

    private boolean removeDefaultValue(String vPath){
        try {
            m_DefaultCuratorFramework.delete().deletingChildrenIfNeeded().forPath(vPath);
            return true;
        } catch (Exception vE) {
            vE.printStackTrace();
            return false;
        }
    }

    private boolean setVersionValue(String vVersion, String vPath, byte[] vData){
        try {
            m_VersionCuratorFramework.create().creatingParentsIfNeeded().forPath(PathKit.joint(vVersion, vPath), vData);
            return true;
        } catch (Exception vE) {
            vE.printStackTrace();
            return false;
        }
    }

    private byte[] getVersionValue(String vVersion, String vPath){
        try {
            return m_VersionCuratorFramework.getData().forPath(PathKit.joint(vVersion, vPath));
        } catch (Exception vE) {
            vE.printStackTrace();
            return null;
        }
    }

    private boolean removeVersionValue(String vVersion, String vPath){
        try {
            m_VersionCuratorFramework.delete().deletingChildrenIfNeeded().forPath(PathKit.joint(vVersion, vPath));
            return true;
        } catch (Exception vE) {
            vE.printStackTrace();
            return false;
        }
    }
}
