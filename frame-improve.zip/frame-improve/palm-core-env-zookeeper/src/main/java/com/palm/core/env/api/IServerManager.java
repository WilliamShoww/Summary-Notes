package com.palm.core.env.api;

import com.palm.core.env.model.ServerInfo;

import java.util.List;

public interface IServerManager {
    //服务器注册
    public int register(ServerInfo vServerInfo);

    //用户绑定
    public int binding(String vServerId, long vUserId);

    //用户解绑
    public int unbinding(String vServerId, long vUserId);

    //获取服务器信息
    public ServerInfo getServerInfo(String vServerId);

    //添加服务挂掉监听
    public void addListener(IServerLifeListener vServerLifeListener);

    //获取服务器下玩家列表
    public List<Long> getUserIdList(String vServerId);

    //通玩家获取服务器信息
    public ServerInfo getFromUserId(String vServerModel, long vUserId);

    //获取服务群
    public List<ServerInfo> getServerInfoList(String vServerModel);

    //服务器替换
    public int replaceServer(String vOldServerId, String vNewServerId);
}
