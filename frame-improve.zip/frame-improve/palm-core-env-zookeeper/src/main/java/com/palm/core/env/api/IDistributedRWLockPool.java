package com.palm.core.env.api;

import com.palm.common.kit.AutoLock;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;

public interface IDistributedRWLockPool {
    public ReadWriteLock getReadWriteLock(String vLockName);

    public Lock getReadLock(String vLockName);

    public Lock getWriteLock(String vLockName);

    public AutoLock getAutoReadLock(String vLockName);

    public AutoLock getAutoWriteLock(String vLockName);

    public void discard(String vLockName);

    public IDistributedRWLockPool getChild(String vChildName);
}
