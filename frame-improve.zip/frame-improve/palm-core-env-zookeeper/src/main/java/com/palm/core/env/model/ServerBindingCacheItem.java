package com.palm.core.env.model;

import com.palm.common.kit.OvonicListTable;
import org.apache.curator.framework.recipes.cache.PathChildrenCache;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ServerBindingCacheItem {
    private String                        m_ServerMode;
    private PathChildrenCache             m_PathChildrenCache;

    private OvonicListTable<String, Long> m_UserIdList      = new OvonicListTable();
    private List<String>                  m_ServerIdList    = new CopyOnWriteArrayList();

    public String getServerMode() {
        return m_ServerMode;
    }

    public void setServerMode(String vServerMode) {
        m_ServerMode = vServerMode;
    }

    public PathChildrenCache getPathChildrenCache() {
        return m_PathChildrenCache;
    }

    public void setPathChildrenCache(PathChildrenCache vPathChildrenCache) {
        m_PathChildrenCache = vPathChildrenCache;
    }

    public OvonicListTable<String, Long> getUserIdList() {
        return m_UserIdList;
    }

    public void setUserIdList(OvonicListTable<String, Long> vUserIdList) {
        m_UserIdList = vUserIdList;
    }

    public List<String> getServerIdList() {
        return m_ServerIdList;
    }

    public void setServerIdList(List<String> vServerIdList) {
        m_ServerIdList = vServerIdList;
    }
}
