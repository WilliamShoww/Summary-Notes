package com.palm.core.env.model;

import org.apache.curator.framework.recipes.locks.InterProcessReadWriteLock;

import java.util.concurrent.locks.ReadWriteLock;

public class RemoteReadWriteLock implements ReadWriteLock{
    private RemoteLock m_ReadRemoteLock;
    private RemoteLock m_WriteRemoteLock;

    public RemoteReadWriteLock(InterProcessReadWriteLock vInterProcessReadWriteLock) {
        m_ReadRemoteLock    = new RemoteLock(vInterProcessReadWriteLock.readLock());
        m_WriteRemoteLock   = new RemoteLock(vInterProcessReadWriteLock.writeLock());
    }

    @Override
    public RemoteLock readLock() {
        return m_ReadRemoteLock;
    }

    @Override
    public RemoteLock writeLock() {
        return m_WriteRemoteLock;
    }
}