package com.palm.core.env.enums;

public class ErrorCode {
}
