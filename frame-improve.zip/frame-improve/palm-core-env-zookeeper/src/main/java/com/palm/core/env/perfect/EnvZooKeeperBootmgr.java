package com.palm.core.env.perfect;

import com.palm.common.kit.PathKit;
import com.palm.core.env.api.IDistributedLockPool;
import com.palm.core.env.api.IDistributedRWLockPool;
import com.palm.core.env.api.IEnvironmentVariablesTable;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.RetryNTimes;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

@Component
public class EnvZooKeeperBootmgr{
    private CuratorFramework            m_RootCuratorFramework;
    private CuratorFramework            m_ServerRootCuratorFramework;
    private DistributedLockPool         m_DistributedLockPool;
    private DistributedRWLockPool       m_DistributedRWLockPool;
    private EnvironmentVariablesTable   m_EnvironmentVariablesTable;

    @Value("${server.env.connect.address:127.0.0.1:2181}")
    private String m_Address;

    @Value("${server.env.connect.retries:3}")
    private int m_Retries;

    @Value("${server.env.connect.await:10}")
    private int m_Await;

    @Value("${server.env.server.version:0.0.1}")
    private String m_Version;

    @Value("${server.env.server.root:server}")
    private String m_ServerRootPath;

    @PostConstruct
    public void init(){
        m_RootCuratorFramework = CuratorFrameworkFactory.newClient(m_Address, new RetryNTimes(m_Retries, m_Await));
        m_RootCuratorFramework.start();
    }

    @PreDestroy
    public void uninit(){
        if(null != m_RootCuratorFramework)
            m_RootCuratorFramework.close();
    }

    @Bean
    public CuratorFramework getCuratorFramework(){
        m_ServerRootCuratorFramework = m_RootCuratorFramework.usingNamespace(PathKit.joint(m_ServerRootPath, "palm"));
        return m_ServerRootCuratorFramework;
    }

    @Bean
    public IDistributedLockPool getDistributedLockPool(){
        m_DistributedLockPool = new DistributedLockPool(m_RootCuratorFramework.usingNamespace(PathKit.joint(m_ServerRootPath, "lock")));
        return m_DistributedLockPool;
    }

    @Bean
    public IDistributedRWLockPool getDistributedRWLockPool(){
        m_DistributedRWLockPool = new DistributedRWLockPool(m_RootCuratorFramework.usingNamespace(PathKit.joint(m_ServerRootPath, "rwLock")));
        return m_DistributedRWLockPool;
    }

    @Bean
    public IEnvironmentVariablesTable getEnvironmentVariablesTable() throws Exception {
        CuratorFramework tDefault = m_RootCuratorFramework.usingNamespace(PathKit.joint(m_ServerRootPath, "env", "default"));
        CuratorFramework tVersion = m_RootCuratorFramework.usingNamespace(PathKit.joint(m_ServerRootPath, "env", "version", m_Version));
        m_EnvironmentVariablesTable = new EnvironmentVariablesTable(tDefault, tVersion);
        return m_EnvironmentVariablesTable;
    }
}
