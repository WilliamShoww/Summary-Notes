package com.palm.core.env.api;

import com.palm.common.kit.AutoLock;

import java.util.concurrent.locks.Lock;

public interface IDistributedLockPool {
    public Lock getLock(String vLockName);

    public AutoLock getAutoLock(String vLockName);

    public void discard(String vLockName);

    public IDistributedLockPool getChild(String vChildName);
}
