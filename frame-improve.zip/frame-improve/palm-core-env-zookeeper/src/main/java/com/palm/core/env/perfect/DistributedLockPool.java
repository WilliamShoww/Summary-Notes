package com.palm.core.env.perfect;

import com.palm.common.kit.AutoLock;
import com.palm.common.kit.PathKit;
import com.palm.core.env.api.IDistributedLockPool;
import com.palm.core.env.model.RemoteLock;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.locks.InterProcessMutex;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;

/**
 * 分布式锁池 （最简单设计）
 */
public class DistributedLockPool implements IDistributedLockPool {
    private CuratorFramework m_RootCuratorFramework;

    private Map<String, RemoteLock> m_RemoteLockMap = new HashMap();

    public DistributedLockPool(CuratorFramework vRootCuratorFramework) {
        m_RootCuratorFramework = vRootCuratorFramework;
    }

    @Override
    public Lock getLock(String vLockName) {
        return getRemoteLock(vLockName);
    }

    @Override
    public AutoLock getAutoLock(String vLockName) {
        return new AutoLock(getRemoteLock(vLockName));
    }

    @Override
    public IDistributedLockPool getChild(String vChildName) {
        return new DistributedLockPool(m_RootCuratorFramework.usingNamespace(PathKit.joint(m_RootCuratorFramework.getNamespace(), vChildName)));
    }

    @Override
    public synchronized void discard(String vLockName){
        removeRemoteLock(vLockName);
    }

    private synchronized RemoteLock getRemoteLock(String vLockName){
        RemoteLock tRemoteLock = m_RemoteLockMap.get(vLockName);
        if(null == tRemoteLock){
            tRemoteLock = new RemoteLock(new InterProcessMutex(m_RootCuratorFramework, PathKit.jointRapid("/", vLockName)));
            m_RemoteLockMap.put(vLockName, tRemoteLock);
        }

        return tRemoteLock;
    }

    private synchronized void removeRemoteLock(String vLockName){
        m_RemoteLockMap.remove(vLockName);
    }
}
