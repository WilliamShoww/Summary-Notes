package com.palm.core.env.perfect;

import com.alibaba.fastjson.JSONObject;
import com.palm.common.kit.DataKit;
import com.palm.common.kit.OvonicListTable;
import com.palm.common.kit.PathKit;
import com.palm.core.env.api.IServerLifeListener;
import com.palm.core.env.api.IServerManager;
import com.palm.core.env.model.ServerInfo;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheListener;
import org.apache.curator.framework.recipes.cache.TreeCache;
import org.apache.zookeeper.CreateMode;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * 粗略未完成，等待优化
 */
public class ServerManager implements IServerManager, AutoCloseable{
    private Set<IServerLifeListener> m_ServerLifeListenerList = Collections.newSetFromMap(new ConcurrentHashMap());

    private TreeCache           m_BindingCache;
    private CuratorFramework    m_ServerRootCurator;
    private CuratorFramework    m_BindingRootCurator;
    private PathChildrenCache   m_ServerCache;

    private Map<String, ServerBindingCacheItem> m_ModeServerCache = new ConcurrentHashMap();

    private Map<String, ServerInfo> m_ServerMap     = new ConcurrentHashMap();
    private Map<String, ServerInfo> m_DieServerMap  = new ConcurrentHashMap();

    public ServerManager(CuratorFramework vServerRootCurator, CuratorFramework vBindingRootCurator) throws Exception {
        m_ServerRootCurator = vServerRootCurator;
        m_BindingRootCurator = vBindingRootCurator;

        m_ServerCache = new PathChildrenCache(vServerRootCurator, "/", false);
        m_ServerCache.getListenable().addListener(new ServerLifeListener());
        m_ServerCache.start();

        m_BindingCache = new TreeCache(vBindingRootCurator, "/");
        m_BindingCache.start();
    }

    @Override
    public void close() throws Exception {
        if(null != m_BindingCache) m_BindingCache.close();
        if(null != m_ServerCache) m_ServerCache.close();
    }

    /**
     * 思路：
     *      服务器注册
     *          1、先查询是否有相同节点在运行
     *          2、校验 创建服务器信息到节点
     *          3、将服务器节点打入运行节点
     */
    @Override
    public int register(ServerInfo vServerInfo) {
        try {
            m_ServerRootCurator.create().creatingParentsIfNeeded().withMode(CreateMode.EPHEMERAL).forPath(vServerInfo.getServerId(), JSONObject.toJSONBytes(vServerInfo));
            return 0;
        } catch (Exception vE) {
            vE.printStackTrace();
            return -1;
        }
    }

    /**
     * 思路：
     *      玩家服务器绑定
     *          1、判断该服务器是否真的存在 并获取服务器信息（可能因服务器初次启动，无法拿到服务器信息，但Id亦是通过缓存获取，则可在一定程度上忽略）
     *          2、简单粗暴，直接写模块玩家节点数据为服务器Id 失败则表示该玩家已绑定固定服务器 成功则表示未绑定
     */
    @Override
    public int binding(String vServerId, long vUserId) {
        ServerInfo tServer = getServer(vServerId);
        if(null == tServer)
            return -1;

        try {
            m_BindingRootCurator.create().creatingParentsIfNeeded().forPath(PathKit.joint(tServer.getServerMode(), vUserId+""), DataKit.getBytes(vServerId));
            return 0;
        } catch (Exception vE) {
            vE.printStackTrace();
            return -1;
        }
    }

    /**
     * 思路：
     *      玩家服务器解绑
     *          1、判断服务器是否真的存在 获取服务器信息
     *          2、判断是否真的绑定对应，若对应则删除（远程锁判定）
     */
    @Override
    public int unbinding(String vServerId, long vUserId) {
        ServerInfo tServer = getServer(vServerId);
        if(null == tServer)
            return -1;

        try {
            m_BindingRootCurator.delete().forPath(PathKit.joint(tServer.getServerMode(), vUserId+""));
            return 0;
        } catch (Exception vE) {
            vE.printStackTrace();
            return -1;
        }
    }

    /**
     * 获取服务器信息（公有私有方法分开，公有直接调私有方法）
     */
    @Override
    public ServerInfo getServerInfo(String vServerId) {
        return getServer(vServerId);
    }

    /**
     * 添加服务器周期监听器
     */
    @Override
    public void addListener(IServerLifeListener vServerLifeListener) {
        m_ServerLifeListenerList.add(vServerLifeListener);
    }

    /**
     * 获取服务器绑定玩家列表
     */
    @Override
    public List<Long> getUserIdList(String vServerId) {
        ServerInfo tServer = getServer(vServerId);
        if(null == tServer)
            return null;

        return getServerBindingCacheItem(tServer.getServerMode()).getUserIdBindingCache().getValueList(vServerId);
    }

    /**
     * 获取玩家某功能模块绑定的服务器
     */
    @Override
    public ServerInfo getFromUserId(String vServerModel, long vUserId) {
        String tServerId = getServerBindingCacheItem(vServerModel).getUserIdBindingCache().getKey(vUserId);
        if(null == tServerId)
            return null;

        return getServer(tServerId);
    }

    /**
     * 获取某服务器某块对应服务器表
     */
    @Override
    public List<ServerInfo> getServerInfoList(String vServerModel) {
        List<ServerInfo> tResult = new ArrayList();
        for (String tServerId : getServerBindingCacheItem(vServerModel).getServerIdList()) {
            tResult.add(getServerInfo(vServerModel));
        }

        return tResult;
    }

    /**
     * 将某服务器所有玩家指向另一服务器
     */
    @Override
    public int replaceServer(String vOldServerId, String vNewServerId) {
        throw new RuntimeException("未实现");
    }

    private ServerInfo getServer(String vServerId){
        ServerInfo tServerInfo = m_ServerMap.get(vServerId);
        if(null == tServerInfo)
            tServerInfo = m_DieServerMap.get(vServerId);

        return tServerInfo;
    }

    private ServerBindingCacheItem getServerBindingCacheItem(String vServerMode){
        ServerBindingCacheItem tServerBindingCacheItem = m_ModeServerCache.get(vServerMode);
        if(null == tServerBindingCacheItem) {
            tServerBindingCacheItem = new ServerBindingCacheItem();
            m_ModeServerCache.put(vServerMode, tServerBindingCacheItem);
        }
        return tServerBindingCacheItem;
    }

    private class ServerLifeListener implements PathChildrenCacheListener{
        @Override
        public void childEvent(CuratorFramework vFramework, PathChildrenCacheEvent vEvent) throws Exception {
            if(PathChildrenCacheEvent.Type.CHILD_ADDED == vEvent.getType()){
                ServerInfo tServerInfo = JSONObject.parseObject(vEvent.getData().getData(), ServerInfo.class);
                String tServerId = vEvent.getData().getPath();
                m_ServerMap.put(tServerId, tServerInfo);
                m_DieServerMap.remove(tServerId);
                for (IServerLifeListener tServerLifeListener : m_ServerLifeListenerList)
                    tServerLifeListener.onBirth(tServerInfo);
            }

            if(PathChildrenCacheEvent.Type.CHILD_REMOVED == vEvent.getType()) {
                String tServerId = vEvent.getData().getPath();
                ServerInfo tServerInfo = m_ServerMap.get(tServerId);

                for (IServerLifeListener tServerLifeListener : m_ServerLifeListenerList)
                    tServerLifeListener.onDie(tServerInfo);

                m_ServerMap.remove(tServerId);
                m_DieServerMap.put(tServerId, tServerInfo);
            }
        }
    }

    public class ServerBindingCacheItem{
        private String                        m_ServerMode;
        private PathChildrenCache             m_PathChildrenCache;
        private OvonicListTable<String, Long> m_UserIdBindingCache  = new OvonicListTable();
        private List<String>                  m_ServerIdList        = new CopyOnWriteArrayList();

        public String getServerMode() {
            return m_ServerMode;
        }

        public PathChildrenCache getPathChildrenCache() {
            return m_PathChildrenCache;
        }

        public OvonicListTable<String, Long> getUserIdBindingCache() {
            return m_UserIdBindingCache;
        }

        public List<String> getServerIdList() {
            return m_ServerIdList;
        }
    }
}