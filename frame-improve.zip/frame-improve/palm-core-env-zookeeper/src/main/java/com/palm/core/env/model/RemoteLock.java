package com.palm.core.env.model;

import org.apache.curator.framework.recipes.locks.InterProcessMutex;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class RemoteLock implements Lock{
    private InterProcessMutex m_InterProcessMutex;

    public RemoteLock(InterProcessMutex vInterProcessMutex) {
        m_InterProcessMutex = vInterProcessMutex;
    }

    @Override
    public void lock() {
        try {
            m_InterProcessMutex.acquire();
        } catch (Exception vE) {
            throw new RuntimeException(vE);
        }
    }

    @Override
    @Deprecated
    public void lockInterruptibly() throws InterruptedException {
        throw new RuntimeException();
    }

    @Override
    public boolean tryLock() {
        try {
            return m_InterProcessMutex.acquire(0, TimeUnit.MICROSECONDS);
        } catch (Exception vE) {
            throw new RuntimeException(vE);
        }
    }

    @Override
    public boolean tryLock(long vTime, TimeUnit vTimeUnit) throws InterruptedException {
        try {
            return m_InterProcessMutex.acquire(vTime, vTimeUnit);
        } catch (Exception vE) {
            throw new RuntimeException(vE);
        }
    }

    @Override
    public void unlock() {
        try {
            if(true == m_InterProcessMutex.isAcquiredInThisProcess())
                m_InterProcessMutex.release();
        } catch (Exception vE) {
            throw new RuntimeException(vE);
        }
    }

    @Override
    @Deprecated
    public Condition newCondition() {
        throw new RuntimeException();
    }
}
