package com.palm.core.env.api;

public interface IPathManager {
    public String getPathByVersion(String vPath, String vVersion);
    public String getPathByDefault(String vPath);
}
