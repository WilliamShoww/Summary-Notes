package com.palm.core.env.api;

import com.palm.core.env.model.ServerInfo;

public interface IServerLifeListener {
    public void onBirth(ServerInfo vServerInfo);

    public void onDie(ServerInfo vServerInfo);
}
