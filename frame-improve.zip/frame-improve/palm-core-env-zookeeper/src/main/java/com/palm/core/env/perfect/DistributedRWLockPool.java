package com.palm.core.env.perfect;

import com.palm.common.kit.AutoLock;
import com.palm.common.kit.PathKit;
import com.palm.core.env.api.IDistributedRWLockPool;
import com.palm.core.env.model.RemoteLock;
import com.palm.core.env.model.RemoteReadWriteLock;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.locks.InterProcessReadWriteLock;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;

/**
 * 分布式读写锁池 （最简单设计）
 */
public class DistributedRWLockPool implements IDistributedRWLockPool{
    private CuratorFramework m_RootCuratorFramework;

    private Map<String, RemoteReadWriteLock> m_RemoteReadWriteLockMap = new HashMap();

    public DistributedRWLockPool(CuratorFramework vRootCuratorFramework) {
        m_RootCuratorFramework = vRootCuratorFramework;
    }

    @Override
    public ReadWriteLock getReadWriteLock(String vLockName) {
        return getRemoteReadWriteLock(vLockName);
    }

    @Override
    public RemoteLock getReadLock(String vLockName) {
        return getRemoteReadWriteLock(vLockName).readLock();
    }

    @Override
    public RemoteLock getWriteLock(String vLockName) {
        return getRemoteReadWriteLock(vLockName).writeLock();
    }

    @Override
    public AutoLock getAutoReadLock(String vLockName) {
        return new AutoLock(getRemoteReadWriteLock(vLockName).readLock());
    }

    @Override
    public AutoLock getAutoWriteLock(String vLockName) {
        return new AutoLock(getRemoteReadWriteLock(vLockName).writeLock());
    }

    @Override
    public void discard(String vLockName) {
        removeRemoteLock(vLockName);
    }

    @Override
    public IDistributedRWLockPool getChild(String vChildName) {
        return new DistributedRWLockPool(m_RootCuratorFramework.usingNamespace(PathKit.joint(m_RootCuratorFramework.getNamespace(), vChildName)));
    }

    private synchronized RemoteReadWriteLock getRemoteReadWriteLock(String vLockName){
        RemoteReadWriteLock tRemoteReadWriteLock = m_RemoteReadWriteLockMap.get(vLockName);
        if(null == tRemoteReadWriteLock){
            tRemoteReadWriteLock = new RemoteReadWriteLock(new InterProcessReadWriteLock(m_RootCuratorFramework, PathKit.jointRapid("/", vLockName)));
            m_RemoteReadWriteLockMap.put(vLockName, tRemoteReadWriteLock);
        }

        return tRemoteReadWriteLock;
    }

    private synchronized void removeRemoteLock(String vLockName){
        m_RemoteReadWriteLockMap.remove(vLockName);
    }
}
