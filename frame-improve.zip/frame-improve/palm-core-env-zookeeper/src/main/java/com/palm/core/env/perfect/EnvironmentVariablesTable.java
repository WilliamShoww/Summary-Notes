package com.palm.core.env.perfect;

import com.palm.common.kit.DataKit;
import com.palm.common.kit.PathKit;
import com.palm.core.env.api.IEnvironmentVariablesTable;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.cache.ChildData;
import org.apache.curator.framework.recipes.cache.TreeCache;

public class EnvironmentVariablesTable implements IEnvironmentVariablesTable{
    private TreeCache m_DefaultCache;
    private TreeCache m_CurCache;

    public EnvironmentVariablesTable(CuratorFramework vDefaultClient, CuratorFramework vCurClient) throws Exception {
        m_DefaultCache = new TreeCache(vDefaultClient, "/");
        m_CurCache = new TreeCache(vCurClient, "/");

        m_DefaultCache.start();
        m_CurCache.start();
    }

    @Override
    public Integer getCurValueToInt(String vName) {
        return getCurValueToIntPrivate(vName);
    }

    @Override
    public Boolean getCurValueToBool(String vName) {
        return getCurValueToBoolPrivate(vName);
    }

    @Override
    public String getCurValueToString(String vName) {
        return getCurValueToStringPrivate(vName);
    }

    @Override
    public byte[] getCurValue(String vName) {
        return getCurValuePrivate(vName);
    }

    private Integer getCurValueToIntPrivate(String vPath) {
        byte[] tResult = getCurValue(vPath);
        return null == tResult ? null : DataKit.getInt(tResult);
    }

    private Boolean getCurValueToBoolPrivate(String vPath) {
        byte[] tResult = getCurValue(vPath);
        return null == tResult ? null : DataKit.getBool(tResult);
    }

    private String getCurValueToStringPrivate(String vPath) {
        byte[] tResult = getCurValue(vPath);
        return null == tResult ? null : DataKit.getString(tResult);
    }

    private byte[] getCurValuePrivate(String vPath) {
        byte[] tResult  = getValue(m_CurCache, vPath);
        if(null == tResult)
            tResult = getValue(m_DefaultCache, vPath);

        return tResult;
    }

    private static byte[] getValue(TreeCache vCache, String vPath){
        String tPath    = PathKit.joint("/", vPath);
        if(null == vCache)
            return null;

        ChildData tCurrentData = vCache.getCurrentData(tPath);
        if(null == tCurrentData)
            return null;

        return tCurrentData.getData();
    }

    @Override
    public IEnvironmentVariablesTable getChild(String vPath) {
        return new ChildEnvironmentVariablesTable(vPath);
    }

    public class ChildEnvironmentVariablesTable implements IEnvironmentVariablesTable{
        private String m_RootPath;

        public ChildEnvironmentVariablesTable(String vRootPath) {
            m_RootPath = vRootPath;
        }

        @Override
        public Integer getCurValueToInt(String vName) {
            return getCurValueToIntPrivate(PathKit.joint(m_RootPath, vName));
        }

        @Override
        public Boolean getCurValueToBool(String vName) {
            return getCurValueToBoolPrivate(PathKit.joint(m_RootPath, vName));
        }

        @Override
        public String getCurValueToString(String vName) {
            return getCurValueToStringPrivate(PathKit.joint(m_RootPath, vName));
        }

        @Override
        public byte[] getCurValue(String vName) {
            return getCurValuePrivate(PathKit.joint(m_RootPath, vName));
        }

        @Override
        public IEnvironmentVariablesTable getChild(String vPath) {
            return new ChildEnvironmentVariablesTable(PathKit.joint(m_RootPath, vPath));
        }
    }
}
