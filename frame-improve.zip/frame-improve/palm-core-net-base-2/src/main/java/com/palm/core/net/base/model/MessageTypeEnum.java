package com.palm.core.net.base.model;

/**
 * 协议类型
 */
public enum MessageTypeEnum {
    LOGIN_REQUEST,           //登录协议
    BEFORE_LOGIN_REQUEST,   //登录前协议
    LATER_LOGIN_REQUEST,    //登录后协议
    RESPONSE                  //响应
}
