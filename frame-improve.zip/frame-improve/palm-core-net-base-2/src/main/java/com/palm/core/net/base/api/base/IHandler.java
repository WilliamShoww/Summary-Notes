package com.palm.core.net.base.api.base;

/**
 * 所有消息执行器基本接口 为便于管理
 */
public interface IHandler {
}
