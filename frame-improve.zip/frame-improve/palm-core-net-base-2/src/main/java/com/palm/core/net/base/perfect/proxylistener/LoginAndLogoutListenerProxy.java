package com.palm.core.net.base.perfect.proxylistener;

import com.palm.core.net.base.api.needperfect.ILoginAndLogoutListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class LoginAndLogoutListenerProxy implements ILoginAndLogoutListener {
    private final static Logger LOGGER = LoggerFactory.getLogger(LoginAndLogoutListenerProxy.class);

    @Autowired(required = false)
    private List<ILoginAndLogoutListener> m_LoginAndLogoutListenerList = new ArrayList();

    @Override
    public void onLogin(long vUserId, long vSessionId) {
        for (ILoginAndLogoutListener tLoginAndLogoutListener : m_LoginAndLogoutListenerList) {
            tLoginAndLogoutListener.onLogin(vUserId, vSessionId);
        }
        LOGGER.debug(String.format("onLogin ==> vUserId=%s!", vUserId));
    }

    @Override
    public void onLogout(long vUserId) {
        for (ILoginAndLogoutListener tLoginAndLogoutListener : m_LoginAndLogoutListenerList) {
            tLoginAndLogoutListener.onLogout(vUserId);
        }
        LOGGER.debug(String.format("onLogout ==> vUserId=%s!", vUserId));
    }
}
