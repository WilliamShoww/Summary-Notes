package com.palm.core.net.base.api.utils;

import com.google.protobuf.Message;
import com.palm.core.net.base.model.MessageFromEnum;

import java.net.InetAddress;
import java.util.List;

/**
 * 业务发送消息工具（已实现 通过Spring注入即可直接调用 供业务层发送消息使用）
 */
public interface ISendMessageKit {
    /**
     * 单发消息
     *
     * @param vMessage 消息
     * @param vUserId  用户Id
     */
    public void send(Message vMessage, long vUserId);

    /**
     * 群发消息
     *
     * @param vMessage 消息
     * @param vUserIds 用户Id列表
     */
    public void send(Message vMessage, List<Long> vUserIds);

    /**
     * 伪造请求
     *
     * @param vUserId          玩家Id
     * @param vMessage         消息
     * @param vMessageFromEnum 消息来源
     */
    public void simulateRequest(long vUserId, Message vMessage, MessageFromEnum vMessageFromEnum);

    /**
     * 广播
     *
     * @param vMessage 消息
     */
    public void broadcast(Message vMessage);

    /**
     * 重置Order(旧系统 客户端兼容)
     *
     * @param vUserId 用户Id
     */
    public void resetOrder(long vUserId);

    /**
     * 获取用户地址信息
     *
     * @param vUserId 用户Id
     * @return InetAddress 网络地址信息
     */
    public InetAddress getAddress(long vUserId);

    /**
     * 踢出用户
     *
     * @param vUserId 用户Id
     */
    public void kickUser(long vUserId);

    /**
     * 获取所有在线用户ID
     *
     * @return 用户Id列表
     */
    public List<Long> getOnlineUserIds();
}
