package com.palm.core.net.base.api.needperfect;

import com.palm.core.net.base.api.base.IHandler;

/**
 * 需业务实现（加Spring注解即可生效）
 * 不需要登陆执行器
 * @param <TRequestMessage>     请求协议
 * @param <TResponseMessage>    响应协议
 */
public interface INotLoginExecuteHandler<TRequestMessage, TResponseMessage> extends IHandler {
    /**
     * 消息执行
     * @param vTMessage     请求消息
     * @return
     *      TResponseMessage 响应消息
     */
    public TResponseMessage onExecute(TRequestMessage vTMessage);
}
