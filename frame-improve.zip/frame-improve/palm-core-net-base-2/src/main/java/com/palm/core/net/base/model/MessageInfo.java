package com.palm.core.net.base.model;

import com.baidu.bjf.remoting.protobuf.Codec;
import com.baidu.bjf.remoting.protobuf.ProtobufProxy;
import com.palm.core.net.base.annotations.HandlerDispatch;
import com.palm.core.net.base.api.base.IHandler;
import com.palm.core.net.base.api.needperfect.IExecuteHandler;
import com.palm.core.net.base.api.needperfect.ILoginHandler;
import com.palm.core.net.base.api.needperfect.INotLoginExecuteHandler;

import java.lang.reflect.Method;

/**
 * 协议相关信息
 */
public class MessageInfo {
    private long                    m_Code;                     //协议号
    private Class                   m_MessageClass;             //协议对应class
    private IHandler                m_Handler;                  //协议执行体
    private Method                  m_MainValueMethod;          //协议同步数据提炼
    private MessageTypeEnum         m_Type;                     //协议类型
    private HandlerDispatch         m_HandlerDispatch;          //协议线程管理注解
    private Codec                   m_ProtobufCodec;            //协议解析器

    public MessageInfo(long vCode, Class vMessageClass, IExecuteHandler vExecuteHandler, HandlerDispatch vHandlerDispatch) throws NoSuchMethodException {
        m_Code = vCode;
        m_Handler = vExecuteHandler;
        m_MessageClass = vMessageClass;
        m_Type = MessageTypeEnum.LATER_LOGIN_REQUEST;
        m_HandlerDispatch = vHandlerDispatch;

        if(null != vHandlerDispatch && false == vHandlerDispatch.threadMainField().isEmpty()){
            String tFieldName = vHandlerDispatch.threadMainField();
            String tMainValueMethodName = "get" + tFieldName.substring(0, 1).toUpperCase() + tFieldName.substring(1);
            m_MainValueMethod = vMessageClass.getMethod(tMainValueMethodName);
        }

        m_ProtobufCodec = ProtobufProxy.create(vMessageClass);
    }

    public MessageInfo(long vCode, Class vMessageClass, ILoginHandler vLoginHandler){
        m_Code = vCode;
        m_Handler = vLoginHandler;
        m_MessageClass = vMessageClass;
        m_ProtobufCodec = ProtobufProxy.create(vMessageClass);
        m_Type = MessageTypeEnum.LOGIN_REQUEST;
    }

    public MessageInfo(long vCode, Class vMessageClass){
        m_Code = vCode;
        m_MessageClass = vMessageClass;
        m_ProtobufCodec = ProtobufProxy.create(vMessageClass);
        m_Type = MessageTypeEnum.RESPONSE;
    }

    public MessageInfo(long vCode, Class vMessageClass, INotLoginExecuteHandler vNotLoginExecuteHandler){
        m_Code = vCode;
        m_Handler = vNotLoginExecuteHandler;
        m_MessageClass = vMessageClass;
        m_ProtobufCodec = ProtobufProxy.create(vMessageClass);
        m_Type = MessageTypeEnum.BEFORE_LOGIN_REQUEST;
    }

    public long getCode() {
        return m_Code;
    }

    public Class getMessageClass() {
        return m_MessageClass;
    }

    public HandlerDispatch getHandlerDispatch() {
        return m_HandlerDispatch;
    }

    public IExecuteHandler getExecuteHandler() {
        return (IExecuteHandler) m_Handler;
    }

    public ILoginHandler getLoginHandler() {
        return (ILoginHandler) m_Handler;
    }

    public INotLoginExecuteHandler getNotLoginExecuteHandler() {
        return (INotLoginExecuteHandler) m_Handler;
    }

    public Method getMainValueMethod() {
        return m_MainValueMethod;
    }

    public MessageTypeEnum getType() {
        return m_Type;
    }

    public Codec getProtobufCodec() {
        return m_ProtobufCodec;
    }

    @Override
    public String toString() {
        return "MessageInfo{" +
                "m_Code=" + m_Code +
                ", m_MessageClass=" + m_MessageClass.getName() +
                ", m_Type=" + m_Type +
                '}';
    }
}
