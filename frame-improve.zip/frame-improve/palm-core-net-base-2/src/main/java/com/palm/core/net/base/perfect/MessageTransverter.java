package com.palm.core.net.base.perfect;

import com.baidu.bjf.remoting.protobuf.Codec;
import com.google.protobuf.GeneratedMessage;
import com.google.protobuf.Message;
import com.palm.core.net.base.annotations.HandlerDispatch;
import com.palm.core.net.base.api.base.IHandler;
import com.palm.core.net.base.api.needperfect.IExecuteHandler;
import com.palm.core.net.base.api.needperfect.ILoginHandler;
import com.palm.core.net.base.api.needperfect.INotLoginExecuteHandler;
import com.palm.core.net.base.api.utils.IMessageTransverter;
import com.palm.core.net.base.model.MessageInfo;
import com.palm.core.net.base.model.MessageTypeEnum;
import com.palm.jprotobuf.JProtoBufTransitiveBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.*;

@Component
public class MessageTransverter implements IMessageTransverter {
    private final static Logger LOGGER = LoggerFactory.getLogger(MessageTransverter.class);

    private final static List<Class<? extends IHandler>> HANDLER_INTERFACE_SET = Arrays.asList(ILoginHandler.class, IExecuteHandler.class, INotLoginExecuteHandler.class);

    @Autowired(required = false)
    private List<IHandler> m_AllHandler = new ArrayList();

    private Map<Long, MessageInfo> m_CodeAndMessageMap = new HashMap();
    private Map<Class, Long>       m_ClassAndCodeMap   = new HashMap();

    @PostConstruct
    public void init() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        LOGGER.info("load agreement start!!!");

        //找出所有协议所在外部类
        Set<Class> tMessageOutClassSet = new HashSet();
        for(IHandler tHandler : m_AllHandler) {
            LOGGER.info("tHandler: " + tHandler + " -->class: " +getMessageClass(tHandler.getClass()).getDeclaringClass());
            tMessageOutClassSet.add(getMessageClass(tHandler.getClass()).getDeclaringClass());
        }

        //扫描出所有协议，并将协议与协议码对应
        Set<Class<?>>       tAllMessageClassSet = new HashSet();
        Map<String, Long>   tMessageCodeMap     = new HashMap();
        for(Class tMessageOutClass : tMessageOutClassSet) {
            String tOutClassSimpleName = tMessageOutClass.getSimpleName();
            LOGGER.info(String.format("scan message package %s start", tOutClassSimpleName));
            for (Class tClass : tMessageOutClass.getDeclaredClasses()){
                if(true == GeneratedMessage.class.equals(tClass.getSuperclass()))
                    tAllMessageClassSet.add((Class<Message>) tClass);

                String tEnumClassSimpleName = tClass.getSimpleName();
                if(true == tClass.isEnum() && true == tClass.getName().contains("MsgType")){
                    LOGGER.info(String.format("scan message code enum %s start", tEnumClassSimpleName));

                    Object[] tEnumArray = (Object[])tClass.getMethod("values").invoke(null);
                    Method   tMethod    = tEnumArray[0].getClass().getMethod("getNumber");
                    for(Object tO : tEnumArray){
                        tMessageCodeMap.put(tO.toString().substring(3), (long)(Integer) tMethod.invoke(tO));
                    }

                    LOGGER.info(String.format("scan message code enum %s end", tEnumClassSimpleName));
                }
            }

            LOGGER.info(String.format("scan message package %s end", tOutClassSimpleName));
        }

        //请求加入表单
        for(IHandler tHandler : m_AllHandler){
            Class<?> tMessageClass = getMessageClass(tHandler.getClass());
            if(null == tMessageClass){
                LOGGER.error("{} has not message", tHandler.getClass());
                return;
            }

            Long tCode;
            if (true == JProtoBufTransitiveBase.class.isAssignableFrom(tMessageClass)) {
                com.palm.jprotobuf.Message tMessage = tMessageClass.getAnnotation(com.palm.jprotobuf.Message.class);
                tCode = tMessage.code();
            }else {
                tCode = tMessageCodeMap.get(tMessageClass.getSimpleName());
            }
            m_ClassAndCodeMap.put(tMessageClass, tCode);

            if(tHandler instanceof ILoginHandler){
                m_CodeAndMessageMap.put(tCode, new MessageInfo(tCode, tMessageClass, (ILoginHandler) tHandler));
            }else if(tHandler instanceof IExecuteHandler){
                m_CodeAndMessageMap.put(tCode, new MessageInfo(tCode, tMessageClass, (IExecuteHandler) tHandler, getHandlerDispatch(tMessageClass)));
            }else {
                m_CodeAndMessageMap.put(tCode, new MessageInfo(tCode, tMessageClass, (INotLoginExecuteHandler) tHandler));
            }

            tAllMessageClassSet.remove(tMessageClass);
        }

        //响应入队列
        for(Class<?> tResponseMessageClass : tAllMessageClassSet){
            Long tCode = tMessageCodeMap.get(tResponseMessageClass.getSimpleName());
            if(null != tCode) {
                m_CodeAndMessageMap.put(tCode, new MessageInfo(tCode, tResponseMessageClass));
                m_ClassAndCodeMap.put(tResponseMessageClass, tCode);
                LOGGER.info(String.format("add response or request ==>> %s start", tResponseMessageClass.getName()));
            }
        }

        LOGGER.info("load agreement end!!!");
    }

    @Override
    public long getCode(Class<?> vMsgClass) {
        return m_ClassAndCodeMap.get(vMsgClass);
    }

    @Override
    public long getCode(Object vMsg) {
        return m_ClassAndCodeMap.get(vMsg.getClass());
    }

    @Override
    public Class<?> getMsgClass(long vCode) {
        MessageInfo tMessageInfo = m_CodeAndMessageMap.get(vCode);
        if(null == tMessageInfo)
            return null;

        return tMessageInfo.getMessageClass();
    }

    @Override
    public byte[] encode(Object vMsg) throws IOException {
        MessageInfo tMessageInfo = m_CodeAndMessageMap.get(m_ClassAndCodeMap.get(vMsg.getClass()));
        if(null == tMessageInfo)
            return null;

        return tMessageInfo.getProtobufCodec().encode(vMsg);
    }

    @Override
    public Object decode(long vCode, byte[] vData) throws IOException {
        MessageInfo tMessageInfo = m_CodeAndMessageMap.get(vCode);
        if(null == tMessageInfo)
            return null;

        Codec tProtobufCodec = tMessageInfo.getProtobufCodec();
        return tProtobufCodec.decode(vData);
    }

    @Override
    public MessageTypeEnum getMessageType(long vCode){
        MessageInfo tMessageInfo = m_CodeAndMessageMap.get(vCode);
        if(null == tMessageInfo)
            return null;

        return tMessageInfo.getType();
    }

    @Override
    public MessageInfo getMessageInfo(long vCode) {
        return m_CodeAndMessageMap.get(vCode);
    }

    @Override
    public String getTaskKey(Object vMessage){
        MessageInfo tMessageInfo = m_CodeAndMessageMap.get(m_ClassAndCodeMap.get(vMessage.getClass()));
        if(null == tMessageInfo)
            return UUID.randomUUID().toString();

        try {
            HandlerDispatch tHandlerDispatch = tMessageInfo.getHandlerDispatch();
            String          tKey             = (null == tHandlerDispatch || true == tHandlerDispatch.threadKey().isEmpty()) ? vMessage.getClass().getName() : tHandlerDispatch.threadKey();
            String          tMainValue       = null == tMessageInfo.getMainValueMethod() ? String.valueOf(vMessage.hashCode()) : tMessageInfo.getMainValueMethod().invoke(vMessage).toString();
            return tKey + "+" + tMainValue;
        }catch (Exception vE){
            throw new RuntimeException(vE);
        }
    }

    @Override
    public List<Class<?>> getMassageClassList(MessageTypeEnum vMessageType){
        List<Class<?>> tResult = new ArrayList();
        for (MessageInfo tMessageInfo : m_CodeAndMessageMap.values()) {
            if(vMessageType == tMessageInfo.getType())
                tResult.add(tMessageInfo.getMessageClass());
        }

        return tResult;
    }

    private Class<?> getMessageClass(Class<? extends IHandler> vHandler){
        for(Type tType : vHandler.getGenericInterfaces()){
            if(tType instanceof ParameterizedType){
                if(true == HANDLER_INTERFACE_SET.contains(((ParameterizedType) tType).getRawType()))
                    return (Class<Message>) (((ParameterizedType) tType).getActualTypeArguments())[0];
            }
        }

        return null;
    }

    private HandlerDispatch getHandlerDispatch(Class vHandler){
        //System.out.println("vHandler: "+vHandler+" |HandlerDispath: "+(HandlerDispatch)vHandler.getAnnotation(HandlerDispatch.class));
        return (HandlerDispatch)vHandler.getAnnotation(HandlerDispatch.class);
    }
}
