package com.palm.core.net.base.perfect.proxylistener;

import com.palm.core.net.base.annotations.Detection;
import com.palm.core.net.base.api.needperfect.IExecuteListener;
import com.palm.core.net.base.api.utils.IMessageTransverter;
import com.palm.core.net.base.model.MessageFromEnum;
import com.palm.core.net.base.model.MessageTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ExecuteListenerProxy implements IExecuteListener {
    private final static Logger LOGGER = LoggerFactory.getLogger(ExecuteListenerProxy.class);

    @Autowired(required=false)
    private List<IExecuteListener> m_ExecuteListenerList = new ArrayList();

    @Autowired
    private IMessageTransverter m_MessageTransverter;

    private List<IExecuteListener> m_AllMessageListenerList = new ArrayList();

    private Map<Class<?>, List<IExecuteListener>> m_ClassExecuteListenerMap = new HashMap();

    @PostConstruct
    public void init(){
        List<Class<?>> tMassageClassList = m_MessageTransverter.getMassageClassList(MessageTypeEnum.LATER_LOGIN_REQUEST);
        for (IExecuteListener tExecuteListener : m_ExecuteListenerList) {
            Detection tAnnotation = tExecuteListener.getClass().getAnnotation(Detection.class);
            if(null != tAnnotation && (false == tAnnotation.hand().isEmpty() || 0 != tAnnotation.massage().length)){
                if(0 != tAnnotation.massage().length){
                    for (Class<?> tClass : tAnnotation.massage()) {
                        List<IExecuteListener> tList = m_ClassExecuteListenerMap.get(tClass);
                        if(null == tList){
                            tList = new ArrayList();
                            m_ClassExecuteListenerMap.put(tClass, tList);
                        }

                        tList.add(tExecuteListener);
                    }
                }

                if(false == tAnnotation.hand().isEmpty()) {
                    for (Class<?> tClass : tMassageClassList) {
                        if (true == tClass.getName().contains(tAnnotation.hand())) {
                            List<IExecuteListener> tList = m_ClassExecuteListenerMap.get(tClass);
                            if(null == tList){
                                tList = new ArrayList();
                                m_ClassExecuteListenerMap.put(tClass, tList);
                            }

                            tList.add(tExecuteListener);
                        }
                    }
                }
            }else {
                m_AllMessageListenerList.add(tExecuteListener);
            }
        }
    }

    @Override
    public void onExecute(long vUserId, Object vTRequestMessage, Object vTResponseMessage, MessageFromEnum vMessageFromEnum) {
        List<IExecuteListener> tPartListenerList = m_ClassExecuteListenerMap.get(vTRequestMessage.getClass());
        if(null != tPartListenerList){
            for (IExecuteListener tExecuteListener : tPartListenerList)
                tExecuteListener.onExecute(vUserId, vTRequestMessage, vTResponseMessage, vMessageFromEnum);
        }

        for (IExecuteListener tExecuteListener : m_AllMessageListenerList)
            tExecuteListener.onExecute(vUserId, vTRequestMessage, vTResponseMessage, vMessageFromEnum);

        LOGGER.debug(String.format("ExecuteListenerProxy ==> vUserId=%s, RequestClass=%s, vTRequestMessage=%s, vTResponseMessage=%s, vMessageFromEnum=%s!", vUserId, vTRequestMessage.getClass(), vTRequestMessage, vTResponseMessage, vMessageFromEnum));
    }
}
