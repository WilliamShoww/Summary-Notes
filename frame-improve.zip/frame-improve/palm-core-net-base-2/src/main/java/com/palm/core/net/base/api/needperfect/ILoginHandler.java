package com.palm.core.net.base.api.needperfect;

import com.palm.core.net.base.api.base.IHandler;
import com.palm.core.net.base.model.LoginResult;

/**
 * 需业务实现（加Spring注解即可生效）
 * 登录执行器
 * @param <TLoginRequest>   登录请求协议
 * @param <TLoginResponse>  登录响应协议
 */
public interface ILoginHandler<TLoginRequest, TLoginResponse> extends IHandler {
    /**
     * 登录操作
     * @param vTLoginMessage    登录消息
     * @param vSessionId        会话Id
     * @return
     *      LoginResult 登录结果
     */
    public LoginResult<TLoginResponse> onLogin(TLoginRequest vTLoginMessage, long vSessionId);

    /**
     * 断线后续处理
     * @param vUserId   用户Id
     */
    public void onDisconnect(long vUserId);
}