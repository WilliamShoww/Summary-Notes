package com.palm.core.net.base.annotations;

import java.lang.annotation.*;

/**
 * 协议处理线程分派管理注解
 *      ThreadKey       ThreadMainField
 *      false           false               进入即立即执行
 *      false           true                ThreadMainField对应数据的值相同只允许单线程运行
 *      true            false               相同Key服务只允许单线程运行
 *      true            true                相同Key且ThreadMainField对应数据的值也相同则只允许单线程运行
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Documented
public @interface HandlerDispatch {
    /**
     * 线程调用时的区分线程分组
     */
    public String threadKey() default "";

    /**
     * 协议相关字段名 以字段数据作为单线程标准
     */
    public String threadMainField() default "";
}
