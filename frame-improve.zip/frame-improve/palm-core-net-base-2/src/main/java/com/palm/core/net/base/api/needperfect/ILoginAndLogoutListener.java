package com.palm.core.net.base.api.needperfect;

/**
 * 需业务实现（加Spring注解即可生效）
 * 登陆退出以及非正常断线监听器
 */
public interface ILoginAndLogoutListener {
    /**
     * 登录监听
     * @param vUserId       用户Id
     * @param vSessionId    用户会话对应Id
     */
    public void onLogin(long vUserId, long vSessionId);

    /**
     * 掉线监听
     * @param vUserId   用户Id
     */
    public void onLogout(long vUserId);
}
