package com.palm.core.net.base.api.needperfect;

import com.palm.core.net.base.api.base.IHandler;

/**
 * 需业务实现（加Spring注解即可生效）
 * 普通协议执行器
 * @param <TRequestMessage>     请求协议
 * @param <TResponseMessage>    响应协议
 */
public interface IExecuteHandler<TRequestMessage, TResponseMessage> extends IHandler {
    /**
     * 执行接口
     * @param vUserId       //用户Id
     * @param vTMessage     //执行消息
     */
    public TResponseMessage onExecute(long vUserId, TRequestMessage vTMessage);
}