package com.palm.core.net.base.model;

public enum MessageFromEnum {
    NORMAL,              //正常消息 来源自客户端
    DISCONNECT,         //伪造消息 暂定超时自动消息
    OTHER               //其他    暂定机器人？
}
