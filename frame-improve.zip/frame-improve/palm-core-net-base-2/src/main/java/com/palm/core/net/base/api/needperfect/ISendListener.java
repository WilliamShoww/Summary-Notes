package com.palm.core.net.base.api.needperfect;

/**
 * 需业务实现（加Spring注解即可生效）
 * 发送消息监听器
 */
public interface ISendListener<TMessage> {
    /**
     * 发送消息丢入队列
     * @param vUserId       用户Id
     * @param vTMessage     消息
     */
    public void onSendStart(long vUserId, TMessage vTMessage);

    /**
     * 发送消息完成并成功
     * @param vUserId       用户Id
     * @param vTMessage     消息
     */
    public void onSendSucceed(long vUserId, TMessage vTMessage);

    /**
     * 发送消息完成 因玩家掉线等原因发送失败
     * @param vUserId       用户Id
     * @param vTMessage     消息
     */
    public void onSendFail(long vUserId, TMessage vTMessage);
}