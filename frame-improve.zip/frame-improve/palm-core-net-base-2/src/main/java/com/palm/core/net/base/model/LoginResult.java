package com.palm.core.net.base.model;

/**
 * 登录结果封装
 * @param <TLoginResponse> 登录结果对应协议类
 */
public class LoginResult<TLoginResponse>{
    private Long           m_UserId;           //玩家Id 登录成功
    private TLoginResponse m_LoginResponse;    //登录给客户端响应

    /**
     * 登录返回结果构造
     * @param vUserId           若登录成功则传玩家Id 否则传null
     * @param vLoginResponse    登录响应消息
     */
    public LoginResult(Long vUserId, TLoginResponse vLoginResponse) {
        m_UserId = vUserId;
        m_LoginResponse = vLoginResponse;
    }

    public Long getUserId() {
        return m_UserId;
    }

    public TLoginResponse getLoginResponse() {
        return m_LoginResponse;
    }
}
