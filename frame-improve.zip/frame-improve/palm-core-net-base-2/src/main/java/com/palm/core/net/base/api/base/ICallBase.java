package com.palm.core.net.base.api.base;

/**
 * 异步完成回调
 */
public interface ICallBase {
    /**
     * 回调时间
     * @param vSuccess  执行结果
     */
    public void onCall(boolean vSuccess);
}