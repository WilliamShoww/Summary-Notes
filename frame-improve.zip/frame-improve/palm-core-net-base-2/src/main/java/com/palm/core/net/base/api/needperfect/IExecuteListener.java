package com.palm.core.net.base.api.needperfect;

import com.palm.core.net.base.model.MessageFromEnum;

/**
 * 需业务实现（加Spring注解即可生效）
 * 协议消息执行监听器
 */
public interface IExecuteListener<TRequestMessage, TResponseMessage> {
    /**
     * 执行完 触发器
     * @param vUserId           用户Id
     * @param vTRequestMessage  执行消息
     * @param vTResponseMessage 响应消息
     * @param vMessageFromEnum  消息源
     */
    public void onExecute(long vUserId, TRequestMessage vTRequestMessage, TResponseMessage vTResponseMessage, MessageFromEnum vMessageFromEnum);
}
