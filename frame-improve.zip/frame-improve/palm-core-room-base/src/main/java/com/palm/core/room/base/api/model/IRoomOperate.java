package com.palm.core.room.base.api.model;

import com.palm.core.room.base.model.RoomModel;

/**
 * 房间附带操作（游戏操作借此进入可以，内部有加锁）
 */
public interface IRoomOperate {
    public int onOperate(RoomModel vRoomModel);
}