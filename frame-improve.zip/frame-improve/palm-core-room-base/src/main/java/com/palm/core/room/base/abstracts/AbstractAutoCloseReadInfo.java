package com.palm.core.room.base.abstracts;

import com.palm.core.room.base.api.model.IAutoCloseReadInfo;

/**
 * 读数据 自动释放锁
 * @param <TData>
 */
public abstract class AbstractAutoCloseReadInfo<TData> implements IAutoCloseReadInfo<TData>{
    protected TData m_Data;

    /**
     * 只放入数据
     * @param vData 读取的数据
     */
    public AbstractAutoCloseReadInfo(TData vData) {
        m_Data = vData;
    }

    @Override
    public TData getData() {
        return m_Data;
    }
}
