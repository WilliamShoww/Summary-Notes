package com.palm.core.room.base.api.model;

import java.util.Map;

/**
 * 房间结果处理器 主要发送房间操作结果
 */
public interface IRoomResultDeal {
    /**
     * 进入
     * @param vUserId   用户Id
     * @param vPosId    座位号
     */
    public void join(long vUserId, int vPosId);

    /**
     * 退出
     * @param vUserId   用户Id
     * @param vPosId    座位号
     */
    public void exit(long vUserId, int vPosId);

    /**
     * 换座位
     * @param vUserId       用户Id
     * @param vNewPosId     新座位号
     */
    public void changePos(long vUserId, int vNewPosId);

    /**
     * 准备
     * @param vUserId   用户Id
     * @param vReady    是否准备
     */
    public void ready(long vUserId, boolean vReady);

    /**
     * 玩家上线
     * @param vUserId   用户Id
     */
    public void online(long vUserId);

    /**
     * 玩家下线
     * @param vUserId   用户Id
     */
    public void offline(long vUserId);

    /**
     * 重连
     * @param vUserId   用户Id
     */
    public void reconnect(long vUserId);

    /**
     * 销毁房间
     * @param vType     销毁原因
     */
    public void destroy(int vType);

    /**
     * 解散房间
     * @param vVoteTable    投票信息表
     * @param vResult       投票结果    true 解散 false 失败 null 无结果
     */
    public void dissolve(Map<Long, Integer> vVoteTable, Boolean vResult);

    /**
     * 大结算
     */
    public void settleTotal();
}
