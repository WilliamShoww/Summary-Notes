package com.palm.core.room.base.api.model;

/**
 * 获取信息 内部附带读锁 依赖AutoCloseable自动释放
 * 数据修改无效 并保证查看过程中不会被修改
 * @param <TInfo>
 */
public interface IAutoCloseReadInfo<TInfo> extends AutoCloseable{
    /**
     * 获取数据
     */
    public TInfo getData();

    /**
     * 释放读锁
     */
    @Override
    public void close();
}