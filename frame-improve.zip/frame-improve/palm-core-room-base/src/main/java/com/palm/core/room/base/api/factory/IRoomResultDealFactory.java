package com.palm.core.room.base.api.factory;

import com.palm.core.room.base.api.model.IRoomResultDeal;

/**
 * 房间结果处理工厂（消息发送模型创建工厂）
 */
public interface IRoomResultDealFactory {
    /**
     * 创建房间结果处理类
     * @param vRoomId   房间号
     * @return
     *      结果处理类
     */
    public IRoomResultDeal createRoomResultDeal(long vRoomId);

    /**
     * 获取结果处理类
     * @param vRoomId   房间号
     * @return
     *      结果处理类
     */
    public IRoomResultDeal getResultDeal(long vRoomId);

    /**
     * 删除结果处理类
     * @param vRoomId   房间号
     * @return
     *      结果处理类
     */
    public IRoomResultDeal removeResultDeal(long vRoomId);
}
