package com.palm.core.room.base.model;

import java.util.Map;

/**
 * 创建房间参数
 */
public class RoomCreateParam {
    private long                    m_RoomId;         //房间号
    private int                     m_GameType;       //游戏类型
    private int                     m_GameStyle;      //游戏模式
    private int                     m_PlayerSize;     //玩家人数上限
    private int                     m_GameSize;       //游戏局数上限
    private Map<Integer, Integer>   m_GameRule;       //游戏其余规则
    private long                    m_RoomMainId;     //房主Id
    private Map<String, String>     m_AttrEx;         //房间拓展数据

    public long getRoomMainId() {
        return m_RoomMainId;
    }

    public void setRoomMainId(long vRoomMainId) {
        m_RoomMainId = vRoomMainId;
    }

    public long getRoomId() {
        return m_RoomId;
    }

    public void setRoomId(long vRoomId) {
        m_RoomId = vRoomId;
    }

    public int getGameType() {
        return m_GameType;
    }

    public void setGameType(int vGameType) {
        m_GameType = vGameType;
    }

    public int getGameStyle() {
        return m_GameStyle;
    }

    public void setGameStyle(int vGameStyle) {
        m_GameStyle = vGameStyle;
    }

    public int getPlayerSize() {
        return m_PlayerSize;
    }

    public void setPlayerSize(int vPlayerSize) {
        m_PlayerSize = vPlayerSize;
    }

    public int getGameSize() {
        return m_GameSize;
    }

    public void setGameSize(int vGameSize) {
        m_GameSize = vGameSize;
    }

    public Map<Integer, Integer> getGameRule() {
        return m_GameRule;
    }

    public void setGameRule(Map<Integer, Integer> vGameRule) {
        m_GameRule = vGameRule;
    }

    public Map<String, String> getAttrEx() {
        return m_AttrEx;
    }

    public void setAttrEx(Map<String, String> vAttrEx) {
        m_AttrEx = vAttrEx;
    }
}
