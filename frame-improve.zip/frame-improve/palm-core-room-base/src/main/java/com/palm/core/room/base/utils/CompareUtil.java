package com.palm.core.room.base.utils;

public class CompareUtil {
    /**
     * 数据比较是否相等 可为null
     */
    public static boolean some(Object vObject1, Object vObject2){
        if(null == vObject1 && null == vObject2)
            return true;

        if(null == vObject1 || null == vObject2)
            return false;

        return vObject1.equals(vObject2);
    }
}
