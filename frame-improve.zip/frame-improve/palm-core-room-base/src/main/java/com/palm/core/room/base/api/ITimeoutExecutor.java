package com.palm.core.room.base.api;

import com.palm.core.room.base.model.TimeoutTask;

/**
 * 超时任务执行器
 * 具备 添加定时任务，去除任务组，暂停任务组，取消暂停任务，取消延迟等功能
 */
public interface ITimeoutExecutor<TData>{
    public void addTask(TimeoutTask<TData> vTimeoutTask);

    public void subTaskGroup(String vKey);

    public void playTaskGroup(String vKey);

    public void pauseTaskGroup(String vKey);

    public void cancelDelayTask(String vKey);
}