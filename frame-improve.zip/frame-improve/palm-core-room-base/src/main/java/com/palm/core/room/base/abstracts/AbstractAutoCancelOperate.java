package com.palm.core.room.base.abstracts;

import com.palm.core.room.base.api.model.IAutoCancelOperate;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;

/**
 * 简单封装事务抽象
 * @param <TModel> 数据操作封装
 */
public abstract class AbstractAutoCancelOperate<TModel> implements IAutoCancelOperate<TModel>{
    protected TModel m_Model;
    protected Lock   m_Lock;

    /**
     * 外部已锁 完结只负责释放 构造方法
     * @param vModel        数据模型
     * @param vAlreadyLock  已经锁过的锁
     */
    public AbstractAutoCancelOperate(TModel vModel, Lock vAlreadyLock) {
        m_Model = vModel;
        m_Lock = vAlreadyLock;
    }

    /**
     * 外部未锁
     * @param vModel
     * @param vReadWriteLock
     */
    public AbstractAutoCancelOperate(TModel vModel, ReadWriteLock vReadWriteLock) {
        m_Model = vModel;
        m_Lock = vReadWriteLock.writeLock();
        m_Lock.lock();
    }

    @Override
    public TModel getModel(){
        return m_Model;
    }

    @Override
    public void close(){
        m_Lock.unlock();
    }
}