package com.palm.core.room.base.api.model;

import com.palm.core.room.base.model.RoomInfo;

/**
 * 房间操作附带条件
 */
public interface IRoomDemand {
    public int onDemand(RoomInfo vRoomInfo);
}
