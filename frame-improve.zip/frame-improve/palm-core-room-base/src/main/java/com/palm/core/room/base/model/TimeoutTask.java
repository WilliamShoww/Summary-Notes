package com.palm.core.room.base.model;

/**
 * 超时任务
 * @param <TData>   超时任务数据
 */
public class TimeoutTask<TData> {
    protected long   m_CreateTime;  //创建时间
    protected long   m_Delayed;     //延时长度 ms
    protected String m_Key;         //任务Key（房间号等）
    protected TData  m_Data;        //任务数据

    public TimeoutTask() {
    }

    public TimeoutTask(long vDelayed, String vKey, TData vData) {
        m_CreateTime = System.currentTimeMillis();
        m_Delayed = vDelayed;
        m_Key = vKey;
        m_Data = vData;
    }

    public long getCreateTime() {
        return m_CreateTime;
    }

    public void setCreateTime(long vCreateTime) {
        m_CreateTime = vCreateTime;
    }

    public long getDelayed() {
        return m_Delayed;
    }

    public void setDelayed(long vDelayed) {
        m_Delayed = vDelayed;
    }

    public TData getData() {
        return m_Data;
    }

    public void setData(TData vData) {
        m_Data = vData;
    }

    public String getKey() {
        return m_Key;
    }

    public void setKey(String vKey) {
        m_Key = vKey;
    }
}
