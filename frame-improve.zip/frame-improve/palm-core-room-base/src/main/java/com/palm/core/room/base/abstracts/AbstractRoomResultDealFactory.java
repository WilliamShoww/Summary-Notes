package com.palm.core.room.base.abstracts;

import com.palm.core.room.base.api.IRoomFactory;
import com.palm.core.room.base.api.factory.IRoomResultDealFactory;
import com.palm.core.room.base.api.model.IAutoCloseReadInfo;
import com.palm.core.room.base.api.model.IRoomResultDeal;
import com.palm.core.room.base.model.RoomInfo;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 房间管理结果处理器生成工厂
 * @param <TRoomResultDeal>
 */
public abstract class AbstractRoomResultDealFactory<TRoomResultDeal extends IRoomResultDeal> implements IRoomResultDealFactory{
    protected Map<Long, TRoomResultDeal> m_RoomResultDealMap = new ConcurrentHashMap();

    protected IRoomFactory m_RoomFactory;

    @Override
    public TRoomResultDeal createRoomResultDeal(long vRoomId) {
        try (IAutoCloseReadInfo<RoomInfo> tRoomInfoIAutoCloseReadInfo = m_RoomFactory.borrowRoomInfo(vRoomId)){
            TRoomResultDeal tRoomResultDeal = onCreate(tRoomInfoIAutoCloseReadInfo.getData());
            m_RoomResultDealMap.put(vRoomId, tRoomResultDeal);
            return tRoomResultDeal;
        }
    }

    @Override
    public TRoomResultDeal getResultDeal(long vRoomId) {
        return m_RoomResultDealMap.get(vRoomId);
    }

    @Override
    public TRoomResultDeal removeResultDeal(long vRoomId) {
        return m_RoomResultDealMap.remove(vRoomId);
    }

    protected abstract TRoomResultDeal onCreate(RoomInfo vRoomInfo);
}