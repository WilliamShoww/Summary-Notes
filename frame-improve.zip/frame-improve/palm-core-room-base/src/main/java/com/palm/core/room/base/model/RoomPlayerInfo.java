package com.palm.core.room.base.model;

import java.util.List;

/**
 * 房间内玩家数据
 */
public class RoomPlayerInfo {
    protected long          m_PlayerId;     //玩家Id
    protected int           m_PlayerIndex;  //玩家座位号
    protected int           m_Score;        //分数
    protected int           m_WinCount;     //赢次数
    protected List<Integer> m_OtherSign;    //玩家其他标记
    protected int           m_PlayerStatus; //玩家状态
    protected boolean       m_Ready;        //是否准备
    protected int           m_VoteStatus;   //玩家投票状态

    public long getPlayerId() {
        return m_PlayerId;
    }

    public void setPlayerId(long vPlayerId) {
        m_PlayerId = vPlayerId;
    }

    public int getPlayerIndex() {
        return m_PlayerIndex;
    }

    public void setPlayerIndex(int vPlayerIndex) {
        m_PlayerIndex = vPlayerIndex;
    }

    public int getScore() {
        return m_Score;
    }

    public void setScore(int vScore) {
        m_Score = vScore;
    }

    public int getWinCount() {
        return m_WinCount;
    }

    public void setWinCount(int vWinCount) {
        m_WinCount = vWinCount;
    }

    public List<Integer> getOtherSign() {
        return m_OtherSign;
    }

    public void setOtherSign(List<Integer> vOtherSign) {
        m_OtherSign = vOtherSign;
    }

    public int getPlayerStatus() {
        return m_PlayerStatus;
    }

    public void setPlayerStatus(int vPlayerStatus) {
        m_PlayerStatus = vPlayerStatus;
    }

    public boolean isReady() {
        return m_Ready;
    }

    public void setReady(boolean vReady) {
        m_Ready = vReady;
    }

    public void addWinCount(){
        m_WinCount++;
    }

    public void addScore(int vScore){
        m_Score+=vScore;
    }

    public int getVoteStatus() {
        return m_VoteStatus;
    }

    public void setVoteStatus(int vVoteStatus) {
        m_VoteStatus = vVoteStatus;
    }
}