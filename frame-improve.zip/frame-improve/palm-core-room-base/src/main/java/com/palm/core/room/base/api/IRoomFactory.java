package com.palm.core.room.base.api;

import com.palm.core.room.base.api.factory.IGameFactory;
import com.palm.core.room.base.api.factory.IRoomResultDealFactory;
import com.palm.core.room.base.api.model.IAutoCloseReadInfo;
import com.palm.core.room.base.api.model.IDissolveVoteUtil;
import com.palm.core.room.base.api.model.IRoomOperate;
import com.palm.core.room.base.logic.RoomLogic;
import com.palm.core.room.base.model.GameResult;
import com.palm.core.room.base.model.RoomCreateParam;
import com.palm.core.room.base.model.RoomInfo;

import java.util.Map;

/**
 * 房间工厂
 */
public interface IRoomFactory {
    /**
     * 投票工具设置
     */
    public void setDissolveVoteUtil(int vGameType, IDissolveVoteUtil vDissolveVoteUtil);
    public void setDissolveVoteUtil(int vGameType, int vGameStyle, IDissolveVoteUtil vDissolveVoteUtil);

    /**
     * 房间结果处理工厂设置
     */
    public void setRoomResultDealFactory(int vGameType, IRoomResultDealFactory vRoomResultDealFactory);
    public void setRoomResultDealFactory(int vGameType, int vGameStyle, IRoomResultDealFactory vRoomResultDealFactory);
    public void setDefaultRoomResultDealFactory(IRoomResultDealFactory vDefaultRoomResultDealFactory);

    /**
     * 游戏工厂设置
     */
    public void setGameFactory(int vGameType, IGameFactory vGameFactory);
    public void setGameFactory(int vGameType, int vGameStyle, IGameFactory vGameFactory);

    /**
     * 玩家房间表更新工具设置
     */
    public void setUserIdRoomIdTable(IUserIdRoomIdTable vUserIdRoomIdTable);

    /**
     * 创建房间
     * @param vRoomCreateParam 创建房间
     */
    public void createRoom(RoomCreateParam vRoomCreateParam);

    /**
     * 获取房间信息 （可能死锁）
     * @param vRoomId   房间号
     * @return
     *      自动关闭锁的数据封装类
     */
    public IAutoCloseReadInfo<RoomInfo> getRoomInfo(long vRoomId);

    /**
     * 获取房间信息 （如果写锁线程 则直接返回缓存）
     * @param vRoomId   房间号
     * @return
     *      自动关闭锁的数据封装类
     */
    public IAutoCloseReadInfo<RoomInfo> borrowRoomInfo(long vRoomId);

    /**
     * 查询座位表
     * @param vRoomId   房间号
     * @return
     *      座位表 座位号-> 玩家Id
     */
    public Map<Integer, Long> queryPosTable(long vRoomId);

    /**
     * 删除房间
     * @param vRoomId   房间号
     */
    public void removeRoom(long vRoomId);

    /**
     * 获取房间逻辑类
     * @param vRoomId   房间号
     * @return
     *      房间逻辑类
     */
    public RoomLogic getRoomLogic(long vRoomId);

    /**
     * 小结算
     * @param vRoomId       房间Id
     * @param vGameResult   游戏结果
     */
    public void settle(Long vRoomId, GameResult vGameResult);

    /**
     * 事件执行（加锁）
     * @param vRoomOperate 需执行的事件
     */
    public int doSomething(long vRoomId, IRoomOperate vRoomOperate);
}
