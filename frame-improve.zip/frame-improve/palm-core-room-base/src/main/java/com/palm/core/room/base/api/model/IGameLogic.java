package com.palm.core.room.base.api.model;

import com.palm.core.room.base.api.factory.IGameFactory;

/**
 * 游戏逻辑模型
 * @param <TGameModel>   游戏数据模型
 */
public interface IGameLogic<TGameModel> {
    /**
     * @return 游戏模型
     */
    public TGameModel getGameModel();

    /**
     * 设置工厂 用于回调游戏结束
     * @param vGameFactory  游戏工厂
     */
    public void setGameFactory(IGameFactory<TGameModel> vGameFactory);

    /**
     * 游戏开始
     */
    public void start();
}
