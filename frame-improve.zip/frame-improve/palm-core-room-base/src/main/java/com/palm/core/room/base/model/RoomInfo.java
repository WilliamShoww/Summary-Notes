package com.palm.core.room.base.model;

import java.util.List;
import java.util.Map;

public class RoomInfo {
    protected long                  m_RoomId;           //房间号
    protected long                  m_CurrentGameIndex; //当前局数
    protected long                  m_RoomMainId;       //房主
    protected int                   m_GameType;         //游戏类型
    protected int                   m_GameStyle;        //游戏模式
    protected int                   m_PlayerSize;       //玩家总人数
    protected int                   m_GameSize;         //游戏总局数
    protected int                   m_RoomStatus;       //房间状态
    protected int                   m_DestroyType;      //销毁房间原因
    protected RoomPlayerInfo[]      m_PlayerList;       //玩家列表
    protected Map<Integer, Integer> m_GameRule;         //游戏规则
    protected boolean               m_Voting;           //投票中
    protected List<GameResult>      m_GameResultList;   //小局游戏结果
    protected Map<String, String>   m_AttrEx;           //房间拓展数据

    public long getRoomId() {
        return m_RoomId;
    }

    public long getCurrentGameIndex() {
        return m_CurrentGameIndex;
    }

    public long getRoomMainId() {
        return m_RoomMainId;
    }

    public int getGameType() {
        return m_GameType;
    }

    public int getPlayerSize() {
        return m_PlayerSize;
    }

    public int getGameStyle() {
        return m_GameStyle;
    }

    public int getGameSize() {
        return m_GameSize;
    }

    public Map<Integer, Integer> getGameRule() {
        return m_GameRule;
    }

    public int getRoomStatus() {
        return m_RoomStatus;
    }

    public RoomPlayerInfo[] getPlayerList() {
        return m_PlayerList;
    }

    public int getDestroyType() {
        return m_DestroyType;
    }

    public boolean isVoting() {
        return m_Voting;
    }

    public List<GameResult> getGameResultList() {
        return m_GameResultList;
    }

    public Map<String, String> getAttrEx() {
        return m_AttrEx;
    }

    public void setRoomId(long vRoomId) {
        m_RoomId = vRoomId;
    }

    public void setCurrentGameIndex(long vCurrentGameIndex) {
        m_CurrentGameIndex = vCurrentGameIndex;
    }

    public void setRoomMainId(long vRoomMainId) {
        m_RoomMainId = vRoomMainId;
    }

    public void setGameType(int vGameType) {
        m_GameType = vGameType;
    }

    public void setGameStyle(int vGameStyle) {
        m_GameStyle = vGameStyle;
    }

    public void setPlayerSize(int vPlayerSize) {
        m_PlayerSize = vPlayerSize;
    }

    public void setGameSize(int vGameSize) {
        m_GameSize = vGameSize;
    }

    public void setRoomStatus(int vRoomStatus) {
        m_RoomStatus = vRoomStatus;
    }

    public void setDestroyType(int vDestroyType) {
        m_DestroyType = vDestroyType;
    }

    public void setPlayerList(RoomPlayerInfo[] vPlayerList) {
        m_PlayerList = vPlayerList;
    }

    public void setGameRule(Map<Integer, Integer> vGameRule) {
        m_GameRule = vGameRule;
    }

    public void setVoting(boolean vVoting) {
        m_Voting = vVoting;
    }

    public void setGameResultList(List<GameResult> vGameResultList) {
        m_GameResultList = vGameResultList;
    }

    public void setAttrEx(Map<String, String> vAttrEx) {
        m_AttrEx = vAttrEx;
    }
}
