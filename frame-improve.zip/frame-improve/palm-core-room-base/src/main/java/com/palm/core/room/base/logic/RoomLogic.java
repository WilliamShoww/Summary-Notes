package com.palm.core.room.base.logic;

import com.palm.core.room.base.api.IRoomFactoryPostern;
import com.palm.core.room.base.api.model.IAutoCancelOperate;
import com.palm.core.room.base.api.model.IDissolveVoteUtil;
import com.palm.core.room.base.api.model.IRoomDemand;
import com.palm.core.room.base.api.model.IRoomResultDeal;
import com.palm.core.room.base.enums.DestroyType;
import com.palm.core.room.base.enums.RoomErrorCode;
import com.palm.core.room.base.enums.RoomStatusType;
import com.palm.core.room.base.enums.VoteStatusType;
import com.palm.core.room.base.model.GameResult;
import com.palm.core.room.base.model.RoomModel;

import java.util.Map;

public class RoomLogic {
    private long                m_RoomId;
    private IRoomResultDeal     m_RoomResultDeal;
    private IRoomFactoryPostern m_RoomFactoryPostern;
    private IDissolveVoteUtil   m_DissolveVoteUtil;

    public void setRoomId(long vRoomId) {
        m_RoomId = vRoomId;
    }

    public void setRoomResultDeal(IRoomResultDeal vRoomResultDeal) {
        m_RoomResultDeal = vRoomResultDeal;
    }

    public void setRoomFactoryPostern(IRoomFactoryPostern vRoomFactoryPostern) {
        m_RoomFactoryPostern = vRoomFactoryPostern;
    }

    public void setDissolveVoteUtil(IDissolveVoteUtil vDissolveVoteUtil) {
        m_DissolveVoteUtil = vDissolveVoteUtil;
    }

    //进入
    public int join(long vPlayerId){
        return join(vPlayerId, null);
    }

    //进入
    public int join(long vPlayerId, IRoomDemand vRoomDemand){
        try (IAutoCancelOperate<RoomModel> tAutoCancelRoomOperate = m_RoomFactoryPostern.getRoomModel(m_RoomId)) {
            RoomModel tRoomModel = tAutoCancelRoomOperate.getModel();
            if(RoomStatusType.FIRST_READY != tRoomModel.getRoomStatus())
                return RoomErrorCode.ALREADY_START;

            Integer tPosId = tRoomModel.getPosId(vPlayerId);
            if(null != tPosId)
                return RoomErrorCode.EXIST;

            Integer tVacancyPosId = tRoomModel.getVacancyPosId();
            if(null == tVacancyPosId)
                return RoomErrorCode.PLAYER_FULL;

            if(null != vRoomDemand){
                int tResult = vRoomDemand.onDemand(tRoomModel);
                if(RoomErrorCode.SUCCESS != tResult)
                    return tResult;
            }

            tRoomModel.join(tVacancyPosId, vPlayerId);
            m_RoomResultDeal.join(vPlayerId, tVacancyPosId);
            tAutoCancelRoomOperate.submit();
            return RoomErrorCode.SUCCESS;
        }
    }

    //退出
    public int exit(long vPlayerId){
        try (IAutoCancelOperate<RoomModel> tAutoCancelRoomOperate = m_RoomFactoryPostern.getRoomModel(m_RoomId)) {
            RoomModel tRoomModel = tAutoCancelRoomOperate.getModel();
            if (RoomStatusType.FIRST_READY != tRoomModel.getRoomStatus() && RoomStatusType.OVER != tRoomModel.getRoomStatus())
                return RoomErrorCode.ALREADY_START;

            Integer tPosId = tRoomModel.getPosId(vPlayerId);
            if (null == tPosId)
                return RoomErrorCode.NOT_EXIST;

            tRoomModel.exit(tPosId, vPlayerId);
            m_RoomResultDeal.exit(vPlayerId, tPosId);
            if (vPlayerId == tRoomModel.getRoomMainId())
                settleTotal(DestroyType.MAIN_EXIT);

            tAutoCancelRoomOperate.submit();
            return RoomErrorCode.SUCCESS;
        }
    }

    //换座
    public int changePos(long vPlayerId, int vNewPosId){
        try (IAutoCancelOperate<RoomModel> tAutoCancelRoomOperate = m_RoomFactoryPostern.getRoomModel(m_RoomId)) {
            RoomModel tRoomModel = tAutoCancelRoomOperate.getModel();
            if (RoomStatusType.FIRST_READY != tRoomModel.getRoomStatus() && RoomStatusType.OVER != tRoomModel.getRoomStatus())
                return RoomErrorCode.ALREADY_START;

            if (null == tRoomModel.getPlayerId(vNewPosId))
                return RoomErrorCode.ALREADY;

            tRoomModel.changePos(vNewPosId, vPlayerId);
            m_RoomResultDeal.changePos(vPlayerId, vNewPosId);
            if (vPlayerId == tRoomModel.getRoomMainId())
                settleTotal(DestroyType.MAIN_EXIT);

            tAutoCancelRoomOperate.submit();
            return RoomErrorCode.SUCCESS;
        }
    }

    //准备
    public int ready(long vPlayerId, boolean vReady){
        try (IAutoCancelOperate<RoomModel> tAutoCancelRoomOperate = m_RoomFactoryPostern.getRoomModel(m_RoomId)) {
            RoomModel tRoomModel = tAutoCancelRoomOperate.getModel();
            if (RoomStatusType.FIRST_READY != tRoomModel.getRoomStatus() && RoomStatusType.AGAIN_READY != tRoomModel.getRoomStatus())
                return RoomErrorCode.ALREADY_START;

            Integer tPosId = tRoomModel.getPosId(vPlayerId);
            if (null == tPosId)
                return RoomErrorCode.NOT_EXIST;

            tRoomModel.ready(vPlayerId, vReady);
            m_RoomResultDeal.ready(vPlayerId, vReady);

            //开启游戏
            if (RoomStatusType.PLAYING == tRoomModel.getRoomStatus())
                m_RoomFactoryPostern.startGame(tRoomModel.getRoomId());

            tAutoCancelRoomOperate.submit();
            return RoomErrorCode.SUCCESS;
        }
    }

    //上线
    public int online(long vPlayerId){
        try (IAutoCancelOperate<RoomModel> tAutoCancelRoomOperate = m_RoomFactoryPostern.getRoomModel(m_RoomId)) {
            RoomModel tRoomModel = tAutoCancelRoomOperate.getModel();
            Integer   tPosId     = tRoomModel.getPosId(vPlayerId);
            if (null == tPosId)
                return RoomErrorCode.NOT_EXIST;

            tRoomModel.online(vPlayerId);
            m_RoomResultDeal.online(vPlayerId);
            tAutoCancelRoomOperate.submit();
            return RoomErrorCode.SUCCESS;
        }
    }

    //掉线
    public int offline(long vPlayerId){
        try (IAutoCancelOperate<RoomModel> tAutoCancelRoomOperate = m_RoomFactoryPostern.getRoomModel(m_RoomId)) {
            RoomModel tRoomModel = tAutoCancelRoomOperate.getModel();
            Integer   tPosId     = tRoomModel.getPosId(vPlayerId);
            if (null == tPosId)
                return RoomErrorCode.NOT_EXIST;

            tRoomModel.offline(vPlayerId);
            m_RoomResultDeal.offline(vPlayerId);
            tAutoCancelRoomOperate.submit();
            return RoomErrorCode.SUCCESS;
        }
    }

    //重连
    public int reconnect(long vPlayerId){
        try (IAutoCancelOperate<RoomModel> tAutoCancelRoomOperate = m_RoomFactoryPostern.getRoomModel(m_RoomId)) {
            RoomModel tRoomModel = tAutoCancelRoomOperate.getModel();
            Integer   tPosId     = tRoomModel.getPosId(vPlayerId);
            if (null == tPosId)
                return RoomErrorCode.NOT_EXIST;

            tRoomModel.reconnect(vPlayerId);
            m_RoomResultDeal.reconnect(vPlayerId);
            tAutoCancelRoomOperate.submit();
            return RoomErrorCode.SUCCESS;
        }
    }

    //销毁房间
    public int destroy(int vType){
        try (IAutoCancelOperate<RoomModel> tAutoCancelRoomOperate = m_RoomFactoryPostern.getRoomModel(m_RoomId)) {
            RoomModel tRoomModel = tAutoCancelRoomOperate.getModel();
            if (RoomStatusType.OVER == tRoomModel.getRoomStatus())
                return RoomErrorCode.ALREADY_OVER;

            settleTotal(vType);
            tAutoCancelRoomOperate.submit();
            return RoomErrorCode.SUCCESS;
        }
    }

    //解散房间
    public int dissolve(long vPlayerId, boolean vVote, boolean vStart){
        try (IAutoCancelOperate<RoomModel> tAutoCancelRoomOperate = m_RoomFactoryPostern.getRoomModel(m_RoomId)) {
            RoomModel tRoomModel = tAutoCancelRoomOperate.getModel();
            if (RoomStatusType.OVER == tRoomModel.getRoomStatus())
                return RoomErrorCode.ALREADY_OVER;

            boolean tVoting = tRoomModel.isVoting();
            if (true    == vStart && true == tVoting)       return RoomErrorCode.ALREADY;
            if (false   == vStart && false == tVoting)      return RoomErrorCode.NOT_STARTED;
            if (true    == vStart && false == vVote)        return RoomErrorCode.PARAM_ERROR;
            if (null    == tRoomModel.getPosId(vPlayerId))  return RoomErrorCode.NOT_EXIST;

            int tVoteStatus = vStart ? VoteStatusType.INITIATOR : (vVote ? VoteStatusType.AGREE : VoteStatusType.DISAGREE);
            Map<Long, Integer> tDissolve = tRoomModel.dissolve(vPlayerId, tVoteStatus);

            Boolean tResult = m_DissolveVoteUtil.voteCalculate(tDissolve);
            m_RoomResultDeal.dissolve(tDissolve, tResult);

            if (null != tResult) {
                tRoomModel.cleanVote();
                if (true == tResult)
                    settleTotal(DestroyType.VOTE_DESTROY);
            }

            tAutoCancelRoomOperate.submit();
            return RoomErrorCode.SUCCESS;
        }
    }

    //小结算
    public void settle(GameResult vGameResult){
        try (IAutoCancelOperate<RoomModel> tAutoCancelRoomOperate = m_RoomFactoryPostern.getRoomModel(m_RoomId)) {
            RoomModel tRoomModel = tAutoCancelRoomOperate.getModel();
            tRoomModel.settle(vGameResult);

            if (RoomStatusType.OVER == tRoomModel.getRoomStatus())
                settleTotal(DestroyType.GAME_OVER);

            tAutoCancelRoomOperate.submit();
        }
    }

    private void settleTotal(int vType){
        try (IAutoCancelOperate<RoomModel> tAutoCancelRoomOperate = m_RoomFactoryPostern.getRoomModel(m_RoomId)) {
            RoomModel tRoomModel = tAutoCancelRoomOperate.getModel();
            if (false == tRoomModel.getGameResultList().isEmpty()) {
                tRoomModel.settleTotal();
                m_RoomResultDeal.settleTotal();
            }

            tRoomModel.destroy(vType);
            tAutoCancelRoomOperate.submit();
            m_RoomResultDeal.destroy(vType);
        }
    }
}
