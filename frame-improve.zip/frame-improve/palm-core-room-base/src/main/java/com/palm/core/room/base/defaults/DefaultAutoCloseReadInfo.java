package com.palm.core.room.base.defaults;

import com.palm.core.room.base.abstracts.AbstractAutoCloseReadInfo;
import com.palm.core.room.base.api.model.IAutoCloseReadInfo;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;

public class DefaultAutoCloseReadInfo<TData> extends AbstractAutoCloseReadInfo<TData> {
    protected Lock  m_Lock;

    public DefaultAutoCloseReadInfo(TData vData, Lock vAlreadyLock) {
        super(vData);
        m_Lock = vAlreadyLock;
    }

    public DefaultAutoCloseReadInfo(TData vData, ReadWriteLock vReadWriteLock) {
        super(vData);
        m_Lock = vReadWriteLock.readLock();
        m_Lock.lock();
    }

    @Override
    public void close() {
        m_Lock.unlock();
    }
}
