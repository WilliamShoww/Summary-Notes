package com.palm.core.room.base.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GameResult {
    protected List<Long>         m_WinnerList = new ArrayList();
    protected List<Long>         m_LoserList  = new ArrayList();
    protected Map<Long, Integer> m_ScoreTable = new HashMap();

    public List<Long> getWinnerList() {
        return m_WinnerList;
    }

    public List<Long> getLoserList() {
        return m_LoserList;
    }

    public Map<Long, Integer> getScoreTable() {
        return m_ScoreTable;
    }

    public void setWinnerList(List<Long> vWinnerList) {
        m_WinnerList = vWinnerList;
    }

    public void setLoserList(List<Long> vLoserList) {
        m_LoserList = vLoserList;
    }

    public void setScoreTable(Map<Long, Integer> vScoreTable) {
        m_ScoreTable = vScoreTable;
    }

    public void addWinnerList(long vPlayerId) {
        m_WinnerList.add(vPlayerId);
    }

    public void addLoserList(long vPlayerId) {
        m_LoserList.add(vPlayerId);
    }

    public void putScoreTable(long vPlayerId, int vScore) {
        m_ScoreTable.put(vPlayerId, vScore);
    }
}
