package com.palm.core.room.base.api;

import com.palm.core.room.base.api.model.IAutoCancelOperate;
import com.palm.core.room.base.model.RoomModel;

/**
 * RoomLogic后门
 */
public interface IRoomFactoryPostern {
    public IAutoCancelOperate<RoomModel> getRoomModel(long vRoomId);

    public void startGame(long vRoomId);
}
