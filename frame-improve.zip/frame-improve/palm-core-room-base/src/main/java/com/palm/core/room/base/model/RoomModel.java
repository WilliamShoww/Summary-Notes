package com.palm.core.room.base.model;

import com.palm.core.room.base.enums.PlayerStatusType;
import com.palm.core.room.base.enums.RoomStatusType;
import com.palm.core.room.base.enums.VoteStatusType;

import java.util.HashMap;
import java.util.Map;

/**
 * 房间模型
 */
public class RoomModel extends RoomInfo{
    private RoomModel(){
        super();
    }

    public RoomModel(RoomCreateParam vRoomCreateParam) {
        super();
        m_GameRule      = new HashMap(vRoomCreateParam.getGameRule());
        m_GameSize      = vRoomCreateParam.getGameSize();
        m_GameStyle     = vRoomCreateParam.getGameStyle();
        m_GameType      = vRoomCreateParam.getGameType();
        m_PlayerSize    = vRoomCreateParam.getPlayerSize();
        m_RoomId        = vRoomCreateParam.getRoomId();
        m_RoomMainId    = vRoomCreateParam.getRoomMainId();
        m_AttrEx        = vRoomCreateParam.getAttrEx();
    }

    /**
     * 查询空座位
     * @return
     *      最近的空座位号 null表示玩家已满
     */
    public Integer getVacancyPosId(){
        for (int tPosId = 0; tPosId < m_PlayerList.length; tPosId++) {
            if(null == m_PlayerList[tPosId])
                return tPosId;
        }

        return null;
    }

    /**
     * 通过玩家Id获取座位号
     * @param vPlayerId     玩家Id
     * @return
     *      玩家所在座位号 null表示玩家不在
     */
    public Integer getPosId(long vPlayerId){
        for (RoomPlayerInfo tRoomPlayerInfo : m_PlayerList) {
            if(null != tRoomPlayerInfo && tRoomPlayerInfo.getPlayerId() == vPlayerId)
                return tRoomPlayerInfo.getPlayerIndex();
        }

        return null;
    }

    /**
     * 通过座位号获取玩家Id
     * @param vPosId        座位号
     * @return
     *      该座位的玩家Id null表示该座位是空
     */
    public Long getPlayerId(int vPosId){
        if(null == m_PlayerList[vPosId])
            return null;

        return m_PlayerList[vPosId].getPlayerId();
    }

    /**
     * 进入
     * @param vPosId        座位号
     * @param vPlayerId     玩家Id
     */
    public void join(int vPosId, long vPlayerId){
        RoomPlayerInfo tRoomPlayerInfo = new RoomPlayerInfo();
        tRoomPlayerInfo.setPlayerId(vPlayerId);
        tRoomPlayerInfo.setPlayerIndex(vPosId);
        tRoomPlayerInfo.setPlayerStatus(PlayerStatusType.ONLINE);

        m_PlayerList[vPosId] = tRoomPlayerInfo;
    }

    /**
     * 退出房间
     * @param vPosId        座位号
     * @param vPlayerId     玩家Id
     */
    public void exit(int vPosId, long vPlayerId){
        m_PlayerList[vPosId] = null;
    }

    /**
     * 换座位
     * @param vNewPosId     新座位号
     * @param vPlayerId     玩家Id
     */
    public void changePos(int vNewPosId, long vPlayerId){
        int tOldPosId = getPosId(vPlayerId);
        m_PlayerList[vNewPosId] = m_PlayerList[tOldPosId];
        m_PlayerList[vNewPosId].setPlayerIndex(vNewPosId);
        m_PlayerList[tOldPosId] = null;
    }

    /**
     * 准备
     * @param vPlayerId     玩家Id
     * @param vReady        true：准备 false：取消准备
     */
    public void ready(long vPlayerId, boolean vReady){
        //TODO 不够优雅
        boolean tReadyOver = true;
        for (RoomPlayerInfo tRoomPlayerInfo : m_PlayerList) {
            if(null == tRoomPlayerInfo) {
                tReadyOver = false;
            }else {
                if(vPlayerId == tRoomPlayerInfo.getPlayerId())
                    tRoomPlayerInfo.setReady(vReady);

                if(false == tRoomPlayerInfo.isReady())
                    tReadyOver = false;
            }
        }

        if(true == tReadyOver)
            m_RoomStatus = RoomStatusType.PLAYING;
    }

    /**
     * 上线 回调
     * @param vPlayerId       玩家Id
     */
    public void online(long vPlayerId){
        m_PlayerList[getPosId(vPlayerId)].setPlayerStatus(PlayerStatusType.RECONNECT);
    }

    /**
     * 掉线
     * @param vPlayerId     玩家Id
     */
    public void offline(long vPlayerId){
        m_PlayerList[getPosId(vPlayerId)].setPlayerStatus(PlayerStatusType.OFFLINE);
    }

    /**
     * 重连
     * @param vPlayerId     玩家Id
     */
    public void reconnect(long vPlayerId){
        m_PlayerList[getPosId(vPlayerId)].setPlayerStatus(PlayerStatusType.ONLINE);
    }

    /**
     * 销毁房间
     * @param vType         销毁房间类型->DestroyType
     */
    public void destroy(int vType){
        m_RoomStatus = RoomStatusType.OVER;
        m_DestroyType = vType;
    }

    /**
     * 解散房间
     * @param vPlayerId     玩家Id
     * @param vVoteStatus   投票选择->VoteStatusType
     * @return
     *      投票状态表 玩家Id->投票选择状态->VoteStatusType
     */
    public Map<Long, Integer> dissolve(long vPlayerId, int vVoteStatus){
        Map<Long, Integer> tResult = new HashMap();
        for (RoomPlayerInfo tRoomPlayerInfo : m_PlayerList) {
            if(vPlayerId == tRoomPlayerInfo.getPlayerId())
                tRoomPlayerInfo.setVoteStatus(vVoteStatus);

            tResult.put(tRoomPlayerInfo.getPlayerId(), tRoomPlayerInfo.getVoteStatus());
        }

        m_Voting = true;
        return tResult;
    }

    /**
     * 清空投票
     */
    public void cleanVote(){
        for (RoomPlayerInfo tRoomPlayerInfo : m_PlayerList)
            tRoomPlayerInfo.setVoteStatus(VoteStatusType.UNSELECTED);

        m_Voting = false;
    }

    /**
     * 小结算
     */
    public void settle(GameResult vGameResult){
        m_GameResultList.add(vGameResult);
        for (RoomPlayerInfo tRoomPlayerInfo : m_PlayerList) {
            tRoomPlayerInfo.setReady(false);
            tRoomPlayerInfo.addScore(vGameResult.getScoreTable().get(tRoomPlayerInfo.getPlayerId()));
            if(vGameResult.getWinnerList().contains(tRoomPlayerInfo.getPlayerId()))
                tRoomPlayerInfo.addWinCount();
        }

        if(m_GameResultList.size() == m_GameSize)
            m_RoomStatus = RoomStatusType.OVER;
        else
            m_RoomStatus = RoomStatusType.AGAIN_READY;
    }

    /**
     * 总结算
     */
    public void settleTotal(){
    }
}
