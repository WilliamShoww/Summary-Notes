package com.palm.core.room.base.api.factory;

import com.palm.core.room.base.api.model.IGameLogic;
import com.palm.core.room.base.model.RoomInfo;

/**
 * 游戏工厂接口
 * @param <TGameInfo> 游戏数据模型
 */
public interface IGameFactory<TGameInfo> {
    /**
     * 开始游戏
     * @param vRoomId       房间号
     * @param vRoomInfo     房间信息
     */
    public void gameStart(long vRoomId, RoomInfo vRoomInfo);

    /**
     * 获取游戏逻辑类
     * @param vRoomId   房间号
     * @return
     *      游戏逻辑
     */
    public IGameLogic<TGameInfo> getGameLogic(long vRoomId);

    /**
     * 获取游戏数据
     * @param vRoomId   房间号
     * @return
     *      游戏数据
     */
    public TGameInfo getGameInfo(long vRoomId);

    /**
     * 获取游戏模型
     * @param vRoomId   房间号
     * @return
     *      游戏模型
     */
    public <TGameModel extends TGameInfo> TGameModel getGameModel(long vRoomId);
}
