package com.palm.core.room.base.enums;

public class RoomErrorCode {
    public final static int SUCCESS       = 0;
    public final static int UNKNOWN       = -1;
    public final static int PLAYER_FULL   = -2;
    public final static int EXIST         = -3;
    public final static int NOT_EXIST     = -4;
    public final static int ALREADY_START = -5;
    public final static int ALREADY_OVER  = -6;
    public final static int ALREADY       = -7;
    public final static int NOT_STARTED   = -8;
    public final static int PARAM_ERROR   = -8;
}
