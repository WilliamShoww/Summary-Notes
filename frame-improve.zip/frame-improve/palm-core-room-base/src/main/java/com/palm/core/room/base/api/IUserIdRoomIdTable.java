package com.palm.core.room.base.api;

/**
 * 玩家房间表
 */
public interface IUserIdRoomIdTable {
    /**
     * 更新用户对应房间号
     * @param vUserId   用户Id
     * @param vRoomId   房间Id
     */
    public void update(long vUserId, long vRoomId);

    /**
     * 删除用户对应房间关联
     * @param vUserId   用户Id
     * @param vRoomId   房间Id
     */
    public void remove(long vUserId, long vRoomId);

    /**
     * 获取用户关联房间
     * @param vUserId   用户Id
     * @return
     *      房间Id null表示玩家不在房间内
     */
    public Long getRoomId(long vUserId);
}
