package com.palm.core.room.base.defaults;

import com.palm.core.room.base.abstracts.AbstractRoomFactory;
import com.palm.core.room.base.logic.RoomLogic;
import com.palm.core.room.base.model.RoomModel;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class DefaultRoomFactory extends AbstractRoomFactory {
    protected Map<Long, ReadWriteLock>  m_RoomIdRWLockMap       = new ConcurrentHashMap();
    protected Map<Long, RoomModel>      m_RoomIdRoomModelMap    = new ConcurrentHashMap();
    protected Map<Long, RoomLogic>      m_RoomIdRoomLogicMap    = new ConcurrentHashMap();

    @Override
    protected ReadWriteLock onGetReadWriteLock(long vRoomId) {
        ReadWriteLock tReadWriteLock = m_RoomIdRWLockMap.get(vRoomId);
        if(null == tReadWriteLock){
            synchronized (this){
                tReadWriteLock = m_RoomIdRWLockMap.get(vRoomId);
                if(null == tReadWriteLock){
                    tReadWriteLock = new ReentrantReadWriteLock();
                    m_RoomIdRWLockMap.put(vRoomId, tReadWriteLock);
                }
            }
        }

        return tReadWriteLock;
    }

    @Override
    protected RoomModel onGetRoomModel(long vRoomId) {
        return m_RoomIdRoomModelMap.get(vRoomId);
    }

    @Override
    protected void onSubmitRoomModel(RoomModel vRoomModel) {
        m_RoomIdRoomModelMap.put(vRoomModel.getRoomId(), vRoomModel);
    }

    @Override
    protected void onRemoveRoomModel(long vRoomId) {
        RoomModel tRoomModel = m_RoomIdRoomModelMap.get(vRoomId);
        m_RoomIdRoomModelMap.remove(vRoomId);
        m_RoomIdRoomLogicMap.remove(vRoomId);
        m_RoomIdRWLockMap.remove(vRoomId);
        getRoomResultDealFactory(tRoomModel).removeResultDeal(vRoomId);
    }

    @Override
    public RoomLogic getRoomLogic(long vRoomId) {
        RoomLogic tRoomLogic = m_RoomIdRoomLogicMap.get(vRoomId);
        if(null == tRoomLogic){
            synchronized (this){
                tRoomLogic = m_RoomIdRoomLogicMap.get(vRoomId);
                if(null == tRoomLogic){
                    RoomModel tRoomModel = m_RoomIdRoomModelMap.get(vRoomId);
                    tRoomLogic = new RoomLogic();
                    tRoomLogic.setRoomId(vRoomId);
                    tRoomLogic.setDissolveVoteUtil(getDissolveVoteUtil(tRoomModel));
                    tRoomLogic.setRoomFactoryPostern(this);
                    tRoomLogic.setRoomResultDeal(getRoomResultDealFactory(tRoomModel).createRoomResultDeal(vRoomId));
                    m_RoomIdRoomLogicMap.put(vRoomId, tRoomLogic);
                }
            }
        }

        return tRoomLogic;
    }
}
