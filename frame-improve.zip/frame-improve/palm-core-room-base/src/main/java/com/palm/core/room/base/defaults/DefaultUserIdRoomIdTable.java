package com.palm.core.room.base.defaults;

import com.palm.core.room.base.api.IUserIdRoomIdTable;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class DefaultUserIdRoomIdTable implements IUserIdRoomIdTable{
    private Map<Long, Long> m_UserRoomMap = new ConcurrentHashMap();

    @Override
    public void update(long vUserId, long vRoomId) {
        m_UserRoomMap.put(vUserId, vRoomId);
    }

    @Override
    public void remove(long vUserId, long vRoomId) {
        m_UserRoomMap.remove(vUserId);
    }

    @Override
    public Long getRoomId(long vUserId) {
        return m_UserRoomMap.get(vUserId);
    }
}
