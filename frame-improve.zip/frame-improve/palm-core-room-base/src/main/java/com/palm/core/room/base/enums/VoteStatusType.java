package com.palm.core.room.base.enums;

public class VoteStatusType {
    public final static int UNSELECTED = 0;
    public final static int INITIATOR  = 1;
    public final static int AGREE      = 2;
    public final static int DISAGREE   = 3;
}
