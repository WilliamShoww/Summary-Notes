package com.palm.core.room.base.enums;

public class DestroyType {
    public final static int MAIN_EXIT    = 0;   //房主退出
    public final static int VOTE_DESTROY = 1;   //投票解散
    public final static int GAME_OVER    = 2;   //游戏结束
    public final static int ALL_OFFLINE  = 3;   //全部离线
}
