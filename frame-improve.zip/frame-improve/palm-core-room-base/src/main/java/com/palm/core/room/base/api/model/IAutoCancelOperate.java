package com.palm.core.room.base.api.model;

/**
 * 房间业务处理，内部有事务写锁 需依赖 AutoCloseable自动释放
 * 默认不提交数据 认为操作失败
 * submit 为数据提交
 * @param <TModel>
 */
public interface IAutoCancelOperate<TModel> extends AutoCloseable{
    /**
     * 获取数据模型
     * @return 数据
     */
    public TModel getModel();

    /**
     * 提交本次修改
     */
    public void submit();

    /**
     * 释放锁
     */
    @Override
    public void close();
}