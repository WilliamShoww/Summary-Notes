package com.palm.core.room.base.abstracts;

import com.palm.core.room.base.api.ITimeoutExecutor;
import com.palm.core.room.base.model.TimeoutTask;

import java.util.Map;
import java.util.concurrent.*;

public abstract class AbstractTimeoutExecutor<TData> implements ITimeoutExecutor<TData> {
    protected Map<String, TimeoutTask<TData>>   m_KeyTimeoutTaskMap = new ConcurrentHashMap();
    protected Map<String, ScheduledFuture<?>>   m_KeyFutureMap      = new ConcurrentHashMap();

    protected static ScheduledExecutorService m_ScheduledExecutorService = Executors.newScheduledThreadPool(1);

    @Override
    public void addTask(TimeoutTask<TData> vTimeoutTask) {
        m_KeyTimeoutTaskMap.put(vTimeoutTask.getKey(), vTimeoutTask);
        addTaskToExecutor(vTimeoutTask);
    }

    @Override
    public void subTaskGroup(String vKey) {
        m_KeyTimeoutTaskMap.remove(vKey);
    }

    @Override
    public void playTaskGroup(String vKey) {
        TimeoutTask<TData> tTimeoutTask = m_KeyTimeoutTaskMap.get(vKey);
        if(null != tTimeoutTask)
            addTask(tTimeoutTask);
    }

    @Override
    public void pauseTaskGroup(String vKey) {
        ScheduledFuture<?> tFuture = m_KeyFutureMap.remove(vKey);
        if(null != tFuture)
            tFuture.cancel(false);
    }

    @Override
    public void cancelDelayTask(String vKey) {
        ScheduledFuture<?> tFuture = m_KeyFutureMap.remove(vKey);
        if(null != tFuture && tFuture.cancel(false)) {
            TimeoutTask<TData> tTimeoutTask = m_KeyTimeoutTaskMap.get(vKey);
            tTimeoutTask.setDelayed(0);
            addTask(tTimeoutTask);
        }
    }

    protected void addTaskToExecutor(TimeoutTask<TData> vTimeoutTask){
        m_KeyFutureMap.put(vTimeoutTask.getKey(), m_ScheduledExecutorService.schedule(new ExeRunnable(vTimeoutTask), vTimeoutTask.getDelayed(), TimeUnit.MILLISECONDS));
    }

    protected class ExeRunnable implements Runnable{
        protected TimeoutTask<TData> m_DataTimeoutTask;

        public ExeRunnable(TimeoutTask<TData> vDataTimeoutTask) {
            m_DataTimeoutTask = vDataTimeoutTask;
        }

        @Override
        public void run() {
            try {
                onExecute(m_DataTimeoutTask.getData());
            }catch (Error vError){
                vError.printStackTrace();
            }finally {
                m_KeyTimeoutTaskMap.remove(m_DataTimeoutTask.getKey());
                m_KeyFutureMap.remove(m_DataTimeoutTask.getKey());
            }
        }
    }

    protected abstract void onExecute(TData vTData);
}
