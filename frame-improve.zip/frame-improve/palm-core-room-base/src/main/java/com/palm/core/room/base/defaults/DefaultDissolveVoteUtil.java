package com.palm.core.room.base.defaults;

import com.palm.core.room.base.api.model.IDissolveVoteUtil;
import com.palm.core.room.base.enums.VoteStatusType;

import java.util.Map;

/**
 * 默认投票选举方式（全部同意才通过，一人反对直接否决）
 */
public class DefaultDissolveVoteUtil implements IDissolveVoteUtil {
    @Override
    public Boolean voteCalculate(Map<Long, Integer> vVoteTable) {
        return vVoteTable.containsValue(VoteStatusType.DISAGREE);
    }
}
