package com.palm.core.room.base.api.model;

import java.util.Map;

/**
 * 房间解散投票器 可作为参数在创建房间时预设
 */
public interface IDissolveVoteUtil {
    /**
     * 计算投票结果
     * @param vVoteTable 投票信息 玩家座位号->投票结果
     *                   true同意；false拒绝；null未投票
     * @return
     *      true 解散成功 false 解散失败 null未有结果
     */
    public Boolean voteCalculate(Map<Long, Integer> vVoteTable);
}