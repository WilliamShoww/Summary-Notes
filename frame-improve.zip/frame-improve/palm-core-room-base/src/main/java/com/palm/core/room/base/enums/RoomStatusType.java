package com.palm.core.room.base.enums;

public class RoomStatusType {
    public final static int FIRST_READY = 1;
    public final static int AGAIN_READY = 2;
    public final static int PLAYING     = 3;
    public final static int OVER        = 4;
}
