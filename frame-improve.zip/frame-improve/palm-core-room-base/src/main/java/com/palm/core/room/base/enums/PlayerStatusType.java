package com.palm.core.room.base.enums;

public class PlayerStatusType {
    public final static int ONLINE    = 1;  //在线
    public final static int OFFLINE   = 2;  //掉线
    public final static int RECONNECT = 3;  //重连中
}
