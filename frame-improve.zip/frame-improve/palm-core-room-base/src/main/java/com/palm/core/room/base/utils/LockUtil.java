package com.palm.core.room.base.utils;

import java.util.concurrent.Callable;
import java.util.concurrent.locks.Lock;

public class LockUtil {
    /**
     * 内部开启锁，执行，若失败关闭锁，成功则不关闭锁
     * @param vLock         锁
     * @param vCallable     执行体
     * @param <TClass>      执行体返回结果
     * @return
     *      执行体返回结果
     */
    public static <TClass> TClass lockAndExecute(Lock vLock, Callable<TClass> vCallable){
        vLock.lock();
        try {
            return vCallable.call();
        }catch (Throwable vThrowable){
            vLock.unlock();
            return null;
        }
    }
}
