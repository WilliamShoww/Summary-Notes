package com.palm.core.room.base.abstracts;

import com.palm.common.kit.AutoLock;
import com.palm.core.room.base.api.IRoomFactory;
import com.palm.core.room.base.api.IRoomFactoryPostern;
import com.palm.core.room.base.api.IUserIdRoomIdTable;
import com.palm.core.room.base.api.factory.IGameFactory;
import com.palm.core.room.base.api.factory.IRoomResultDealFactory;
import com.palm.core.room.base.api.model.*;
import com.palm.core.room.base.defaults.DefaultAutoCloseReadInfo;
import com.palm.core.room.base.defaults.DefaultDissolveVoteUtil;
import com.palm.core.room.base.logic.RoomLogic;
import com.palm.core.room.base.model.*;
import com.palm.core.room.base.utils.CompareUtil;
import com.palm.core.room.base.utils.LockUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;

/**
 * 房间工厂抽象
 */
public abstract class AbstractRoomFactory implements IRoomFactory, IRoomFactoryPostern {
    protected Map<Integer, IDissolveVoteUtil>         m_GameTypeVoteUtilMap     = new ConcurrentHashMap();
    protected Map<Integer, IGameFactory>              m_GameTypeGameFactoryMap  = new ConcurrentHashMap();
    protected Map<Integer, IRoomResultDealFactory>    m_GameTypeDealFactoryMap  = new ConcurrentHashMap();

    protected Map<Long, IDissolveVoteUtil>        m_GameTypeGameStyleVoteUtilMap    = new ConcurrentHashMap();
    protected Map<Long, IGameFactory>             m_GameTypeGameStyleGameFactoryMap = new ConcurrentHashMap();
    protected Map<Long, IRoomResultDealFactory>   m_GameTypeGameStyleDealFactoryMap = new ConcurrentHashMap();

    protected Map<Long, Long>       m_RoomIdWriteThreadIdMap    = new ConcurrentHashMap();
    protected Map<Long, RoomModel>  m_RoomIdWriteModelMap       = new ConcurrentHashMap();

    protected IRoomResultDealFactory m_DefaultRoomResultDealFactory;

    protected IUserIdRoomIdTable m_UserIdRoomIdTable;

    //获取读写锁
    protected abstract ReadWriteLock onGetReadWriteLock(long vRoomId);

    //获取数据
    protected abstract RoomModel onGetRoomModel(long vRoomId);

    //提交数据
    protected abstract void onSubmitRoomModel(RoomModel vRoomModel);

    //提交数据
    protected abstract void onRemoveRoomModel(long vRoomId);

    @Override
    public void setDissolveVoteUtil(int vGameType, IDissolveVoteUtil vDissolveVoteUtil) {
        m_GameTypeVoteUtilMap.put(vGameType, vDissolveVoteUtil);
    }

    @Override
    public void setDissolveVoteUtil(int vGameType, int vGameStyle, IDissolveVoteUtil vDissolveVoteUtil) {
        m_GameTypeGameStyleVoteUtilMap.put(joint(vGameType, vGameStyle), vDissolveVoteUtil);
    }

    @Override
    public void setRoomResultDealFactory(int vGameType, IRoomResultDealFactory vRoomResultDealFactory) {
        m_GameTypeDealFactoryMap.put(vGameType, vRoomResultDealFactory);

    }

    @Override
    public void setRoomResultDealFactory(int vGameType, int vGameStyle, IRoomResultDealFactory vRoomResultDealFactory) {
        m_GameTypeGameStyleDealFactoryMap.put(joint(vGameType, vGameStyle), vRoomResultDealFactory);
    }

    @Override
    public void setDefaultRoomResultDealFactory(IRoomResultDealFactory vDefaultRoomResultDealFactory) {
        m_DefaultRoomResultDealFactory = vDefaultRoomResultDealFactory;
    }

    @Override
    public void setGameFactory(int vGameType, IGameFactory vGameFactory) {
        m_GameTypeGameFactoryMap.put(vGameType, vGameFactory);
    }

    @Override
    public void setGameFactory(int vGameType, int vGameStyle, IGameFactory vGameFactory) {
        m_GameTypeGameStyleGameFactoryMap.put(joint(vGameType, vGameStyle), vGameFactory);
    }

    @Override
    public void setUserIdRoomIdTable(IUserIdRoomIdTable vUserIdRoomIdTable) {
        m_UserIdRoomIdTable = vUserIdRoomIdTable;
    }

    @Override
    public void createRoom(RoomCreateParam vRoomCreateParam){
        try (AutoLock tAutoLock = new AutoLock(onGetReadWriteLock(vRoomCreateParam.getRoomId()).writeLock())){
            onSubmitRoomModel(new RoomModel(vRoomCreateParam));
        }
    }

    @Override
    public IAutoCloseReadInfo<RoomInfo> getRoomInfo(final long vRoomId) {
        final Lock tLock = onGetReadWriteLock(vRoomId).readLock();
        return LockUtil.lockAndExecute(tLock, new Callable<IAutoCloseReadInfo<RoomInfo>>() {
            @Override
            public IAutoCloseReadInfo<RoomInfo> call() throws Exception {
                return new DefaultAutoCloseReadInfo(onGetRoomModel(vRoomId), tLock);
            }
        });
    }

    @Override
    public IAutoCloseReadInfo<RoomInfo> borrowRoomInfo(long vRoomId) {
        Long tThreadId = m_RoomIdWriteThreadIdMap.get(vRoomId);
        if(null != tThreadId && tThreadId == Thread.currentThread().getId())
            return new AbstractAutoCloseReadInfo<RoomInfo>(m_RoomIdWriteModelMap.get(vRoomId)) {@Override public void close() {}};

        return getRoomInfo(vRoomId);
    }

    @Override
    public Map<Integer, Long> queryPosTable(long vRoomId) {
        try (IAutoCloseReadInfo<RoomInfo> tRoomInfoIAutoCloseReadInfo = borrowRoomInfo(vRoomId)){
            RoomInfo tRoomInfo = tRoomInfoIAutoCloseReadInfo.getData();
            if(null == tRoomInfo)
                return null;

            Map<Integer, Long> tResult = new HashMap();
            for (RoomPlayerInfo tRoomPlayerInfo : tRoomInfo.getPlayerList()) {
                tResult.put(tRoomPlayerInfo.getPlayerIndex(), tRoomPlayerInfo.getPlayerId());
            }

            return tResult;
        }
    }

    @Override
    public void removeRoom(long vRoomId) {
        try (AutoLock tAutoLock = new AutoLock(onGetReadWriteLock(vRoomId).writeLock())){
            RoomModel tRoomModel = onGetRoomModel(vRoomId);
            for (RoomPlayerInfo tRoomPlayerInfo : tRoomModel.getPlayerList())
                m_UserIdRoomIdTable.remove(tRoomPlayerInfo.getPlayerId(), vRoomId);

            getRoomResultDealFactory(tRoomModel).removeResultDeal(vRoomId);
            onRemoveRoomModel(vRoomId);
        }
    }

    @Override
    public RoomLogic getRoomLogic(final long vRoomId) {
        RoomModel tRoomModel = onGetRoomModel(vRoomId);
        RoomLogic tRoomLogic = new RoomLogic();
        tRoomLogic.setRoomId(vRoomId);
        tRoomLogic.setDissolveVoteUtil(getDissolveVoteUtil(tRoomModel));
        tRoomLogic.setRoomFactoryPostern(this);
        tRoomLogic.setRoomResultDeal(getRoomResultDealFactory(tRoomModel).createRoomResultDeal(vRoomId));
        return tRoomLogic;
    }

    @Override
    public void settle(Long vRoomId, GameResult vGameResult) {
        RoomLogic tRoomLogic = getRoomLogic(vRoomId);
        tRoomLogic.settle(vGameResult);
    }

    @Override
    public int doSomething(long vRoomId, IRoomOperate vRoomOperate) {
        try (AutoLock tAutoLock = new AutoLock(onGetReadWriteLock(vRoomId).writeLock())){
            return vRoomOperate.onOperate(onGetRoomModel(vRoomId));
        }
    }

    @Override
    public void startGame(long vRoomId){
        try (IAutoCloseReadInfo<RoomInfo> tRoomInfoIAutoCloseReadInfo = borrowRoomInfo(vRoomId)){
            RoomInfo tRoomInfo = tRoomInfoIAutoCloseReadInfo.getData();
            IGameFactory tGameFactory = getGameFactory(tRoomInfo);
            tGameFactory.gameStart(vRoomId, tRoomInfo);
        }
    }

    @Override
    public IAutoCancelOperate<RoomModel> getRoomModel(final long vRoomId) {
        final Lock tLock = onGetReadWriteLock(vRoomId).writeLock();
        return LockUtil.lockAndExecute(tLock, new Callable<IAutoCancelOperate<RoomModel>>() {
            @Override
            public IAutoCancelOperate<RoomModel> call() throws Exception {
                return new AbstractAutoCancelOperate<RoomModel>(onGetRoomModel(vRoomId), tLock) {
                    @Override
                    public void submit() {
                        Long[] tOldUserList = new Long[m_Model.getPlayerSize()];
                        for (int tPlayerIndex = 0; tPlayerIndex < m_Model.getPlayerList().length; tPlayerIndex++)
                            tOldUserList[tPlayerIndex] = null == m_Model.getPlayerList()[tPlayerIndex] ? null : m_Model.getPlayerList()[tPlayerIndex].getPlayerId();

                        onSubmitRoomModel(m_Model);

                        for (int tPlayerIndex = 0; tPlayerIndex < m_Model.getPlayerList().length; tPlayerIndex++) {
                            Long tOldUserId = tOldUserList[tPlayerIndex];
                            Long tNewUserId = null == m_Model.getPlayerList()[tPlayerIndex] ? null : m_Model.getPlayerList()[tPlayerIndex].getPlayerId();
                            if(false == CompareUtil.some(tNewUserId, tOldUserId)){
                                if(null == tOldUserId)
                                    m_UserIdRoomIdTable.update(tNewUserId, m_Model.getRoomId());
                                else
                                    m_UserIdRoomIdTable.remove(tOldUserId, m_Model.getRoomId());
                            }
                        }
                    }
                };
            }
        });
    }

    protected long joint(int vGameType, int vGameStyle){
        return (long) vGameType << 32 | vGameStyle;
    }

    /**
     * 获取投票抉择工具
     * @param vRoomInfo     房间信息
     * @return  投票工具
     */
    protected IDissolveVoteUtil getDissolveVoteUtil(RoomInfo vRoomInfo){
        IDissolveVoteUtil tDissolveVoteUtil = m_GameTypeGameStyleVoteUtilMap.get(joint(vRoomInfo.getGameType(), vRoomInfo.getGameStyle()));
        if(null == tDissolveVoteUtil)
            tDissolveVoteUtil = m_GameTypeVoteUtilMap.get(vRoomInfo.getGameType());

        if(null == tDissolveVoteUtil)
            tDissolveVoteUtil = new DefaultDissolveVoteUtil();

        return tDissolveVoteUtil;
    }

    /**
     * 获取游戏工厂
     * @param vRoomInfo     房间信息
     * @return  游戏工厂
     */
    protected IGameFactory getGameFactory(RoomInfo vRoomInfo){
        IGameFactory tGameFactory = m_GameTypeGameStyleGameFactoryMap.get(joint(vRoomInfo.getGameType(), vRoomInfo.getGameStyle()));
        if(null == tGameFactory)
            tGameFactory = m_GameTypeGameFactoryMap.get(vRoomInfo.getGameType());

        return tGameFactory;
    }

    /**
     * 获取结果处理工具工厂
     * @param vRoomInfo     房间信息
     * @return  结果处理工厂
     */
    protected IRoomResultDealFactory getRoomResultDealFactory(RoomInfo vRoomInfo){
        IRoomResultDealFactory tRoomResultDealFactory = m_GameTypeGameStyleDealFactoryMap.get(joint(vRoomInfo.getGameType(), vRoomInfo.getGameStyle()));
        if(null == tRoomResultDealFactory)
            tRoomResultDealFactory = m_GameTypeDealFactoryMap.get(vRoomInfo.getGameType());

        if(null == tRoomResultDealFactory)
            tRoomResultDealFactory = m_DefaultRoomResultDealFactory;

        return tRoomResultDealFactory;
    }
}
