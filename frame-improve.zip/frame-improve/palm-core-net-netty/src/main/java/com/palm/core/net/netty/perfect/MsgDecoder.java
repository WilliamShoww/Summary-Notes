package com.palm.core.net.netty.perfect;

import com.google.protobuf.Message;
import com.palm.core.net.base.api.utils.IMessageTransverter;
import com.palm.core.net.base.model.MessagePackage;
import com.palm.core.net.netty.util.ByteUtil;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.xxtea.XXTEA;

import java.util.List;

@Component
@Scope("prototype")
public class MsgDecoder extends ByteToMessageDecoder {
    private final Logger m_Logger = LoggerFactory.getLogger(getClass());
    private static final String KEY = "akiAABI668lh";

    @Autowired
    private IMessageTransverter m_MessageTransverter;

    @Override
    protected void decode(ChannelHandlerContext vChannelHandlerContext, ByteBuf vByteBuf, List<Object> vList) throws Exception {
        //TODO 待整理
        //查看数据包大小
        vByteBuf.resetReaderIndex();
        if (4 > vByteBuf.readableBytes() || vByteBuf.readableBytes() < ByteUtil.readInt(vByteBuf)) {
            vByteBuf.resetReaderIndex();
            m_Logger.info("msg short.");
            return;
        }

        //提取特定数据组
        long tSessionId = ByteUtil.readInt(vByteBuf);
        long tUserId = ByteUtil.readInt(vByteBuf);
        long tMsgNum = ByteUtil.readInt(vByteBuf);

        if (1 != tMsgNum) {
            m_Logger.warn("msg num overstep!");
            vByteBuf.clear();
            return;
        }

        //TODO 数据解析长度等还需商榷

        //解析数据
        int tCode = ByteUtil.readInt(vByteBuf);
        int tMsgLen = ByteUtil.readInt(vByteBuf);


        ByteBuf tempByte = vByteBuf.readBytes(tMsgLen);
        byte[] msgBodyBefore = new byte[tempByte.readableBytes()];
        tempByte.getBytes(0, msgBodyBefore);
        tempByte.release();

        Message tMessage = m_MessageTransverter.decode(tCode, XXTEA.decrypt(msgBodyBefore, KEY));
        if (null == tMessage) {
            m_Logger.error("msg encode error! Code="+tCode);
            vByteBuf.clear();
            return;
        }

        //添加到数据包
        vList.add(new MessagePackage(tMessage, tCode, tSessionId, tUserId));
    }
}
