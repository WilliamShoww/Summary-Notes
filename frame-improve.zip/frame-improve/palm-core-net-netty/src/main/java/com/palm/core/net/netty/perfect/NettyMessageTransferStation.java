package com.palm.core.net.netty.perfect;

import com.palm.core.net.base.api.base.ICallBase;
import com.palm.core.net.base.api.net.IAcceptMessageBySession;
import com.palm.core.net.base.api.net.ISendMessageBySession;
import com.palm.core.net.base.model.MessageFromEnum;
import com.palm.core.net.base.model.MessagePackage;
import com.palm.core.net.netty.model.SessionInfo;
import io.netty.channel.*;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.List;

@Component
@ChannelHandler.Sharable
public class NettyMessageTransferStation extends ChannelInboundHandlerAdapter implements ISendMessageBySession{
    private static final Logger LOGGER = LoggerFactory.getLogger(NettyMessageTransferStation.class);

    @Autowired
    private IAcceptMessageBySession m_AcceptMessageBySession;

    @Autowired
    private SessionManager          m_SessionManager;

    @Override
    public void channelActive(ChannelHandlerContext vChannelHandlerContext) throws Exception {
        Channel tChannel = vChannelHandlerContext.channel();
        long tCode = m_SessionManager.addSession(tChannel);
        LOGGER.info(String.format("channelActive Address=%s id=%s", ((InetSocketAddress)tChannel.remoteAddress()).getAddress(), tCode));
    }

    @Override
    public void handlerAdded(ChannelHandlerContext vChannelHandlerContext){
        Channel tChannel = vChannelHandlerContext.channel();
        LOGGER.info(String.format("handlerAdded Address=%s", ((InetSocketAddress)tChannel.remoteAddress()).getAddress()));
    }

    @Override
    public void handlerRemoved(ChannelHandlerContext vChannelHandlerContext){
        Channel tChannel = vChannelHandlerContext.channel();
        long tSessionId = m_SessionManager.invalidate(tChannel);
        m_AcceptMessageBySession.disconnect(tSessionId);
        tChannel.close();
        vChannelHandlerContext.close();
        LOGGER.info(String.format("handlerRemoved Address=%s id=%s", ((InetSocketAddress)tChannel.remoteAddress()).getAddress(), tSessionId));
    }

    @Override
    public void channelInactive(ChannelHandlerContext vChannelHandlerContext) throws Exception {
        Channel tChannel = vChannelHandlerContext.channel();
        long tSessionId = m_SessionManager.invalidate(tChannel);
        LOGGER.info(String.format("channelInactive Address=%s id=%s", ((InetSocketAddress)tChannel.remoteAddress()).getAddress(), tSessionId));
    }

    @Override
    public void channelRead(ChannelHandlerContext vChannelHandlerContext, Object vO) {
        SessionInfo tSessionInfo = m_SessionManager.getSessionInfo(vChannelHandlerContext.channel());

        if(vO instanceof List){
            for (MessagePackage tMessagePackage : (List<MessagePackage>) vO)
                dealMessage(tSessionInfo, tMessagePackage);
        }else {
            dealMessage(tSessionInfo, (MessagePackage) vO);
        }

        m_SessionManager.action(vChannelHandlerContext.channel());
    }

    @Override
    public ChannelFuture send(MessagePackage vMessagePackage) {
        Channel tChannel = m_SessionManager.getChannel(vMessagePackage.getSessionId());
        if(null == tChannel)
            return null;

        return tChannel.writeAndFlush(vMessagePackage);
    }

    @Override
    public void send(final MessagePackage vMessagePackage, final ICallBase vCall) {
        Channel tChannel = m_SessionManager.getChannel(vMessagePackage.getSessionId());
        if(null == tChannel) {
            if(null != vCall)
                vCall.onCall(false);

            LOGGER.debug("msg send fail!!! not channel, vMessagePackage", vMessagePackage);
            return;
        }

        ChannelFuture tChannelFuture = tChannel.writeAndFlush(vMessagePackage);
        tChannelFuture.addListener(new GenericFutureListener<Future<Void>>() {
            @Override
            public void operationComplete(Future<Void> vFuture){
                if(null != vCall)
                    vCall.onCall(vFuture.isSuccess());

                if(false == vFuture.isSuccess())
                    LOGGER.warn("msg send fail!!! vMessagePackage", vMessagePackage, vFuture.cause());
            }
        });
    }

    @Override
    public void resetOrder(long vSessionId) {
        m_SessionManager.resetOrder(vSessionId);
    }

    @Override
    public InetAddress getAddress(long vSessionId) {
        Channel tChannel = m_SessionManager.getChannel(vSessionId);
        if(null == tChannel)
            return null;

        return ((InetSocketAddress)tChannel.remoteAddress()).getAddress();
    }

    @Override
    public void kickSession(long vSessionId) {
        Channel tChannel = m_SessionManager.getChannel(vSessionId);
        LOGGER.debug("kick session! sessionId=%s", vSessionId);
        if(null != tChannel)
            tChannel.close();
    }

    private void dealMessage(SessionInfo vSessionInfo, MessagePackage vMessagePackage){
        vMessagePackage.setSessionId(vSessionInfo.getSessionId());
        m_AcceptMessageBySession.accept(vMessagePackage, MessageFromEnum.NORMAL);
    }
}
