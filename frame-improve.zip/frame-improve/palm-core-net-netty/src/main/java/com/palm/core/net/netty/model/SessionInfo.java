package com.palm.core.net.netty.model;

import io.netty.channel.Channel;

/**
 * 会话信息封装
 */
public class SessionInfo {
    private long    m_SessionId;    //会话Id
    private Channel m_Channel;      //链接，用于辨别用户 发送消息
    private long    m_LastDate;     //最后时间
    private long    m_Order;        //消息顺序编号

    public SessionInfo(long vSessionId, Channel vChannel) {
        m_SessionId = vSessionId;
        m_Channel = vChannel;
        m_LastDate = System.currentTimeMillis();
    }

    public long getSessionId() {
        return m_SessionId;
    }

    public Channel getChannel() {
        return m_Channel;
    }

    /**
     * 获取最后请求时间
     */
    public synchronized long getLastDate() {
        return m_LastDate;
    }

    /**
     * 设置最后请求时间
     */
    public synchronized void setLastDate(long vLastDate) {
        m_LastDate = vLastDate;
    }

    /**
     * 重置消息编号
     */
    public synchronized void resetOrder(){
        m_Order = 0;
    }

    /**
     * 获取新的消息编号 （自增）
     */
    public synchronized long getOrder() {
        return ++m_Order;
    }
}
