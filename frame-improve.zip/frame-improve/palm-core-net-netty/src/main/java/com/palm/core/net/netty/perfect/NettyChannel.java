package com.palm.core.net.netty.perfect;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import javax.annotation.PreDestroy;

@Component
public class NettyChannel implements ApplicationListener<ApplicationReadyEvent>, ApplicationContextAware{
    private final static Logger LOGGER = LoggerFactory.getLogger(NettyChannel.class);

    private ApplicationContext m_ApplicationContext;

    @Value("${server.net.netty.port:8081}")
    private int m_ServerPort;

    private EventLoopGroup m_ParentGroup    = new NioEventLoopGroup(16);
    private EventLoopGroup m_ChildGroup     = new NioEventLoopGroup(16);

    @PreDestroy
    public void uninit(){
        m_ParentGroup.shutdownGracefully();
        m_ChildGroup.shutdownGracefully();
    }

    @Override
    public void setApplicationContext(ApplicationContext vApplicationContext) throws BeansException {
        m_ApplicationContext = vApplicationContext;
    }

    @Override
    public void onApplicationEvent(ApplicationReadyEvent applicationReadyEvent) {
        try{
            ServerBootstrap tServerBootstrap = new ServerBootstrap();
            tServerBootstrap.group(m_ParentGroup, m_ChildGroup)
                    .channel(NioServerSocketChannel.class)
                    .option(ChannelOption.SO_BACKLOG, 128)
                    .childHandler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        public void initChannel(SocketChannel vSocketChannel) throws Exception {
                            vSocketChannel.pipeline().addLast(
                                    m_ApplicationContext.getBean(MsgDecoder.class),
                                    m_ApplicationContext.getBean(MsgEncoder.class),
                                    m_ApplicationContext.getBean(NettyMessageTransferStation.class));
                        }
                    });

            tServerBootstrap.option(ChannelOption.TCP_NODELAY, true);
            tServerBootstrap.option(ChannelOption.SO_KEEPALIVE,true);
            tServerBootstrap.option(ChannelOption.SO_TIMEOUT,30);
            tServerBootstrap.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 30);
            tServerBootstrap.bind(m_ServerPort).sync();

            LOGGER.info("netty config succeed!!! server.net.netty.port:"+m_ServerPort);
        }catch (Exception e){
            LOGGER.error("netty start error", e);
            System.exit(-1);
        }
    }
}
