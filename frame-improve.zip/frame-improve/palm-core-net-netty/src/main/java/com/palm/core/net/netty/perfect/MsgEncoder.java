package com.palm.core.net.netty.perfect;

import com.palm.core.net.base.api.utils.IMessageTransverter;
import com.palm.core.net.base.model.MessagePackage;
import com.palm.core.net.netty.util.ByteUtil;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.xxtea.XXTEA;

@Component
@Scope("prototype")
public class MsgEncoder extends MessageToByteEncoder<MessagePackage> {
    private static final String KEY = "akiAABI668lh";

    @Autowired
    private IMessageTransverter m_MessageTransverter;
    @Autowired
    private SessionManager m_SessionManager;

    @Override
    protected void encode(ChannelHandlerContext vChannelHandlerContext, MessagePackage vMessagePackage, ByteBuf vByteBuf) throws Exception {
        //TODO 待整理
        int tSessionId  = (int)vMessagePackage.getSessionId();
        int tCode       = (int)m_MessageTransverter.getCode(vMessagePackage.getMessage());
        int tRespOrder  = -1;
        int tUserId     = null == vMessagePackage.getUserId() ? -1 : (int)(long)vMessagePackage.getUserId();
        byte[] tData    = XXTEA.encrypt(vMessagePackage.getMessage().toByteArray(), KEY);

        //TODO 过于恶心 先预留
        String tName = vMessagePackage.getMessage().getClass().getSimpleName();
        if(tCode > 1000 && tCode != 90003 && !tName.contains("NotifyTimes")
                &&!tName.contains("ChoseMaJiang") &&!tName.contains("ChoseGoldYard")
                && !tName.contains("QuickStart")){
            tRespOrder = (int) m_SessionManager.getOrder(vMessagePackage.getSessionId());
        }

        ByteUtil.writeInt(vByteBuf, 6 * Integer.SIZE / Byte.SIZE + tData.length);
        ByteUtil.writeInt(vByteBuf, tRespOrder);
        ByteUtil.writeInt(vByteBuf, tUserId);
        ByteUtil.writeInt(vByteBuf, tSessionId);
        ByteUtil.writeInt(vByteBuf, 1);
        ByteUtil.writeInt(vByteBuf, tCode);
        ByteUtil.writeInt(vByteBuf, tData.length);
        vByteBuf.writeBytes(tData);
    }
}
