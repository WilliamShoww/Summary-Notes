package com.palm.core.dome.model;

public enum TypeEnum {
    sd,asd;
}
