package com.palm.core.dome;

import com.handmobi.message.MyMessage;
import com.palm.core.net.base.api.needperfect.INotLoginExecuteHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

@Controller
public class NotLoginExecuteHandler implements INotLoginExecuteHandler<MyMessage.NewReconnectRequest, MyMessage.NewReconnectResponse> {
    private final static Logger LOGGER = LoggerFactory.getLogger(NotLoginExecuteHandler.class);
    @Override
    public MyMessage.NewReconnectResponse onExecute(MyMessage.NewReconnectRequest vTMessage) {
        LOGGER.info("execute NotLoginExecuteHandler!!!");
        MyMessage.NewReconnectResponse.Builder tBuilder = MyMessage.NewReconnectResponse.newBuilder();
        tBuilder.setReturnCode(MyMessage.NewReconnectResponse.ErrCode.Success);
        return tBuilder.build();
    }
}

