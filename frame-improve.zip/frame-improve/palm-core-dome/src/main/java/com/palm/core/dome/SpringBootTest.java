package com.palm.core.dome;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com")
@SpringBootApplication //Spring Boot核心注解，用于开启自动配置
public class SpringBootTest {
    private final static Logger LOGGER = LoggerFactory.getLogger(SpringBootTest.class);
    public static void main(String[] vArgs) {
        SpringApplication.run(SpringBootTest.class, vArgs);
        LOGGER.info("server start over!!!");
    }
}
