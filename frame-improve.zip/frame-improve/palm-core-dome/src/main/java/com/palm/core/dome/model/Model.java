package com.palm.core.dome.model;

import com.baidu.bjf.remoting.protobuf.annotation.Protobuf;
import com.palm.jprotobuf.Message;
import com.palm.jprotobuf.MessageType;

@Message(code = 100, note = "模型类", type = MessageType.INLINE)
public class Model {
    @Protobuf
    private String name;
    @Protobuf
    private int id;
    @Protobuf
    private String email;
    @Protobuf
    private Double doubleF;
    @Protobuf
    private Float floatF;

//    @Protobuf(fieldType = FieldType.BYTES, order=6, required = false)
    private byte[] bytesF;

//    @Protobuf(fieldType= FieldType.BOOL, order=7, required=false)
    private Boolean boolF;

    public String getName() {
        return name;
    }

    public void setName(String vName) {
        name = vName;
    }

    public int getId() {
        return id;
    }

    public void setId(int vId) {
        id = vId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String vEmail) {
        email = vEmail;
    }

    public Double getDoubleF() {
        return doubleF;
    }

    public void setDoubleF(Double vDoubleF) {
        doubleF = vDoubleF;
    }

    public Float getFloatF() {
        return floatF;
    }

    public void setFloatF(Float vFloatF) {
        floatF = vFloatF;
    }

    public byte[] getBytesF() {
        return bytesF;
    }

    public void setBytesF(byte[] vBytesF) {
        bytesF = vBytesF;
    }

    public Boolean getBoolF() {
        return boolF;
    }

    public void setBoolF(Boolean vBoolF) {
        boolF = vBoolF;
    }
}
