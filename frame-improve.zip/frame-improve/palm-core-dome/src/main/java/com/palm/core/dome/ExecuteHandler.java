package com.palm.core.dome;

import com.handmobi.message.BenzBmwMessage;
import com.palm.core.net.base.annotations.HandlerDispatch;
import com.palm.core.net.base.api.needperfect.IExecuteHandler;
import com.palm.core.net.base.model.MessageFromEnum;
import com.palm.core.net.base.model.MessagePackage;
import com.palm.core.net.base.perfect.MessageTransferManager;
import com.palm.core.net.base.perfect.MessageTransverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Controller
@HandlerDispatch(threadKey = "asdas")
public class ExecuteHandler implements IExecuteHandler<BenzBmwMessage.BenzBmwBetRequest> {
    @Autowired
    private MessageTransferManager m_messageTransferManager;
    @Autowired
    private MessageTransverter m_messageTransverter;

    @Autowired
    private MessageTransferManager m_iAcceptMessageBySession;

    @PostConstruct
    public void init(){
        new Thread(){
            @Override
            public void run() {
                try {
                    sleep(5000);
//                    m_iAcceptMessageBySession.add(1,1);

                    BenzBmwMessage.BenzBmwBetRequest tBenzBmwBetRequest = BenzBmwMessage.BenzBmwBetRequest.newBuilder().build();
                    MessagePackage                   tMessagePackage   = new MessagePackage(tBenzBmwBetRequest, m_messageTransverter.getCode(tBenzBmwBetRequest), 1, 1L);

                    while (true) {
//                        sleep(1000);
                        m_messageTransferManager.accept(tMessagePackage, MessageFromEnum.OTHER);
                    }

                } catch (Exception vE) {
                    vE.printStackTrace();
                }
            }
        }.start();
    }

    private List<Long> m_UserIdList = new CopyOnWriteArrayList<>();

    @Override
    public void onExecute(long vUserId, BenzBmwMessage.BenzBmwBetRequest vBenzBmwBetRequest) {
//        m_UserIdList.add(vUserId);
//
//        if(1 != m_UserIdList.size())
//            System.out.printf("asdssdsad=>%s", m_UserIdList);

        BenzBmwMessage.BenzBmwBetResponse.Builder tBuilder = BenzBmwMessage.BenzBmwBetResponse.newBuilder();
        tBuilder.setReturnCode(BenzBmwMessage.BenzBmwBetResponse.ErrCode.CoinNotEnough);
//        m_UserIdList.remove(vUserId);/
        m_messageTransferManager.send(tBuilder.build(), vUserId);
    }
}
