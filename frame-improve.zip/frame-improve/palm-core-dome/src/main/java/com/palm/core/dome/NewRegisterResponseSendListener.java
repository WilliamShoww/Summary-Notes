package com.palm.core.dome;

import com.google.protobuf.Message;
import com.handmobi.message.MyMessage;
import com.palm.core.net.base.annotations.Detection;
import com.palm.core.net.base.api.needperfect.ISendListener;
import org.springframework.stereotype.Component;

@Detection(massage = MyMessage.NewRegisterResponse.class)
@Component
public class NewRegisterResponseSendListener implements ISendListener{
    @Override
    public void onSendStart(long vUserId, Message vTMessage) {
        System.out.println("onSendStart");
    }

    @Override
    public void onSendSucceed(long vUserId, Message vTMessage) {
        System.out.println("onSendStart");
    }

    @Override
    public void onSendFail(long vUserId, Message vTMessage) {
        System.out.println("onSendStart");
    }
}
