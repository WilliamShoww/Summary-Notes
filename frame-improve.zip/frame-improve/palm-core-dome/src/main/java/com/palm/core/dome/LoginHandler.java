package com.palm.core.dome;

import com.palm.core.net.base.api.needperfect.ILoginHandler;
import com.palm.core.net.base.api.utils.ISendMessageKit;
import com.palm.core.net.base.model.LoginResult;
import com.handmobi.message.MyMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.net.InetAddress;

@Controller
public class LoginHandler implements ILoginHandler<MyMessage.LoginRequest, MyMessage.LoginResponse> {
    @Autowired
    private ISendMessageKit m_SendMessageKit;

    @Override
    public LoginResult<MyMessage.LoginResponse> onLogin(MyMessage.LoginRequest vTLoginMessage, InetAddress vInetAddress) {
        MyMessage.NewRegisterResponse.Builder tBuilder = MyMessage.NewRegisterResponse.newBuilder();
        tBuilder.setReturnCode(MyMessage.NewRegisterResponse.ErrCode.Fail);
        m_SendMessageKit.send(tBuilder.build(), 2L);

        MyMessage.LoginResponse.Builder builder =  MyMessage.LoginResponse.newBuilder();
        builder.setReturnCode(MyMessage.LoginResponse.ErrCode.PasswordError);
        return new LoginResult(1L, builder.build());
    }

    @Override
    public void onDisconnect(long vUserId) {

    }
}
