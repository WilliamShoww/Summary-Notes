package com.palm.core.dome;

import com.palm.jprotobuf.MakeProtocolFileKit;

import java.io.IOException;

public class ProtocolTest {
    public static void main(String[] args) throws IOException {
        MakeProtocolFileKit.makeAndCreate("com.palm.jprotobuf", "G:\\pro\\frame-improve\\palm-core-jprotobuf\\target\\proto");

//        Set<Class<?>> tInlineClass = new LinkedHashSet();
//        Set<Class<?>> cachedEnumTypes = new LinkedHashSet();
//        tInlineClass.add(Model.class);
//        String tIDL = ProtobufIDLGenerator.getIDL(Model.class);
//        System.out.println(tInlineClass);
//        System.out.println(cachedEnumTypes);
//        System.out.println(tIDL);
//        try (FileOutputStream tFileOutputStream = new FileOutputStream("d:asd.proto")){
//            tFileOutputStream.write(tIDL.getBytes());
//        }
    }
}
