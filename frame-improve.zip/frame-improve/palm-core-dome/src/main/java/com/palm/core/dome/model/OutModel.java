package com.palm.core.dome.model;

import com.baidu.bjf.remoting.protobuf.annotation.Protobuf;
import com.palm.jprotobuf.Message;
import com.palm.jprotobuf.MessageType;

@Message(code = 1000, type = MessageType.NOTICE_PRIVATE, note = "测试")
public class OutModel {
    @Protobuf(order=1, required = true)
    private Model data;

    public Model getData() {
        return data;
    }

    public void setData(Model vData) {
        data = vData;
    }
}
