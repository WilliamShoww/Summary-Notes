package com.palm.core.net.base.api.needperfect;

import java.net.InetAddress;

/**
 * 需业务实现（加Spring注解即可生效）
 * 登陆退出以及非正常断线监听器
 */
public interface ILoginAndLogoutListener {
    /**
     * 登录监听
     * @param vUserId   用户Id
     * @param vInetAddress  客户端连接信息
     */
    public void onLogin(long vUserId, InetAddress vInetAddress);

    /**
     * 掉线监听
     * @param vUserId   用户Id
     */
    public void onLogout(long vUserId);
}
