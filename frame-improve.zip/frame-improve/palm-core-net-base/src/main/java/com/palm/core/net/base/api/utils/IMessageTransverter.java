package com.palm.core.net.base.api.utils;

import com.google.protobuf.Message;
import com.palm.core.net.base.model.MessageInfo;
import com.palm.core.net.base.model.MessageTypeEnum;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

/**
 * 消息协议转换器（已实现 通过Spring注解即可直接调用）
 */
public interface IMessageTransverter {
    /**
     * 获取协议号
     * @param vMsgClass 消息class
     * @return
     *      协议号
     */
    public long getCode(Class<? extends Message> vMsgClass);

    /**
     * 获取协议号
     * @param vMsg      消息对象
     * @return
     *      协议号
     */
    public long getCode(Message vMsg);

    /**
     * 获取消息class
     * @param vCode     协议号
     * @return
     *      消息class
     */
    public Class<Message> getMsgClass(long vCode);

    /**
     * 协议编码
     * @param vMsg      消息
     * @return
     *      消息编码后数据
     */
    public byte[] encode(Message vMsg) throws IOException;

    /**
     * 协议解码
     * @param vCode     协议号
     * @param vData     数据
     * @return
     *      解码后消息体
     * @throws InvocationTargetException
     * @throws IllegalAccessException
     * @throws NoSuchMethodException
     */
    public Message decode(long vCode, byte[] vData) throws InvocationTargetException, IllegalAccessException, NoSuchMethodException, IOException;

    /**
     * 获取消息类型
     * @param vCode     协议号
     * @return
     *      消息类型
     */
    public MessageTypeEnum getMessageType(long vCode);

    /**
     * 获取协议信息
     * @param vCode     协议号
     * @return
     *      协议信息
     */
    public MessageInfo getMessageInfo(long vCode);

    /**
     * 获取消息 TaskKey
     * @param vMessage  消息
     * @return
     *      TaskKey
     */
    public String getTaskKey(Message vMessage);

    /**
     * 获取某种类型的全部协议
     * @param vMessageType  协议类型
     * @return
     *      该类型的协议列表
     */
    public List<Class<? extends Message>> getMassageClassList(MessageTypeEnum vMessageType);
}
