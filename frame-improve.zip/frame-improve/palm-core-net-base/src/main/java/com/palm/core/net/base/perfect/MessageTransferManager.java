package com.palm.core.net.base.perfect;

import com.google.common.io.ByteStreams;
import com.google.protobuf.Message;
import com.palm.common.kit.OvonicTable;
import com.palm.core.net.base.api.base.ICallBase;
import com.palm.core.net.base.api.needperfect.ILoginHandler;
import com.palm.core.net.base.api.net.IAcceptMessageBySession;
import com.palm.core.net.base.api.net.ISendMessageBySession;
import com.palm.core.net.base.api.utils.ISendMessageKit;
import com.palm.core.net.base.model.LoginResult;
import com.palm.core.net.base.model.MessageFromEnum;
import com.palm.core.net.base.model.MessageInfo;
import com.palm.core.net.base.model.MessagePackage;
import com.palm.core.net.base.perfect.proxylistener.ExecuteListenerProxy;
import com.palm.core.net.base.perfect.proxylistener.LoginAndLogoutListenerProxy;
import com.palm.core.net.base.perfect.proxylistener.SendListenerProxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.IOException;
import java.net.InetAddress;
import java.util.*;
import java.util.concurrent.*;

@Component
public class MessageTransferManager implements ISendMessageKit, IAcceptMessageBySession {
    private final static Logger LOGGER = LoggerFactory.getLogger(MessageTransferManager.class);

    @Autowired private SendListenerProxy               m_SendListenerProxy;             //发送 监听代理类
    @Autowired private ExecuteListenerProxy            m_ExecuteListenerProxy;          //普通请求执行 监听代理类
    @Autowired private LoginAndLogoutListenerProxy     m_LoginAndLogoutListenerProxy;   //登陆断线 监听代理类

    @Autowired private MessageTransverter              m_MessageTransverter;            //消息包转换器
    @Autowired private ISendMessageBySession           m_SendMessageBySession;          //发送消息工具

    @Autowired(required = false)
    private List<ILoginHandler>         m_LoginHandlerList = new ArrayList();     //登陆接口

    private ExecutorService             m_CoreThreadPool;                                       //核心业务对应线程池
    private Thread                      m_TaskDistributeTread       = new TaskDispatcher();     //业务调度线程

    private ScheduledExecutorService    m_TimeoutKillThreadPool     = Executors.newSingleThreadScheduledExecutor();  //任务超时线程池 防止死锁等

    private OvonicTable<Long, Long>     m_SessionIdUserIdTable      = new OvonicTable();            //会话与用户对应表
    private Queue<AbstractTaskDisposer> m_NewWaitingExecuteQueue    = new ConcurrentLinkedQueue();  //等待执行队列

    private Set<Long>   m_RunningUserSet    = Collections.newSetFromMap(new ConcurrentHashMap());   //运行中的用户
    private Set<String> m_RunningTaskKeySet = Collections.newSetFromMap(new ConcurrentHashMap());   //运行中的任务Key

    @Value("${core.thread.size:24}")
    private int m_CoreThreadSize;

    @Value("${core.thread.executeTimeMax:5000}")
    private int m_TaskExecuteTimeMax;

    @PostConstruct
    public void init() throws IOException {
        m_CoreThreadPool = Executors.newFixedThreadPool(m_CoreThreadSize);
        m_TaskDistributeTread.start();
        LOGGER.info(new String(ByteStreams.toByteArray(getClass().getResourceAsStream("/logo.txt"))));
    }

    @PreDestroy
    public void uninit(){
        m_TaskDistributeTread.interrupt();
        m_CoreThreadPool.shutdown();
    }

    @Override
    public void accept(MessagePackage vMessagePackage, MessageFromEnum vMessageFromEnum) {
        //重置用户Id
        if(MessageFromEnum.NORMAL == vMessageFromEnum)
            vMessagePackage.setUserId(m_SessionIdUserIdTable.getValue(vMessagePackage.getSessionId()));
        m_NewWaitingExecuteQueue.offer(new RequestTaskDisposer(vMessagePackage, vMessageFromEnum));
    }

    @Override
    public void disconnect(long vSessionId) {
        Long tUserId = m_SessionIdUserIdTable.getKey(vSessionId);
        if(null != tUserId){
            m_SessionIdUserIdTable.removeByKey(vSessionId);
            m_NewWaitingExecuteQueue.offer(new AbstractTaskDisposer(tUserId) {
                @Override
                public void onExecuteHandler() {
                    for (ILoginHandler tLoginHandler : m_LoginHandlerList) {
                        tLoginHandler.onDisconnect(m_UserId);
                    }

                    m_LoginAndLogoutListenerProxy.onLogout(m_UserId);
                }
            });
        }
    }

    @Override
    public void send(final Message vMessage, final long vUserId) {
        m_SendListenerProxy.onSendStart(vUserId, vMessage);
        final Long tSessionId = m_SessionIdUserIdTable.getKey(vUserId);
        if(null == tSessionId)
            m_SendListenerProxy.onSendFail(vUserId, vMessage);
        else {
            m_SendMessageBySession.send(new MessagePackage(vMessage, m_MessageTransverter.getCode(vMessage), tSessionId, vUserId), new ICallBase() {
                @Override
                public void onCall(final boolean vSuccess) {
                    //交给netty线程执行
                    if (true == vSuccess)
                        m_SendListenerProxy.onSendSucceed(vUserId, vMessage);
                    else
                        m_SendListenerProxy.onSendFail(vUserId, vMessage);

                    //若执行后该会话不在用户表 则直接返回发送失败
                    if (null == m_SessionIdUserIdTable.getValue(tSessionId))
                        m_SendMessageBySession.kickSession(tSessionId);
                }
            });
        }
    }

    @Override
    public void send(Message vMessage, List<Long> vUserIds) {
        for (Long tUserId : vUserIds)
            send(vMessage, tUserId);
    }

    @Override
    public void simulateRequest(long vUserId, Message vMessage, MessageFromEnum vMessageFromEnum) {
        m_NewWaitingExecuteQueue.offer(new RequestTaskDisposer(new MessagePackage(vMessage, m_MessageTransverter.getCode(vMessage), m_SessionIdUserIdTable.getKey(vUserId), vUserId), vMessageFromEnum));
    }

    @Override
    public void broadcast(Message vMessage) {
        //未作当前登录保证等。。 最简单模式实现发给当前在线玩家
        send(vMessage, m_SessionIdUserIdTable.getValueList());
    }

    @Override
    public void resetOrder(long vUserId) {
        Long tSessionId = m_SessionIdUserIdTable.getKey(vUserId);
        m_SendMessageBySession.resetOrder(tSessionId);
    }

    @Override
    public InetAddress getAddress(long vUserId) {
        return m_SendMessageBySession.getAddress(m_SessionIdUserIdTable.getKey(vUserId));
    }

    @Override
    public void kickUser(final long vUserId) {
        m_NewWaitingExecuteQueue.offer(new AbstractTaskDisposer(vUserId){
            @Override
            public void onExecuteHandler() {
                Long tSessionId = m_SessionIdUserIdTable.getKey(m_UserId);
                if(null != tSessionId)
                    m_SendMessageBySession.kickSession(tSessionId);
            }
        });
    }

    @Override
    public List<Long> getOnlineUserIds() {
        return m_SessionIdUserIdTable.getValueList();
    }

    /**
     * 任务抽象类 对异常做相应处理
     */
    private abstract class AbstractTaskDisposer implements Runnable{
        protected final Long    m_UserId;
        protected final String  m_ThreadKey;

        public AbstractTaskDisposer(Long vUserId) {
            m_UserId = vUserId;
            m_ThreadKey = UUID.randomUUID().toString();
        }

        public AbstractTaskDisposer(Long vUserId, String vThreadKey) {
            m_UserId = vUserId;
            m_ThreadKey = vThreadKey;
        }

        public Long getUserId() {
            return m_UserId;
        }

        public String getThreadKey() {
            return m_ThreadKey;
        }

        @Override
        final public void run() {
            try {
                onExecuteHandler();
            }catch (Throwable vE){
                LOGGER.error("run error!!! info="+info(), vE);
            }finally {
                if(null != m_UserId)
                    m_RunningUserSet.remove(m_UserId);

                m_RunningTaskKeySet.remove(m_ThreadKey);
            }
        }

        public String info(){
            return "AbstractTaskDisposer{" +
                    "m_UserId=" + m_UserId +
                    ", m_ThreadKey='" + m_ThreadKey + '\'' +
                    '}';
        }

        public abstract void onExecuteHandler();
    }

    /**
     * 执行任务封装（登录消息处理，登录前消息处理，正常业务消息处理）
     */
    private class RequestTaskDisposer extends AbstractTaskDisposer {
        private MessagePackage  m_MessagePackage;
        private MessageFromEnum m_MessageFromEnum;

        public RequestTaskDisposer(MessagePackage vMessagePackage, MessageFromEnum vMessageFromEnum) {
            super(vMessagePackage.getUserId(), m_MessageTransverter.getTaskKey(vMessagePackage.getMessage()));
            m_MessagePackage    = vMessagePackage;
            m_MessageFromEnum   = vMessageFromEnum;
        }

        @Override
        public void onExecuteHandler() {
            MessageInfo tMessageInfo    = m_MessageTransverter.getMessageInfo(m_MessagePackage.getCode());
            Long        tUserId         = m_UserId;
            switch (tMessageInfo.getType()) {
                case LOGIN_REQUEST:
                    //登录成功 替换登录表回调登陆成功 若登录失败 在发送完响应后直接断开连接(此处将发送以及替换会话交给异步是为了加锁，保证新的旧的数据不会发给新的会话)
                    final InetAddress tAddress = m_SendMessageBySession.getAddress(m_MessagePackage.getSessionId());
                    final LoginResult tLoginResult = tMessageInfo.getLoginHandler().onLogin(m_MessagePackage.getMessage(), tAddress);
                    m_NewWaitingExecuteQueue.offer(new AbstractTaskDisposer(tLoginResult.getUserId()){
                        @Override
                        public void onExecuteHandler() {
                            if(null != m_UserId){
                                if(null != m_SessionIdUserIdTable.getKey(m_UserId))
                                    m_LoginAndLogoutListenerProxy.onLogout(m_UserId);

                                //先移除旧的玩家
                                m_SessionIdUserIdTable.removeByValue(m_UserId);
                                m_SessionIdUserIdTable.put(m_MessagePackage.getSessionId(), m_UserId);
                                m_LoginAndLogoutListenerProxy.onLogin(m_UserId, tAddress);
                            }

                            m_SendMessageBySession.send(new MessagePackage(tLoginResult.getLoginResponse(), m_MessageTransverter.getCode(tLoginResult.getLoginResponse()), m_MessagePackage.getSessionId(), null), new ICallBase() {
                                @Override
                                public void onCall(boolean vSuccess) {
                                    if(null == m_UserId)
                                        m_SendMessageBySession.kickSession(m_MessagePackage.getSessionId());
                                }
                            });
                        }
                    });
                    break;
                case BEFORE_LOGIN_REQUEST:
                    Message tResponseMessage = tMessageInfo.getNotLoginExecuteHandler().onExecute(m_MessagePackage.getMessage());
                    m_SendMessageBySession.send(new MessagePackage(tResponseMessage, m_MessageTransverter.getCode(tResponseMessage), m_MessagePackage.getSessionId(), null), null);
                    break;

                case LATER_LOGIN_REQUEST:
                    //玩家登录成功则执行，未登录则直接断掉链接
                    if(null != tUserId) {
                        m_ExecuteListenerProxy.onExecute(tUserId, m_MessagePackage.getMessage(), m_MessageFromEnum);
                        tMessageInfo.getExecuteHandler().onExecute(tUserId, m_MessagePackage.getMessage());
                    }else {
                        LOGGER.warn(String.format("no login! sessionId=%s, class=%s, message=%s", m_MessagePackage.getSessionId(), m_MessagePackage.getMessage().getClass(), m_MessagePackage.getMessage()));
                        m_SendMessageBySession.kickSession(m_MessagePackage.getSessionId());
                    }
                    break;

                case RESPONSE:
                    LOGGER.warn(String.format("Message have not handler info: %s, msg: %s", tMessageInfo, m_MessagePackage));
                    break;
            }
        }

        @Override
        public String info() {
            return m_MessagePackage.toString();
        }
    }

    private class TaskDispatcher extends Thread{
        private void execute(Runnable vRunnable){
            final Future<?> tSubmit = m_CoreThreadPool.submit(vRunnable);

            m_TimeoutKillThreadPool.schedule(new Runnable() {
                @Override
                public void run() {
                    if(false == tSubmit.isDone())
                        tSubmit.cancel(true);
                }
            }, m_TaskExecuteTimeMax, TimeUnit.MILLISECONDS);
        }

        @Override
        public void run() {
            //
            Queue<AbstractTaskDisposer> tAllExecuteQueue        = new ArrayDeque();
            Queue<AbstractTaskDisposer> tSurplusExecuteQueue    = new ArrayDeque();

            //截取模式，保证key及用户相同的任务以队列顺序执行 （对线程的性能有所消耗，若后期性能不足可以去除 让消息可以存在执行先后问题）
            Set<Long>   tRunningUserSet     = new HashSet();
            Set<String> tRunningTaskKeySet  = new HashSet();

            while (false == isInterrupted()) {
                try {
                    tRunningUserSet.addAll(m_RunningUserSet);
                    tRunningTaskKeySet.addAll(m_RunningTaskKeySet);

                    //将新的任务加入 队列末端
                    for (AbstractTaskDisposer tItem = m_NewWaitingExecuteQueue.poll(); null != tItem && 1000000 >= tAllExecuteQueue.size(); tItem = m_NewWaitingExecuteQueue.poll())
                        tAllExecuteQueue.offer(tItem);

                    for(AbstractTaskDisposer tTaskDisposer = tAllExecuteQueue.poll(); null != tTaskDisposer; tTaskDisposer=tAllExecuteQueue.poll()){
                        if(null == tTaskDisposer.getUserId()){
                            execute(tTaskDisposer);
                        } else if(false == tRunningUserSet.contains(tTaskDisposer.getUserId()) && false == tRunningTaskKeySet.contains(tTaskDisposer.getThreadKey())){
                            m_RunningUserSet.add(tTaskDisposer.getUserId());
                            m_RunningTaskKeySet.add(tTaskDisposer.getThreadKey());
                            tRunningUserSet.add(tTaskDisposer.getUserId());
                            tRunningTaskKeySet.add(tTaskDisposer.getThreadKey());

                            execute(tTaskDisposer);
                        }else {
                            tSurplusExecuteQueue.offer(tTaskDisposer);
                        }
                    }

                    //两容器互换 剩余未执行任务仍在全部任务队列里 而空出的全部任务队列则作为下次剩余未执行任务的容器使用
                    Queue<AbstractTaskDisposer> tTmp = tAllExecuteQueue;
                    tAllExecuteQueue = tSurplusExecuteQueue;
                    tSurplusExecuteQueue = tTmp;

                    tRunningUserSet.clear();
                    tRunningTaskKeySet.clear();

                    //防止cpu爆表
                    sleep(1);
                } catch (Throwable vE) {
                    LOGGER.error("run TaskDispatcher", vE);
                }
            }
        }
    }
}