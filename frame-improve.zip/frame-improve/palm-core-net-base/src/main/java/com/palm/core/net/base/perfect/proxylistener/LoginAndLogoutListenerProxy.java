package com.palm.core.net.base.perfect.proxylistener;

import com.palm.core.net.base.api.needperfect.ILoginAndLogoutListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

@Component
public class LoginAndLogoutListenerProxy implements ILoginAndLogoutListener {
    private final static Logger LOGGER = LoggerFactory.getLogger(LoginAndLogoutListenerProxy.class);

    @Autowired(required = false)
    private List<ILoginAndLogoutListener> m_LoginAndLogoutListenerList = new ArrayList();

    @Override
    public void onLogin(long vUserId, InetAddress vInetAddress) {
        for (ILoginAndLogoutListener tLoginAndLogoutListener : m_LoginAndLogoutListenerList) {
            try {
                tLoginAndLogoutListener.onLogin(vUserId, vInetAddress);
            } catch (Throwable e) {
                LOGGER.error(String.format("onLogin ==> vUserId=%s!", vUserId), e);
            }
        }
        LOGGER.debug(String.format("onLogin ==> vUserId=%s!", vUserId));
    }

    @Override
    public void onLogout(long vUserId) {
        for (ILoginAndLogoutListener tLoginAndLogoutListener : m_LoginAndLogoutListenerList) {
            try {
                tLoginAndLogoutListener.onLogout(vUserId);
            } catch (Throwable e) {
                LOGGER.error(String.format("onLogout ==> vUserId=%s!", vUserId), e);
            }
        }
        LOGGER.debug(String.format("onLogout ==> vUserId=%s!", vUserId));
    }
}
