package com.palm.core.net.base.annotations;

import com.google.protobuf.Message;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 限制监听协议
 * 优先 massage 若无则以 hand 为准
 * 以下接口有效
 * IExecuteListener
 * ISendListener
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Documented
public @interface Detection {
    /**
     * 监听具体协议
     */
    public Class<? extends Message>[] massage() default {};

    /**
     * 监听协议前段符合（包名，外层类）
     */
    public String hand() default "";
}
