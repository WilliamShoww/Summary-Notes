package com.palm.core.net.base.model;

import com.google.protobuf.Message;

/**
 * 解析数据包头
 */
public class MessagePackage {
    private Message m_Message;      //消息
    private long    m_SessionId;    //消息对应会话
    private Long    m_UserId;       //消息对应玩家
    private long    m_Code;         //协议号

    public MessagePackage() {
    }

    public MessagePackage(Message vMessage, long vCode) {
        m_Message = vMessage;
        m_Code = vCode;
    }

    public MessagePackage(Message vMessage, long vCode, long vSessionId, Long vUserId) {
        m_Message = vMessage;
        m_SessionId = vSessionId;
        m_UserId = vUserId;
        m_Code = vCode;
    }

    public Message getMessage() {
        return m_Message;
    }

    public long getSessionId() {
        return m_SessionId;
    }

    public Long getUserId() {
        return m_UserId;
    }

    public void setUserId(Long vUserId) {
        m_UserId = vUserId;
    }

    public void setSessionId(long vSessionId) {
        m_SessionId = vSessionId;
    }

    public long getCode() {
        return m_Code;
    }

    @Override
    public String toString() {
        return "MessagePackage{" +
                "m_Message=" + m_Message +
                ", m_SessionId=" + m_SessionId +
                ", m_UserId=" + m_UserId +
                ", m_Code=" + m_Code +
                '}';
    }
}
