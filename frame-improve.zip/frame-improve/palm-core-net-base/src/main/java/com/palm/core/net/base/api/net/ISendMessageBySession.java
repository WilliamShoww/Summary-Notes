package com.palm.core.net.base.api.net;

import com.palm.core.net.base.api.base.ICallBase;
import com.palm.core.net.base.model.MessagePackage;

import java.net.InetAddress;
import java.util.concurrent.Future;

/**
 * 网络层实现（由net.base调用 外部禁止调用）
 * 通过Session发送消息
 */
public interface ISendMessageBySession {
    /**
     * 发送消息 通过 会话Id
     * @param vMessagePackage   消息封装包
     * @return
     *      Future<Void> 结果检测器
     */
    public Future<Void> send(MessagePackage vMessagePackage);

    /**
     * 发送消息 通过 会话Id
     * @param vMessagePackage   消息封装包
     * @param vCall             结果回调
     */
    public void send(MessagePackage vMessagePackage, ICallBase vCall);

    /**
     * 重置Order（为旧服务做预留）
     * @param vSessionId    会话Id
     */
    public void resetOrder(long vSessionId);

    /**
     * 获取用户地址信息
     * @param vSessionId    会话Id
     * @return
     *      InetAddress 户地址信息
     */
    public InetAddress getAddress(long vSessionId);

    /**
     * 踢掉会话
     * @param vSessionId    会话Id
     */
    public void kickSession(long vSessionId);
}
