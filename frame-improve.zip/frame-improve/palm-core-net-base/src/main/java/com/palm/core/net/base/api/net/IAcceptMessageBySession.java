package com.palm.core.net.base.api.net;

import com.palm.core.net.base.model.MessageFromEnum;
import com.palm.core.net.base.model.MessagePackage;

/**
 * 通过网络层调用 启动消息（已有实现，通过Spring注解即可调用）
 * 协议入口调度管理接口
 */
public interface IAcceptMessageBySession {
    /**
     * 消息处理入口
     * @param vMessagePackage   消息包
     * @param vMessageFromEnum  消息来源
     */
    public void accept(MessagePackage vMessagePackage, MessageFromEnum vMessageFromEnum);

    /**
     * 会话被销毁
     * @param vSessionId    会话Id
     */
    public void disconnect(long vSessionId);
}
