package com.palm.core.net.base.model;

import com.google.protobuf.Message;

import java.util.concurrent.Future;

public class SendInfo {
    private Future<Void>    m_Future;       //发送结果
    private Message         m_Message;      //发送消息

    public SendInfo(Message vMessage, Future<Void> vFuture) {
        m_Future = vFuture;
        m_Message = vMessage;
    }

    public Future<Void> getFuture() {
        return m_Future;
    }

    public Message getMessage() {
        return m_Message;
    }
}
