package com.palm.core.net.base.api.needperfect;

import com.google.protobuf.Message;
import com.palm.core.net.base.api.base.IHandler;

/**
 * 需业务实现（加Spring注解即可生效）
 * 普通协议执行器
 * @param <TMessage>
 */
public interface IExecuteHandler<TMessage extends Message> extends IHandler {
    /**
     * 执行接口
     * @param vUserId       //用户Id
     * @param vTMessage     //执行消息
     */
    public void onExecute(long vUserId, TMessage vTMessage);
}