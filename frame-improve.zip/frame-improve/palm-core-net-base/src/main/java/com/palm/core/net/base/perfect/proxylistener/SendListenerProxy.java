package com.palm.core.net.base.perfect.proxylistener;

import com.google.protobuf.Message;
import com.palm.core.net.base.annotations.Detection;
import com.palm.core.net.base.api.needperfect.ISendListener;
import com.palm.core.net.base.api.utils.IMessageTransverter;
import com.palm.core.net.base.model.MessageTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class SendListenerProxy implements ISendListener{
    private final static Logger LOGGER = LoggerFactory.getLogger(SendListenerProxy.class);

    @Autowired(required=false)
    private List<ISendListener> m_SendListenerList = new ArrayList();

    @Autowired
    private IMessageTransverter m_MessageTransverter;

    private List<ISendListener> m_AllMessageListenerList = new ArrayList();

    private Map<Class<? extends Message>, List<ISendListener>> m_ClassExecuteListenerMap = new HashMap();

    @PostConstruct
    public void init(){
        List<Class<? extends Message>> tMassageClassList = m_MessageTransverter.getMassageClassList(MessageTypeEnum.LATER_LOGIN_REQUEST);
        for (ISendListener tExecuteListener : m_SendListenerList) {
            Detection tAnnotation = tExecuteListener.getClass().getAnnotation(Detection.class);
            if(null != tAnnotation && (false == tAnnotation.hand().isEmpty() || 0 != tAnnotation.massage().length)){
                if(0 != tAnnotation.massage().length){
                    for (Class<? extends Message> tClass : tAnnotation.massage()) {
                        List<ISendListener> tList = m_ClassExecuteListenerMap.get(tClass);
                        if(null == tList){
                            tList = new ArrayList();
                            m_ClassExecuteListenerMap.put(tClass, tList);
                        }

                        tList.add(tExecuteListener);
                    }
                }

                if(false == tAnnotation.hand().isEmpty()) {
                    for (Class<? extends Message> tClass : tMassageClassList) {
                        if (true == tClass.getName().contains(tAnnotation.hand())) {
                            List<ISendListener> tList = m_ClassExecuteListenerMap.get(tClass);
                            if(null == tList){
                                tList = new ArrayList();
                                m_ClassExecuteListenerMap.put(tClass, tList);
                            }

                            tList.add(tExecuteListener);
                        }
                    }
                }
            }else {
                m_AllMessageListenerList.add(tExecuteListener);
            }
        }
    }

    @Override
    public void onSendStart(long vUserId, Message vTMessage) {
        List<ISendListener> tPartListenerList = m_ClassExecuteListenerMap.get(vTMessage.getClass());
        if(null != tPartListenerList){
            for (ISendListener tSendListener : tPartListenerList)
                tSendListener.onSendStart(vUserId, vTMessage);
        }

        for (ISendListener tSendListener : m_AllMessageListenerList)
            tSendListener.onSendStart(vUserId, vTMessage);

        LOGGER.debug(String.format("ProxySendListener onSendStart ==> vUserId=%s, Class=%s, vTMessage=%s!", vUserId, vTMessage.getClass().getSimpleName(), vTMessage));
    }

    @Override
    public void onSendSucceed(long vUserId, Message vTMessage) {
        List<ISendListener> tPartListenerList = m_ClassExecuteListenerMap.get(vTMessage.getClass());
        if(null != tPartListenerList){
            for (ISendListener tSendListener : tPartListenerList)
                tSendListener.onSendSucceed(vUserId, vTMessage);
        }

        for (ISendListener tSendListener : m_AllMessageListenerList)
            tSendListener.onSendSucceed(vUserId, vTMessage);

        LOGGER.debug(String.format("ProxySendListener onSendSucceed ==> vUserId=%s, Class=%s, vTMessage=%s!", vUserId, vTMessage.getClass().getSimpleName(), vTMessage));
    }

    @Override
    public void onSendFail(long vUserId, Message vTMessage) {
        List<ISendListener> tPartListenerList = m_ClassExecuteListenerMap.get(vTMessage.getClass());
        if(null != tPartListenerList){
            for (ISendListener tSendListener : tPartListenerList)
                tSendListener.onSendFail(vUserId, vTMessage);
        }

        for (ISendListener tSendListener : m_AllMessageListenerList)
            tSendListener.onSendFail(vUserId, vTMessage);

        LOGGER.debug(String.format("ProxySendListener onSendFail ==> vUserId=%s, Class=%s, vTMessage=%s!", vUserId, vTMessage.getClass().getSimpleName(), vTMessage));
    }
}
