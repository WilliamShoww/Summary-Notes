package com.palm.core.net.base.api.needperfect;

import com.google.protobuf.Message;
import com.palm.core.net.base.model.MessageFromEnum;

/**
 * 需业务实现（加Spring注解即可生效）
 * 协议消息执行监听器
 */
public interface IExecuteListener {
    /**
     * 执行完 触发器
     * @param vUserId           用户Id
     * @param vTMessage         执行消息
     * @param vMessageFromEnum  消息源
     */
    public void onExecute(long vUserId, Message vTMessage, MessageFromEnum vMessageFromEnum);
}
