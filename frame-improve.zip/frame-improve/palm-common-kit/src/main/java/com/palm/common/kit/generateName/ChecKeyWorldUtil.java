package com.palm.common.kit.generateName;

import com.palm.common.kit.http.HttpService;

import java.net.URLEncoder;

/**
 * @Author:zhh
 * @Date:Created in 18:40 2018/8/13 0013
 * 检查过滤子
 */
public class ChecKeyWorldUtil {
    /**
     *
     * @param url  过滤子服务器地址
     * @param info 内容
     * @return 将字符串中包含的关键字过滤并替换为*，然后退回替换后的字符串
     */
    public static String getFilterString(String url,String info) {
        try {
            info = HttpService.sendPost2(url, "str=" + URLEncoder.encode(info, "utf-8"));
            return removeFourChar(info);
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }
    }

    public static String removeFourChar(String content) {
        byte[] conbyte = content.getBytes();
        for (int i = 0; i < conbyte.length; i++) {
            if ((conbyte[i] & 0xF8) == 0xF0) {
                for (int j = 0; j < 4; j++) {
                    conbyte[i+j]=0x30;
                }
                i += 3;
            }
        }
        content = new String(conbyte);
        return content.replaceAll("0000", "****");
    }
}