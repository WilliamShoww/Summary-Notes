package com.palm.common.kit;

import java.io.File;
import java.io.IOException;
import java.net.JarURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class ClassKit {
    public static Set<String> getLocalClassNameSet(String vPackageName) {
        Set<String> tResult   = new LinkedHashSet();
        try {
            Enumeration<URL> tSystemResources = ClassLoader.getSystemResources("");
            while (tSystemResources.hasMoreElements()) {
                URL         tURL      = tSystemResources.nextElement();
                String      tRootPath = PathKit.jointRapid(new File(tURL.getFile()).getPath(), "/");
                String      tDirPath  = PathKit.jointRapid(tRootPath, vPackageName.replace(".", "/"));
                Queue<File> tDirQueue = new LinkedList(Collections.singletonList(new File(tDirPath)));
                for (File tDir = tDirQueue.poll(); null != tDir; tDir = tDirQueue.poll()) {
                    File[] tTmpFileList = tDir.listFiles();
                    if (null != tTmpFileList) {
                        for (File tFileItem : tTmpFileList) {
                            if (true == tFileItem.isDirectory()) {
                                tDirQueue.offer(tFileItem);
                            } else {
                                String tFilePath = PathKit.jointRapid(tFileItem.getPath());
                                tResult.add(tFilePath.substring(tRootPath.length(), tFilePath.lastIndexOf(".")).replace("/", "."));
                            }
                        }
                    }
                }
            }
        } catch (IOException vE) {
            vE.printStackTrace();
        }

        return tResult;
    }

    public static Set<String> getJarClassNameSet(String vPackageName){
        String      tPackagePath  = vPackageName.replace('.', '/');
        Set<String> tResult   = new LinkedHashSet();
        try {
            Enumeration<URL> tEnumeration = Thread.currentThread().getContextClassLoader().getResources(tPackagePath);
            while (true == tEnumeration.hasMoreElements()) {
                URL tURL = tEnumeration.nextElement();
                URLConnection tURLConnection = tURL.openConnection();
                if(tURLConnection instanceof JarURLConnection) {
                    try (JarFile tJarFile = ((JarURLConnection) tURLConnection).getJarFile()) {
                        Enumeration<JarEntry> tEntries = tJarFile.entries();
                        if (true == tEntries.hasMoreElements()) {
                            while (true == tEntries.hasMoreElements()) {
                                JarEntry tJarEntry = tEntries.nextElement();
                                String tJarEntryName = tJarEntry.getName();
                                if (tJarEntryName.startsWith(tPackagePath) && (tJarEntryName.endsWith(".java") || tJarEntryName.endsWith(".class"))) {
                                    String tClassName = tJarEntryName.replace('/', '.');
                                    tClassName = tClassName.substring(0, tClassName.lastIndexOf('.'));
                                    tResult.add(tClassName);
                                }
                            }
                        }
                    }
                }
            }
        } catch (IOException vE) {
            vE.printStackTrace();
        }

        return tResult;
    }

    public static Set<String> getAllClassNameSet(String vPackageName){
        Set<String> tResult = getJarClassNameSet(vPackageName);
        tResult.addAll(getLocalClassNameSet(vPackageName));
        return tResult;
    }

    public static Set<Class> getClassList(String vPackageName){
        return getClassList(vPackageName, (IClassFilter) null);
    }

    public static Set<Class> getClassList(String vPackageName, final Class vAnnotationClass){
        return getClassList(vPackageName, new IClassFilter() {
            @Override
            public boolean filtrate(Class vClass) {
                return null != vClass.getAnnotation(vAnnotationClass);
            }
        });
    }

    public static Set<Class> getClassList(String vPackageName, IClassFilter vClassFilter){
        Set<Class> tResult = new LinkedHashSet();
        Set<String> tAllClassNameSet = getAllClassNameSet(vPackageName);
        for (String tClassName : tAllClassNameSet) {
            try {
                Class tClass = Class.forName(tClassName);
                if(null == vClassFilter || vClassFilter.filtrate(tClass)){
                    tResult.add(tClass);
                }
            } catch (Throwable vThrowable) {
                vThrowable.printStackTrace();
            }
        }
        return tResult;
    }

    public interface IClassFilter {
        public boolean filtrate(Class vClass);
    }
}
