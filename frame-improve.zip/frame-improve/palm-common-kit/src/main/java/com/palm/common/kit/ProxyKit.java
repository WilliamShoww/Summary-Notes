package com.palm.common.kit;

import org.springframework.cglib.proxy.Enhancer;
import org.springframework.cglib.proxy.MethodInterceptor;
import org.springframework.cglib.proxy.MethodProxy;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ProxyKit {
    public static <TProxyClass> TProxyClass createProxy(Class<?> vProxyClass, Collection<TProxyClass> vPrincipalList){
        Enhancer                tEnhancer      = new Enhancer();
        final List<TProxyClass> tPrincipalList = new ArrayList(vPrincipalList);
        tEnhancer.setSuperclass(vProxyClass);
        tEnhancer.setCallback(new MethodInterceptor() {
            @Override
            public Object intercept(Object vProxyObject, Method vMethod, Object[] vArgs, MethodProxy vMethodProxy) throws Throwable {
                for (TProxyClass tProxyClass : tPrincipalList) {
                    Object tResult = vMethod.invoke(tProxyClass, vArgs);
                    if(null != tResult)
                        return tResult;
                }
                return null;
            }
        });
        return (TProxyClass) tEnhancer.create();
    }
}
