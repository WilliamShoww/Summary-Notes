package com.palm.common.kit;

import java.util.concurrent.locks.Lock;

/**
 * 自动释放锁 封装
 * 使用模板
 * try（AutoLock tAutoLock = new AutoLock(tLock)）{
 * <p>
 * }
 */
public class AutoLock implements AutoCloseable {
    private Lock m_Lock;

    public AutoLock(Lock vLock) {
        m_Lock = vLock;
        m_Lock.lock();
    }

    @Override
    public void close() {
        m_Lock.unlock();
    }
}
