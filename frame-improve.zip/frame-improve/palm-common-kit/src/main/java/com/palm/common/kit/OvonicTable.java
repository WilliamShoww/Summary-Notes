package com.palm.common.kit;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * 双向 get 容器
 *
 * @param <TKey>
 * @param <TValue>
 */
public class OvonicTable<TKey, TValue> {
    private Map<TKey, TValue> m_KeyValueMap   = new HashMap();
    private Map<TValue, TKey> m_ValueKeyMap   = new HashMap();
    private ReadWriteLock     m_ReadWriteLock = new ReentrantReadWriteLock();

    public TValue getValue(TKey vKey) {
        try (AutoLock tAutoLock = new AutoLock(m_ReadWriteLock.readLock())) {
            return m_KeyValueMap.get(vKey);
        }
    }

    public TKey getKey(TValue vValue) {
        try (AutoLock tAutoLock = new AutoLock(m_ReadWriteLock.readLock())) {
            return m_ValueKeyMap.get(vValue);
        }
    }

    public void put(TKey vKey, TValue vValue) {
        try (AutoLock tAutoLock = new AutoLock(m_ReadWriteLock.writeLock())) {
            removeByKey(vKey);
            removeByValue(vValue);

            m_KeyValueMap.put(vKey, vValue);
            m_ValueKeyMap.put(vValue, vKey);
        }
    }

    public void removeByKey(TKey vKey) {
        try (AutoLock tAutoLock = new AutoLock(m_ReadWriteLock.writeLock())) {
            TValue tValue = m_KeyValueMap.remove(vKey);
            if(null != tValue)
                m_ValueKeyMap.remove(tValue);
        }
    }

    public void removeByValue(TValue vValue) {
        try (AutoLock tAutoLock = new AutoLock(m_ReadWriteLock.writeLock())) {
            TKey tKey = m_ValueKeyMap.remove(vValue);
            if(null != tKey)
                m_KeyValueMap.remove(tKey);
        }
    }

    public List<TKey> getKeyList() {
        try (AutoLock tAutoLock = new AutoLock(m_ReadWriteLock.readLock())) {
            return new ArrayList(m_KeyValueMap.keySet());
        }
    }

    public List<TValue> getValueList() {
        try (AutoLock tAutoLock = new AutoLock(m_ReadWriteLock.readLock())) {
            return new ArrayList(m_ValueKeyMap.keySet());
        }
    }

    @Override
    public String toString() {
        try (AutoLock tAutoLock = new AutoLock(m_ReadWriteLock.readLock())) {
            return "OvonicTable{" + "m_KeyValueMap=" + m_KeyValueMap + ", m_ValueKeyMap=" + m_ValueKeyMap + "}";
        }
    }
}
