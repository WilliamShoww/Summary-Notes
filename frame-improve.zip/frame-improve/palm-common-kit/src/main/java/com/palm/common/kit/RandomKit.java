package com.palm.common.kit;

import java.util.Random;

public class RandomKit {
    private final static Random RANDOM = new Random();

    /**
     * 获取随机数 区间[)
     * @param vMin  最小值
     * @param vMax  最大值
     * @return      随机数值
     */
    public static int getRandom(int vMin, int vMax){
        return RANDOM.nextInt(vMax - vMin) + vMin;
    }
}
