package com.palm.common.kit;

import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PathKit {
    private final static Pattern COMPILE = Pattern.compile("//", Pattern.LITERAL);

    public static String jointRapid(String ...vNodes){
        StringBuilder tResult = new StringBuilder();
        for (String tNode : vNodes)
            tResult.append("/").append(tNode);

        return format(tResult.substring(1));
    }

    public static String getParentRapid(String vPath){
        if(true == vPath.isEmpty() || true == vPath.equals("/") || false == vPath.contains("/"))
            return null;

        if(true == vPath.endsWith("/"))
            vPath = vPath.substring(0, vPath.length() - 1);

        return vPath.substring(0, vPath.lastIndexOf('/'));
    }

    public static String getNameRapid(String vPath){
        if(true == vPath.isEmpty() || true == vPath.equals("/") || false == vPath.contains("/"))
            return vPath;

        if(true == vPath.endsWith("/"))
            vPath = vPath.substring(0, vPath.length() - 1);

        return vPath.substring(vPath.lastIndexOf('/'));
    }

    public static String joint(String ...vNodes){
        StringBuilder tResult = new StringBuilder();
        for (String tNode : vNodes)
            tResult.append("/").append(tNode);

        return "/".equals(vNodes[0]) ? tResult.substring(2) : tResult.substring(1);
    }

    public static String getParent(String vPath){
        return new File(vPath).getParent();
    }

    public static String getName(String vPath){
        return new File(vPath).getName();
    }

    public static String format(String vPath){
        String tResult = vPath.replace('\\', '/');

        while (true == tResult.contains("//"))
            tResult = COMPILE.matcher(tResult).replaceAll(Matcher.quoteReplacement("/"));

        return tResult;
    }
}
