package com.palm.common.kit;

import java.util.ArrayList;
import java.util.List;

public class ListKit {
    public static <TClass> TClass getLastItem(List<TClass> vList){
        return (null == vList || true == vList.isEmpty()) ? null : vList.get(vList.size()-1);
    }

    public static <TClass> List<TClass> getFirstList(List<TClass> vList, int vLen){
        return (null == vList || true == vList.isEmpty()) ? null : new ArrayList(vList.subList(0, vLen));
    }

    public static <TClass> List<TClass> getLastList(List<TClass> vList, int vLen){
        return (null == vList || true == vList.isEmpty()) ? null : new ArrayList(vList.subList(vList.size()-vLen, vList.size()));
    }

    @SafeVarargs
    public static <TClass> List<TClass> joint(List<TClass>... vList){
        int tSize = 0;
        for (List<TClass> tItemList : vList)
            tSize += tItemList.size();

        List<TClass> tResult = new ArrayList(tSize);

        for (List<TClass> tItemList : vList)
            tResult.addAll(tItemList);

        return tResult;
    }
}
