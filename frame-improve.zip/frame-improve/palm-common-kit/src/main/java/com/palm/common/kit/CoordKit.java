package com.palm.common.kit;

public class CoordKit {
    private final static double SEA_MILE_TO_KM = 1.852;

    /**
     * 距离计算
     * @param vLat1 坐标1 纬度
     * @param vLon1 坐标1 经度
     * @param vLat2 坐标2 纬度
     * @param vLon2 坐标2 经度
     * @return      距离（单位：米）
     */
    public static double distance(double vLat1, double vLon1, double vLat2, double vLon2) {
        double tDist = Math.sin(toRadian(vLat1)) * Math.sin(toRadian(vLat2))
                + Math.cos(toRadian(vLat1)) * Math.cos(toRadian(vLat2))
                * Math.cos(toRadian(vLon1 - vLon2));
        tDist = Math.acos(tDist);
        return toMeter(toDegrees(tDist) * 60);
    }

    /**
     * 角度转弧度
     * @param vDegrees  角度
     * @return          弧度
     */
    private static double toRadian(double vDegrees) {
        return vDegrees / 180 * Math.PI;
    }

    /**
     * 弧度转角度
     * @param vRadian   弧度
     * @return          角度
     */
    private static double toDegrees(double vRadian) {
        return vRadian * 180 / Math.PI;
    }

    /**
     * 海里转米
     * @param vSeaMile  海里
     * @return          米
     */
    private static double toMeter(double vSeaMile){
        return vSeaMile * SEA_MILE_TO_KM * 1000;
    }
}
