package com.palm.common.kit;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class OvonicListTable<TKey, TListValue> {
    private Map<TKey, List<TListValue>> m_KeyListMap    = new HashMap();
    private Map<TListValue, TKey>       m_ValueKeyMap   = new HashMap();

    private ReadWriteLock m_ReadWriteLock = new ReentrantReadWriteLock();

    public TKey getKey(TListValue vValue){
        try(AutoLock tAutoLock = new AutoLock(m_ReadWriteLock.readLock())) {
            return m_ValueKeyMap.get(vValue);
        }
    }

    public List<TListValue> getValueList(TKey vKey){
        try(AutoLock tAutoLock = new AutoLock(m_ReadWriteLock.readLock())) {
            return new ArrayList(m_KeyListMap.get(vKey));
        }
    }

    public boolean add(TKey vKey, TListValue vValue, boolean vCover){
        try(AutoLock tAutoLock = new AutoLock(m_ReadWriteLock.writeLock())) {
            TKey tOldKey = m_ValueKeyMap.get(vValue);
            if(null != tOldKey){
                if(false == vCover)
                    return false;

                m_ValueKeyMap.remove(vValue);
                m_KeyListMap.get(tOldKey).remove(vValue);
            }

            List<TListValue> tListValues = m_KeyListMap.get(vKey);
            if(null == tListValues){
                tListValues = new ArrayList();
                m_KeyListMap.put(vKey, tListValues);
            }

            tListValues.add(vValue);
            m_ValueKeyMap.put(vValue, vKey);
            return true;
        }
    }

    public boolean remove(TKey vKey, TListValue vValue){
        try(AutoLock tAutoLock = new AutoLock(m_ReadWriteLock.writeLock())) {
            TKey tTmpKey = m_ValueKeyMap.get(vValue);
            if(null == tTmpKey || false == tTmpKey.equals(vKey))
                return false;

            m_KeyListMap.get(vKey).remove(vValue);
            m_ValueKeyMap.remove(vValue);
            return true;
        }
    }

    public boolean removeByValue(TListValue vValue){
        try(AutoLock tAutoLock = new AutoLock(m_ReadWriteLock.writeLock())) {
            TKey tTmpKey = m_ValueKeyMap.remove(vValue);
            if(null == tTmpKey)
                return false;

            m_KeyListMap.get(tTmpKey).remove(vValue);
            return true;
        }
    }

    public boolean removeByKey(TKey vKey){
        try(AutoLock tAutoLock = new AutoLock(m_ReadWriteLock.writeLock())) {
            List<TListValue> tValueList = m_KeyListMap.remove(vKey);
            if(null == tValueList)
                return false;

            for (TListValue tListValue : tValueList)
                m_ValueKeyMap.remove(tListValue);

            return true;
        }
    }
}
